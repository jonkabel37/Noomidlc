package com.noomidlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Box ESP: рамка с уголками и полоской здоровья вокруг игроков (и по желанию мобов).
 * Позиции считаются в мировом рендере, рисуются в HUD, поэтому рамка видна и сквозь стены.
 * Линии рисуются в физических пикселях окна - без "лесенки" GUI-масштаба.
 */
public final class Esp {
    private Esp() {}

    private record Frame(float x1, float y1, float x2, float y2, float hp, boolean player, String name, float dist, float hpAbs, int seed, float[] box, float[] bones) {}

    private static final List<Frame> FRAMES = new ArrayList<>();

    public static boolean boxMode() {
        return Config.esp && Config.espMode != 1;
    }

    public static void collect(WorldRenderContext ctx) {
        FRAMES.clear();
        if (!boxMode()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !Config.espMobs) continue;
            if (!le.isAlive()) continue;

            Vec3d lerp = e.getLerpedPos(td);
            Vec3d off = lerp.subtract(e.getPos());
            Box b = e.getBoundingBox();

            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double cx = ((i & 1) == 0 ? b.minX : b.maxX) + off.x - cam.x;
                double cy = ((i & 2) == 0 ? b.minY : b.maxY) + off.y - cam.y;
                double cz = ((i & 4) == 0 ? b.minZ : b.maxZ) + off.z - cam.z;
                Vector4f v = new Vector4f((float) cx, (float) cy, (float) cz, 1.0f);
                v.mul(view);
                v.mul(proj);
                if (v.w <= 0.05f) {
                    ok = false;
                    break;
                }
                float sx = (v.x / v.w * 0.5f + 0.5f) * sw;
                float sy = (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh;
                minX = Math.min(minX, sx);
                maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy);
                maxY = Math.max(maxY, sy);
            }
            if (!ok) continue;
            float[] box3 = null, bones = null;
            if (Config.espMode == 3) box3 = box3d(b, off, cam, view, proj, sw, sh);
            if (Config.espMode == 4) bones = bones(le, off, cam, view, proj, sw, sh);
            if ((Config.espMode == 3 && box3 == null) || (Config.espMode == 4 && bones == null)) continue;
            if (maxX < -20 || minX > sw + 20 || maxY < -20 || minY > sh + 20) continue;

            float hp = MathHelper.clamp(le.getHealth() / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
            FRAMES.add(new Frame(minX, minY, maxX, maxY, hp, player, e.getName().getString(),
                    (float) mc.player.distanceTo(e), le.getHealth() + le.getAbsorptionAmount(), e.getId(), box3, bones));
        }
    }


    private static float[] project(double x, double y, double z, Matrix4f view, Matrix4f proj, int sw, int sh) {
        Vector4f v = new Vector4f((float) x, (float) y, (float) z, 1.0f);
        v.mul(view);
        v.mul(proj);
        if (v.w <= 0.05f) return null;
        return new float[]{(v.x / v.w * 0.5f + 0.5f) * sw, (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh};
    }

    /** 8 углов настоящего 3D-бокса (16 float). */
    private static float[] box3d(Box b, Vec3d off, Vec3d cam, Matrix4f view, Matrix4f proj, int sw, int sh) {
        float[] out = new float[16];
        for (int i = 0; i < 8; i++) {
            double cx = ((i & 1) == 0 ? b.minX : b.maxX) + off.x - cam.x;
            double cy = ((i & 2) == 0 ? b.minY : b.maxY) + off.y - cam.y;
            double cz = ((i & 4) == 0 ? b.minZ : b.maxZ) + off.z - cam.z;
            float[] pt = project(cx, cy, cz, view, proj, sw, sh);
            if (pt == null) return null;
            out[i * 2] = pt[0];
            out[i * 2 + 1] = pt[1];
        }
        return out;
    }

    /** Палочный "скелет": голова, шея, таз, плечи, руки, ноги (по телу, повёрнутому как у существа). 10 точек. */
    private static float[] bones(LivingEntity le, Vec3d off, Vec3d cam, Matrix4f view, Matrix4f proj, int sw, int sh) {
        double h = le.getHeight();
        double bx = le.getX() + off.x - cam.x, by = le.getY() + off.y - cam.y, bz = le.getZ() + off.z - cam.z;
        double yaw = Math.toRadians(le.bodyYaw);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);      // вектор "вправо" относительно тела
        double sw2 = le.getWidth() * 0.55;
        double[][] pts = {
                {0, h * 0.93, 0},            // 0 голова
                {0, h * 0.82, 0},            // 1 шея
                {0, h * 0.45, 0},            // 2 таз
                {-sw2, h * 0.80, 0},         // 3 левое плечо
                {sw2, h * 0.80, 0},          // 4 правое плечо
                {-sw2, h * 0.47, 0},         // 5 левая кисть
                {sw2, h * 0.47, 0},          // 6 правая кисть
                {-sw2 * 0.45, h * 0.45, 0},  // 7 левое бедро
                {sw2 * 0.45, h * 0.45, 0},   // 8 правое бедро
                {0, 0.0, 0}                  // 9 стопы (центр)
        };
        float[] out = new float[22];
        for (int i = 0; i < 10; i++) {
            double lx = pts[i][0];
            float[] pt = project(bx + rx * lx, by + pts[i][1], bz + rz * lx, view, proj, sw, sh);
            if (pt == null) return null;
            out[i * 2] = pt[0];
            out[i * 2 + 1] = pt[1];
        }
        // ступни: две точки
        float[] fl = project(bx + rx * (-sw2 * 0.45), by, bz + rz * (-sw2 * 0.45), view, proj, sw, sh);
        float[] fr = project(bx + rx * (sw2 * 0.45), by, bz + rz * (sw2 * 0.45), view, proj, sw, sh);
        if (fl == null || fr == null) return null;
        out[18] = fl[0]; out[19] = fl[1];
        out[20] = fr[0]; out[21] = fr[1];
        return out;
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!boxMode() || FRAMES.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        Anim.frame();

        boolean fancy = Config.espMode >= 2;
        float px = 1.0f / Ui.scale();   // один физический пиксель в GUI-координатах
        long now = System.currentTimeMillis();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Frame f : FRAMES) {
            float x1 = f.x1(), y1 = f.y1(), x2 = f.x2(), y2 = f.y2();
            float w = x2 - x1, h = y2 - y1;
            if (w < 4 || h < 4) continue;

            float pulse = Config.espPulse ? 0.8f + 0.2f * (float) Math.sin(now / 380.0 + f.seed()) : 1.0f;
            float op = Config.espOpacity * pulse;
            int rgb = f.player() ? WorldFx.rgbOf(Config.espColor, (f.seed() % 100) / 100.0f) : 0xFFFFFF;
            int rgb2 = f.player() ? WorldFx.rgbOf(Config.espColor, ((f.seed() % 100) / 100.0f) + 0.18f) : 0xB0B0FF;
            int col = Ui.alpha(rgb, op);

            if (tracerOn()) tracer(c, sw / 2.0f, sh - 2.0f, (x1 + x2) / 2.0f, y2, Ui.alpha(rgb, 0.55f * op), px);

            if (Config.espMode == 5) {
                drawNeon(c, mc, f, rgb, rgb2, op, px, now);
                continue;
            }

            if (Config.espFill) {
                if (fancy) {
                    // вертикальный градиент: сверху почти прозрачный, снизу насыщенный
                    gradient(c, x1, y1, x2, y2, Ui.alpha(rgb, 0.02f), Ui.alpha(rgb2, 0.26f * op));
                } else {
                    Ui.rrectF(c, x1, y1, w, h, Math.min(6.0f, Math.min(w, h) / 3.0f), (col & 0xFFFFFF) | 0x14000000);
                }
            }

            float len = Math.max(4.0f, Math.min(w, h) / 4.0f);
            float t = px * 2.0f;            // толщина линии 2 физических пикселя

            if (Config.espGlowLayer) {
                // мягкое свечение: несколько расширяющихся контуров с падающей прозрачностью
                for (int k = 4; k >= 1; k--) {
                    float pad = k * px * 1.6f;
                    int gc = Ui.alpha(rgb, (0.12f / k) * op);
                    outline(c, x1 - pad, y1 - pad, x2 + pad, y2 + pad, px * 1.6f, gc);
                }
            }

            if (Config.espMode == 3 && f.box() != null) {
                drawBox3d(c, f.box(), Ui.alpha(rgb, op), px);
            } else if (Config.espMode == 4 && f.bones() != null) {
                drawBones(c, f.bones(), Ui.alpha(rgb, op), Ui.alpha(rgb2, op), px);
            } else if (fancy) {
                outline(c, x1, y1, x2, y2, px, Ui.alpha(rgb, 0.35f * op));        // тонкая полная рамка
                corners(c, x1, y1, x2, y2, len, 0xFF000000, t, px);                // подложка
                cornersGrad(c, x1, y1, x2, y2, len, Ui.alpha(rgb, op), Ui.alpha(rgb2, op), t);
            } else {
                corners(c, x1, y1, x2, y2, len, 0xFF000000, t, px);
                corners(c, x1, y1, x2, y2, len, col | 0xFF000000, t, 0.0f);
            }


            if (Config.espHealth) {
                float bx = x1 - 5.0f;
                Ui.rect(c, bx - px, y1 - px, bx + px * 3.0f, y2 + px, 0xB0000000);
                float fill = h * f.hp();
                if (fancy) {
                    int top = 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.7f, 1.0f);
                    int bot = 0xFF000000 | MathHelper.hsvToRgb(Math.max(0.0f, f.hp() * 0.33f - 0.12f), 0.85f, 0.85f);
                    gradient(c, bx, y2 - fill, bx + px * 2.0f, y2, top, bot);
                } else {
                    Ui.rect(c, bx, y2 - fill, bx + px * 2.0f, y2, 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.75f, 1.0f));
                }
            }

            if (fancy && (Config.espName || Config.espDistance)) {
                String label = Config.espName ? f.name() : "";
                if (Config.espDistance) label += (label.isEmpty() ? "" : "  ") + Math.round(f.dist()) + "m";
                int tw = Ui.width(mc.textRenderer, label);
                int bw = tw + 14, bh = 13;
                float bxl = (x1 + x2) / 2.0f - bw / 2.0f;
                float byl = y1 - bh - 4.0f;
                Ui.rrectF(c, bxl, byl, bw, bh, bh / 2.0f, Ui.alpha(0x0E0E16, 0.72f));
                Ui.rrectF(c, bxl, byl + bh - 1.5f, bw, 1.5f, 0.7f, Ui.alpha(rgb, 0.9f));
                Ui.textMidF(c, mc.textRenderer, label, bxl + 7, byl, bh, 0xFFF2F2FA);
            }
        }
    }


    private static float[] perim(float x1, float y1, float x2, float y2, float d) {
        float w = x2 - x1, h = y2 - y1;
        float per = 2.0f * (w + h);
        d = ((d % per) + per) % per;
        if (d < w) return new float[]{x1 + d, y1};
        d -= w;
        if (d < h) return new float[]{x2, y1 + d};
        d -= h;
        if (d < w) return new float[]{x2 - d, y2};
        d -= w;
        return new float[]{x1, y2 - d};
    }

    /** Neon: неоновая рамка с дыханием, бегущей кометой по периметру, сканирующей полосой и капсулой с именем. */
    private static void drawNeon(DrawContext c, MinecraftClient mc, Frame f, int rgb, int rgb2,
                                 float op, float px, long now) {
        float x1 = f.x1(), y1 = f.y1(), x2 = f.x2(), y2 = f.y2();
        float w = x2 - x1, h = y2 - y1;
        double t = now / 1000.0;
        float seed = (f.seed() % 23) / 23.0f;
        float breathe = 0.5f + 0.5f * (float) Math.sin(t * 2.2 + f.seed());

        // заливка: сверху прозрачно, снизу цвет, чуть дышит
        if (Config.espFill) {
            gradient(c, x1, y1, x2, y2, Ui.alpha(rgb, 0.0f), Ui.alpha(rgb2, (0.12f + 0.10f * breathe) * op));
        }

        // сканирующая полоса ходит вверх-вниз
        float ph = (float) ((t * 0.55 + seed) % 1.0);
        float tri = 1.0f - Math.abs(2.0f * ph - 1.0f);
        float sy = y1 + tri * h;
        float bh = Math.max(3.0f, h * 0.10f);
        gradient(c, x1, Math.max(y1, sy - bh), x2, sy, Ui.alpha(rgb, 0.0f), Ui.alpha(rgb, 0.30f * op));
        gradient(c, x1, sy, x2, Math.min(y2, sy + bh), Ui.alpha(rgb, 0.30f * op), Ui.alpha(rgb, 0.0f));
        Ui.rect(c, x1, sy - px * 0.8f, x2, sy + px * 0.8f, Ui.alpha(0xFFFFFF, 0.55f * op));

        // мягкое свечение вокруг рамки
        for (int k = 9; k >= 1; k--) {
            float pad = k * px * 1.5f;
            int gcol = k > 4 ? Ui.mix(0xFF000000 | rgb, 0xFF000000 | rgb2, (k - 4) / 5.0f) : rgb;
            outline(c, x1 - pad, y1 - pad, x2 + pad, y2 + pad, px * 1.5f,
                    Ui.alpha(gcol, (0.16f / k) * op * (0.7f + 0.3f * breathe)));
        }
        outline(c, x1 - px, y1 - px, x2 + px, y2 + px, px * 1.0f, Ui.alpha(rgb2, 0.28f * op));
        outline(c, x1, y1, x2, y2, px * 1.2f, Ui.alpha(rgb, 0.42f * op));

        // уголки с градиентом
        float len = Math.max(5.0f, Math.min(w, h) / 3.2f);
        float tk = px * 2.2f;
        corners(c, x1, y1, x2, y2, len, 0xFF000000, tk, px);
        cornersGrad(c, x1, y1, x2, y2, len, Ui.alpha(rgb, op), Ui.alpha(rgb2, op), tk);

        // комета бежит по периметру
        float per = 2.0f * (w + h);
        float head = (float) (((t * 0.32 + seed) % 1.0) * per);
        int trail = 14;
        for (int i = 0; i < trail; i++) {
            float[] p = perim(x1, y1, x2, y2, head - i * Math.max(2.0f, per / 70.0f));
            float a = (1.0f - i / (float) trail);
            float sz = px * (3.4f - i * 0.17f);
            Ui.rect(c, p[0] - sz, p[1] - sz, p[0] + sz, p[1] + sz,
                    Ui.alpha(i == 0 ? 0xFFFFFF : rgb, a * a * op));
        }

        // здоровье: закруглённая полоска слева
        if (Config.espHealth) {
            float bx = x1 - 6.0f;
            float bw = px * 3.0f;
            Ui.rrectF(c, bx - px, y1 - px, bw + px * 2.0f, h + px * 2.0f, 1.2f, 0xB0000000);
            float fill = Math.max(px * 2.0f, h * f.hp());
            int top = 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.7f, 1.0f);
            int bot = 0xFF000000 | MathHelper.hsvToRgb(Math.max(0.0f, f.hp() * 0.33f - 0.12f), 0.85f, 0.85f);
            gradient(c, bx, y2 - fill, bx + bw, y2, top, bot);
        }

        // имя и дистанция в капсуле над рамкой
        if (Config.espName || Config.espDistance) {
            String label = Config.espName ? f.name() : "";
            if (Config.espDistance) label += (label.isEmpty() ? "" : "  ") + Math.round(f.dist()) + "m";
            if (Config.espHealth && f.player()) label += "  " + Math.round(f.hpAbs()) + "hp";
            int tw = Ui.width(mc.textRenderer, label);
            int bw2 = tw + 18, bh2 = 14;
            float bxl = (x1 + x2) / 2.0f - bw2 / 2.0f;
            float byl = y1 - bh2 - 5.0f;
            Ui.rrectF(c, bxl - 1.5f, byl - 1.5f, bw2 + 3.0f, bh2 + 3.0f, bh2 / 2.0f + 1.5f, Ui.alpha(rgb, 0.16f * op));
            Ui.rrectF(c, bxl, byl, bw2, bh2, bh2 / 2.0f, Ui.alpha(0x0C0C14, 0.80f));
            Ui.capsuleF(c, bxl + 6.0f, byl + (bh2 - 4) / 2.0f, 4, 4, Ui.alpha(rgb, op));
            Ui.rrectF(c, bxl + 8, byl + bh2 - 1.5f, bw2 - 16, 1.2f, 0.6f, Ui.alpha(rgb2, 0.9f * op));
            Ui.textMidF(c, mc.textRenderer, label, bxl + 12, byl, bh2, 0xFFF4F4FC);
        }
    }

    static final int[][] BOX_EDGES = {
            {0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

    private static void drawBox3d(DrawContext c, float[] p, int color, float px) {
        for (int[] e : BOX_EDGES) {
            tracer(c, p[e[0] * 2], p[e[0] * 2 + 1], p[e[1] * 2], p[e[1] * 2 + 1], color, px * 1.6f);
        }
    }

    private static void drawBones(DrawContext c, float[] p, int a, int b, float px) {
        int[][] links = {{1, 2}, {1, 3}, {1, 4}, {3, 5}, {4, 6}, {2, 7}, {2, 8}};
        float t = px * 1.6f;
        tracer(c, p[0], p[1], p[2], p[3], a, t);      // голова - шея
        for (int[] l : links) tracer(c, p[l[0] * 2], p[l[0] * 2 + 1], p[l[1] * 2], p[l[1] * 2 + 1], a, t);
        tracer(c, p[14], p[15], p[18], p[19], b, t);   // левое бедро - левая стопа
        tracer(c, p[16], p[17], p[20], p[21], b, t);   // правое бедро - правая стопа
        // голова: небольшой квадрат
        float hs = Math.max(2.0f, Math.abs(p[3] - p[5]) * 0.0f + Math.abs(p[1] - p[3]) * 0.9f);
        Ui.rect(c, p[0] - hs, p[1] - hs, p[0] + hs, p[1] + hs, Ui.alpha(0x000000, 0.25f));
        outlineBox(c, p[0] - hs, p[1] - hs, p[0] + hs, p[1] + hs, t, a);
    }

    private static void outlineBox(DrawContext c, float x1, float y1, float x2, float y2, float t, int color) {
        outline(c, x1, y1, x2, y2, t, color);
    }

    private static boolean tracerOn() {
        return Config.espTracer;
    }

    /** Линия от точки к точке из повёрнутого прямоугольника. */
    static void tracer(DrawContext c, float ax, float ay, float bx, float by, int color, float px) {
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 2.0f) return;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(ax, ay, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        Ui.rect(c, 0.0f, -px, len, px, color);
        m.pop();
    }

    /** Градиент сверху вниз в физических пикселях. */
    private static void gradient(DrawContext c, float x1, float y1, float x2, float y2, int top, int bottom) {
        float s = Ui.scale();
        MatrixStack m = c.getMatrices();
        m.push();
        m.scale(1.0f / s, 1.0f / s, 1.0f);
        int X1 = Math.round(x1 * s), Y1 = Math.round(y1 * s), X2 = Math.round(x2 * s), Y2 = Math.round(y2 * s);
        if (X2 > X1 && Y2 > Y1) c.fillGradient(X1, Y1, X2, Y2, top, bottom);
        m.pop();
    }

    private static void outline(DrawContext c, float x1, float y1, float x2, float y2, float t, int color) {
        Ui.rect(c, x1, y1, x2, y1 + t, color);
        Ui.rect(c, x1, y2 - t, x2, y2, color);
        Ui.rect(c, x1, y1 + t, x1 + t, y2 - t, color);
        Ui.rect(c, x2 - t, y1 + t, x2, y2 - t, color);
    }

    /** Уголки, у которых цвет плавно переходит от верха (a) к низу (b). */
    private static void cornersGrad(DrawContext c, float x1, float y1, float x2, float y2,
                                    float len, int a, int b, float t) {
        // верхние уголки - цвет a, нижние - цвет b, вертикальные плечи с градиентом
        Ui.rect(c, x1, y1, x1 + len, y1 + t, a);
        Ui.rect(c, x2 - len, y1, x2, y1 + t, a);
        Ui.rect(c, x1, y2 - t, x1 + len, y2, b);
        Ui.rect(c, x2 - len, y2 - t, x2, y2, b);
        gradient(c, x1, y1, x1 + t, y1 + len, a, Ui.mix(a, b, 0.5f));
        gradient(c, x2 - t, y1, x2, y1 + len, a, Ui.mix(a, b, 0.5f));
        gradient(c, x1, y2 - len, x1 + t, y2, Ui.mix(a, b, 0.5f), b);
        gradient(c, x2 - t, y2 - len, x2, y2, Ui.mix(a, b, 0.5f), b);
    }

    /** pad > 0 рисует подложку шире линии со всех сторон. */
    private static void corners(DrawContext c, float x1, float y1, float x2, float y2,
                                float len, int color, float t, float pad) {
        float p = pad;
        // левый верх
        Ui.rect(c, x1 - p, y1 - p, x1 + len + p, y1 + t + p, color);
        Ui.rect(c, x1 - p, y1 - p, x1 + t + p, y1 + len + p, color);
        // правый верх
        Ui.rect(c, x2 - len - p, y1 - p, x2 + p, y1 + t + p, color);
        Ui.rect(c, x2 - t - p, y1 - p, x2 + p, y1 + len + p, color);
        // левый низ
        Ui.rect(c, x1 - p, y2 - t - p, x1 + len + p, y2 + p, color);
        Ui.rect(c, x1 - p, y2 - len - p, x1 + t + p, y2 + p, color);
        // правый низ
        Ui.rect(c, x2 - len - p, y2 - t - p, x2 + p, y2 + p, color);
        Ui.rect(c, x2 - t - p, y2 - len - p, x2 + p, y2 + p, color);
    }
}
