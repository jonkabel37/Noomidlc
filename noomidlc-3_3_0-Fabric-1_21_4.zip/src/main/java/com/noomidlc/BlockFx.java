package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;

/**
 * Block Effect: анимированная подсветка блока, на который смотришь.
 * Aura - свечение, градиентные грани, бегущие огни по рёбрам и летящие искры.
 * Pulse / Scan / Corners - более простые варианты.
 */
public final class BlockFx {
    private BlockFx() {}

    private static int argb(int rgb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private static float fract(float x) {
        return x - (float) Math.floor(x);
    }

    public static void render(WorldRenderContext ctx) {
        if (!Config.blockFx) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) return;
        boolean any = Config.bfFill || Config.bfOutline || Config.bfGlow || Config.bfSparks || Config.bfMode == 2;
        if (!any) return;

        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        VoxelShape shape = st.getOutlineShape(mc.world, pos);
        Box box = shape.isEmpty() ? new Box(0, 0, 0, 1, 1, 1) : shape.getBoundingBox();
        box = box.offset(pos).expand(0.003);

        Vec3d cam = ctx.camera().getPos();
        double time = (System.currentTimeMillis() % 100000L) / 1000.0 * Config.bfSpeed;
        float wave = 0.5f + 0.5f * (float) Math.sin(time * Math.PI * 2.0);
        int rgb = WorldFx.rgbOf(Config.bfColor, (float) ((time * 0.25) % 1.0));
        int rgb2 = WorldFx.rgbOf(Config.bfColor, (float) ((time * 0.25 + 0.2) % 1.0));
        if (Config.bfColor == 0) rgb2 = Hud.accent2() & 0xFFFFFF;

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = WorldFx.fixMatrix(ctx, ms.peek().getPositionMatrix());

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        switch (Config.bfMode) {
            case 0 -> aura(b, m, x1, y1, z1, x2, y2, z2, time, wave, rgb, rgb2);
            case 2 -> {   // Scan: яркая полоса ходит вверх-вниз по граням
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.10f));
                float ph = (float) (time % 1.0);
                float tri = 1.0f - Math.abs(2.0f * ph - 1.0f);
                float h = y2 - y1;
                float cy = y1 + tri * h;
                float bh = Math.max(0.07f, h * 0.14f);
                float lo = Math.max(y1, cy - bh), hi = Math.min(y2, cy + bh);
                int clear = argb(rgb, 0.0f), bright = argb(rgb, 0.85f);
                band(b, m, x1, z1, x2, z1, lo, cy, hi, clear, bright);
                band(b, m, x1, z2, x2, z2, lo, cy, hi, clear, bright);
                band(b, m, x1, z1, x1, z2, lo, cy, hi, clear, bright);
                band(b, m, x2, z1, x2, z2, lo, cy, hi, clear, bright);
                if (Config.bfOutline) edges(b, m, x1, y1, z1, x2, y2, z2, 0.010f, 1.0f, argb(rgb, 0.9f));
            }
            case 3 -> {   // Corners: пульсирующие уголки
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.08f + 0.10f * wave));
                edges(b, m, x1, y1, z1, x2, y2, z2, 0.014f, 0.16f + 0.18f * wave, argb(rgb, 0.95f));
            }
            default -> {  // Pulse: дышащая заливка + контур
                if (Config.bfFill) solid(b, m, x1, y1, z1, x2, y2, z2, argb(rgb, 0.10f + 0.22f * wave));
                if (Config.bfOutline) edges(b, m, x1, y1, z1, x2, y2, z2, 0.008f + 0.006f * wave, 1.0f, argb(rgb, 0.7f + 0.3f * wave));
            }
        }
        Ui.flush(b);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    // ------------------------------------------------------------ Aura

    private static void aura(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2,
                             double time, float wave, int rgb, int rgb2) {
        float h = y2 - y1;

        // внешнее свечение: несколько расширяющихся прозрачных оболочек
        if (Config.bfGlow) {
            float[] ex = {0.012f, 0.032f, 0.060f, 0.095f};
            float[] al = {0.10f, 0.055f, 0.03f, 0.014f};
            for (int k = ex.length - 1; k >= 0; k--) {
                float e = ex[k];
                solid(b, m, x1 - e, y1 - e, z1 - e, x2 + e, y2 + e, z2 + e, argb(rgb, al[k] * (0.7f + 0.6f * wave)));
            }
        }

        // грани: снизу почти прозрачные, сверху насыщенные (градиент между двумя цветами)
        if (Config.bfFill) {
            int bot = argb(rgb2, 0.03f);
            int top = argb(rgb, 0.22f + 0.12f * wave);
            sidesGrad(b, m, x1, y1, z1, x2, y2, z2, bot, top);
        }

        // рёбра
        if (Config.bfOutline) {
            edges(b, m, x1, y1, z1, x2, y2, z2, 0.0085f, 1.0f, argb(rgb, 0.55f + 0.25f * wave));
        }

        // бегущие огни по верхней и нижней рамке (в разные стороны)
        if (Config.bfOutline || Config.bfGlow) {
            float w = x2 - x1, d = z2 - z1;
            float per = 2.0f * (w + d);
            float head = (float) ((time * 0.45 % 1.0) * per);
            int n = 12;
            for (int i = 0; i < n; i++) {
                float a = 1.0f - i / (float) n;
                float[] p = rim(x1, z1, x2, z2, head - i * (per / 48.0f));
                float s = 0.028f * (0.6f + 0.4f * a);
                solid(b, m, p[0] - s, y2 - s, p[1] - s, p[0] + s, y2 + s, p[1] + s, argb(i == 0 ? 0xFFFFFF : rgb, a * a));
                float[] q = rim(x1, z1, x2, z2, per - head + i * (per / 48.0f));
                solid(b, m, q[0] - s, y1 - s, q[1] - s, q[0] + s, y1 + s, q[1] + s, argb(i == 0 ? 0xFFFFFF : rgb2, a * a));
            }
        }

        // искры поднимаются вокруг блока
        if (Config.bfSparks) {
            int count = 16;
            int spark = Ui.mix(0xFF000000 | rgb, 0xFFFFFFFF, 0.55f);
            for (int k = 0; k < count; k++) {
                float rx = fract((float) Math.sin(k * 12.9898) * 43758.547f);
                float rz = fract((float) Math.sin(k * 78.233) * 12345.678f);
                float rs = fract((float) Math.sin(k * 3.1 + 1.7) * 999.0f);
                float phase = (float) ((time * 0.35 + k / (float) count) % 1.0);
                float px = x1 - 0.12f + rx * ((x2 - x1) + 0.24f);
                float pz = z1 - 0.12f + rz * ((z2 - z1) + 0.24f);
                float py = y1 - 0.05f + phase * (h + 0.85f);
                float sz = 0.010f + 0.016f * rs;
                float al = (float) Math.sin(phase * Math.PI);
                solid(b, m, px - sz, py - sz, pz - sz, px + sz, py + sz, pz + sz, argb(spark, 0.95f * al));
            }
        }
    }

    /** Точка на периметре прямоугольника x1..x2 / z1..z2 на расстоянии d от угла. */
    private static float[] rim(float x1, float z1, float x2, float z2, float d) {
        float w = x2 - x1, l = z2 - z1;
        float per = 2.0f * (w + l);
        d = ((d % per) + per) % per;
        if (d < w) return new float[]{x1 + d, z1};
        d -= w;
        if (d < l) return new float[]{x2, z1 + d};
        d -= l;
        if (d < w) return new float[]{x2 - d, z2};
        d -= w;
        return new float[]{x1, z2 - d};
    }

    // ------------------------------------------------------------ примитивы

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int col) {
        b.vertex(m, x, y, z).color(col);
    }

    /** Четыре боковые грани с градиентом снизу вверх и верхняя грань цветом top. */
    private static void sidesGrad(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                                  float x2, float y2, float z2, int bot, int top) {
        v(b, m, x1, y1, z1, bot); v(b, m, x2, y1, z1, bot); v(b, m, x2, y2, z1, top); v(b, m, x1, y2, z1, top);
        v(b, m, x1, y1, z2, bot); v(b, m, x2, y1, z2, bot); v(b, m, x2, y2, z2, top); v(b, m, x1, y2, z2, top);
        v(b, m, x1, y1, z1, bot); v(b, m, x1, y1, z2, bot); v(b, m, x1, y2, z2, top); v(b, m, x1, y2, z1, top);
        v(b, m, x2, y1, z1, bot); v(b, m, x2, y1, z2, bot); v(b, m, x2, y2, z2, top); v(b, m, x2, y2, z1, top);
        v(b, m, x1, y2, z1, top); v(b, m, x2, y2, z1, top); v(b, m, x2, y2, z2, top); v(b, m, x1, y2, z2, top);
    }

    /** Закрашенный параллелепипед (6 граней). */
    private static void solid(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                              float x2, float y2, float z2, int c) {
        v(b, m, x1, y1, z1, c); v(b, m, x2, y1, z1, c); v(b, m, x2, y1, z2, c); v(b, m, x1, y1, z2, c);
        v(b, m, x1, y2, z1, c); v(b, m, x1, y2, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y2, z1, c);
        v(b, m, x1, y1, z1, c); v(b, m, x1, y2, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y1, z1, c);
        v(b, m, x1, y1, z2, c); v(b, m, x2, y1, z2, c); v(b, m, x2, y2, z2, c); v(b, m, x1, y2, z2, c);
        v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z2, c); v(b, m, x1, y2, z2, c); v(b, m, x1, y2, z1, c);
        v(b, m, x2, y1, z1, c); v(b, m, x2, y2, z1, c); v(b, m, x2, y2, z2, c); v(b, m, x2, y1, z2, c);
    }

    /** Полоса на вертикальной грани: снизу прозрачная, в центре яркая, сверху снова прозрачная. */
    private static void band(BufferBuilder b, Matrix4f m, float ax, float az, float bx, float bz,
                             float lo, float mid, float hi, int clear, int bright) {
        v(b, m, ax, lo, az, clear); v(b, m, bx, lo, bz, clear); v(b, m, bx, mid, bz, bright); v(b, m, ax, mid, az, bright);
        v(b, m, ax, mid, az, bright); v(b, m, bx, mid, bz, bright); v(b, m, bx, hi, bz, clear); v(b, m, ax, hi, az, clear);
    }

    /** 12 рёбер коробки толщиной t; frac < 1 даёт только уголки (по frac длины ребра с каждого конца). */
    private static void edges(BufferBuilder b, Matrix4f m, float x1, float y1, float z1,
                              float x2, float y2, float z2, float t, float frac, int c) {
        float[] ys = {y1, y2}, zs = {z1, z2}, xs = {x1, x2};
        for (float y : ys) {
            for (float z : zs) seg(b, m, x1, x2, y - t, y + t, z - t, z + t, 0, frac, c);
        }
        for (float x : xs) {
            for (float z : zs) seg(b, m, x - t, x + t, y1, y2, z - t, z + t, 1, frac, c);
        }
        for (float x : xs) {
            for (float y : ys) seg(b, m, x - t, x + t, y - t, y + t, z1, z2, 2, frac, c);
        }
    }

    private static void seg(BufferBuilder b, Matrix4f m, float x1, float x2, float y1, float y2, float z1, float z2,
                            int axis, float frac, int c) {
        if (frac >= 0.99f) {
            solid(b, m, x1, y1, z1, x2, y2, z2, c);
            return;
        }
        float len = axis == 0 ? x2 - x1 : axis == 1 ? y2 - y1 : z2 - z1;
        float d = Math.min(len * 0.5f, frac);
        if (axis == 0) {
            solid(b, m, x1, y1, z1, x1 + d, y2, z2, c);
            solid(b, m, x2 - d, y1, z1, x2, y2, z2, c);
        } else if (axis == 1) {
            solid(b, m, x1, y1, z1, x2, y1 + d, z2, c);
            solid(b, m, x1, y2 - d, z1, x2, y2, z2, c);
        } else {
            solid(b, m, x1, y1, z1, x2, y2, z1 + d, c);
            solid(b, m, x1, y1, z2 - d, x2, y2, z2, c);
        }
    }
}
