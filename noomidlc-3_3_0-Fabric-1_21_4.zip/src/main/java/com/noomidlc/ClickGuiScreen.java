package com.noomidlc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Меню мода в виде плавающих панелей-категорий.
 * ЛКМ по модулю - вкл/выкл, ПКМ - раскрыть настройки, ПКМ по заголовку - свернуть панель,
 * заголовок можно таскать, колесо мыши листает длинные панели.
 * Эффекты: фоновые частицы с линиями (отталкиваются от курсора), след курсора, волна от клика,
 * свечение включённых модулей, волна появления панелей, анимированная линия заголовка.
 */
public class ClickGuiScreen extends Screen {
    private static final int STRIDE = 22;   // шаг строк
    private static final int RH = 20;       // высота строки

    private static final int BORDER = 0xFF2C2C3A;
    private static final int BG = 0xF012121A;
    private static final int HEAD_BG = 0xF0181822;
    private static final int PANEL = 0xFF1E1E29;
    private static final int PANEL_HOVER = 0xFF2A2A38;
    private static final int OFF = 0xFF3C3C4C;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFF8E8E9F;

    private static final String[] TAB_NAMES = {"Visuals", "World", "Hands", "Combat", "Extra", "Misc", "HUD", "Style", "Colors"};

    // положение окна и выбранная вкладка запоминаются между открытиями
    private static int winDX = 0, winDY = 0;
    private static int selTab = 0;

    // фоновые частицы
    private static final class Dot { float x, y, vx, vy, r; }
    private final List<Dot> dots = new ArrayList<>();
    private final Random rnd = new Random();

    // след курсора и волны от кликов
    private final float[][] trail = new float[16][3];   // x, y, время появления (мс)
    private int trailN = 0;
    private float lastTx = -1, lastTy = -1;
    private final List<float[]> ripples = new ArrayList<>();   // x, y, время (мс)

    private final List<Hit> hits = new ArrayList<>();
    private Row dragging = null;
    private BindRow listening = null;

    private float openT = 0.0f;
    private long openAt = 0L;

    public ClickGuiScreen() {
        super(Text.literal("noomidls"));
    }

    private static final class Hit {
        Row row;
        Toggle parent;
        int x, y, w;
        int kind;      // 0 - список модулей, 1 - настройки, 2 - вкладка, 3 - шапка окна
        int tab;
    }

    // ------------------------------------------------------------ строки меню

    private abstract class Row {
        float hv = 0.0f;

        float hover(boolean in) {
            hv = Anim.step(hv, in ? 1.0f : 0.0f, 16.0f);
            return hv;
        }

        int height() { return STRIDE; }
        abstract void render(DrawContext c, int x, int y, int w, int mx, int my);
        boolean click(int x, int y, int w, double mx, double my) { return false; }
        void drag(double mx) {}
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        List<Row> settings = null;   // != null -> у модуля есть настройки (ПКМ раскрывает)
        boolean expanded = false;
        float ex = 0.0f;             // анимация раскрытия 0..1
        float knob = -1.0f;
        float pulse = 0.0f;          // вспышка при включении

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        Toggle with(Row... rows) {
            this.settings = new ArrayList<>(Arrays.asList(rows));
            return this;
        }

        int settingsHeight() {
            int h = 0;
            if (settings != null) for (Row r : settings) h += r.height();
            return h;
        }

        /** Один раз за кадр: двигает анимацию раскрытия. */
        void tickExpand() {
            if (settings != null) ex = Anim.step(ex, expanded ? 1.0f : 0.0f, 16.0f);
        }

        @Override
        int height() {
            if (settings == null) return STRIDE;
            return STRIDE + Math.round((settingsHeight() + 4) * ex);
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean on = get.getAsBoolean();
            if (knob < 0.0f) knob = on ? 1.0f : 0.0f;
            float prev = knob;
            knob = Anim.step(knob, on ? 1.0f : 0.0f, 14.0f);
            if (on && prev < 0.5f && knob >= 0.5f) pulse = 1.0f;
            pulse = Anim.smooth(pulse, 0.0f, 5.0f);
            float hv = hover(Ui.in(mx, my, x, y, w, RH));
            int accent = Config.accent();

            if (knob > 0.02f && Config.guiGlow) {
                for (int k = 3; k >= 1; k--) {
                    Ui.rrectF(c, x - k, y - k, w + k * 2, RH + k * 2, 7 + k,
                            Ui.alpha(accent, (0.06f + 0.10f * pulse) * knob / k));
                }
            }
            Ui.rrectF(c, x, y, w, RH, 6, Ui.mix(PANEL, PANEL_HOVER, hv));
            if (knob > 0.01f) {
                float fw = Math.max(RH * 0.7f, w * knob);
                int a2 = Ui.mix(accent, 0xFFFFFFFF, 0.18f + 0.3f * pulse);
                Ui.rrectF(c, x, y, fw, RH, 6, Ui.mix(Ui.alpha(accent, 0.0f), accent, Math.min(1.0f, knob * 1.4f)));
                Ui.rrectF(c, x, y, fw, RH / 2.0f, 6, Ui.alpha(a2, 0.35f * knob));
            }
            Ui.textMid(c, textRenderer, label, x + 9 + Math.round(2 * hv), y, RH,
                    Ui.mix(MUTED, 0xFFFFFFFF, Math.max(knob, hv * 0.6f)));

            if (settings != null) {
                // шеврон: поворачивается при раскрытии
                int cx = x + w - 11, cy = y + RH / 2;
                float rot = ex;
                for (int i = -2; i <= 2; i++) {
                    float off = Math.abs(i) * (1.0f - 2.0f * rot) * 0.9f;   // v -> ^ плавно
                    Ui.rrectF(c, cx + i * 1.4f - 0.7f, cy - 1.5f + off, 1.6f, 1.6f, 0.8f,
                            Ui.mix(MUTED, 0xFFFFFFFF, Math.max(knob, hv)));
                }
            }
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Cycle extends Row {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            String v = options[Math.floorMod(get.getAsInt(), options.length)];
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(Math.floorMod(get.getAsInt() + 1, options.length));
                return true;
            }
            return false;
        }
    }

    private class Slider extends Row {
        final String label;
        final float min, max;
        final String fmt;
        final Supplier<Float> get;
        final Consumer<Float> set;
        int trackX, trackW;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);

            String value = String.format(fmt, get.get());
            Ui.textMid(c, textRenderer, value, x + w - 12 - Ui.width(textRenderer, value), y, RH, MUTED);

            trackX = x + 58;
            trackW = Math.max(22, w - 58 - 46);
            float t = (get.get() - min) / (max - min);
            t = Math.max(0f, Math.min(1f, t));
            float fill = trackW * t;
            int ty = y + (RH - 4) / 2;
            Ui.capsuleF(c, trackX, ty, trackW, 4, OFF);
            if (fill > 0) Ui.capsuleF(c, trackX, ty, Math.max(4.0f, fill), 4, Config.accent());
            Ui.capsuleF(c, trackX + fill - 4, y + (RH - 8) / 2.0f, 8, 8, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, trackX - 6, y, trackW + 12, RH)) {
                drag(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            float t = (float) ((mx - trackX) / trackW);
            t = Math.max(0f, Math.min(1f, t));
            set.accept(min + t * (max - min));
        }
    }

    private class Button extends Row {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            float hv = hover(Ui.in(mx, my, x, y, w, RH));
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL_HOVER, Config.accent(), hv));
            int tw = Ui.width(textRenderer, label);
            Ui.textMid(c, textRenderer, label, x + (w - tw) / 2, y, RH, TEXT);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    /** Выбор клавиши / кнопки мыши. Клик -> нажми нужную кнопку. Esc = очистить. */
    private class BindRow extends Row {
        final String label;
        final IntSupplier get;
        final IntConsumer set;

        BindRow(String label, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        String name(int code) {
            if (code == -1) return "None";
            if (code <= -100) {
                int b = -100 - code;
                return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "Mouse " + (b + 1);
            }
            return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            boolean wait = listening == this;
            String v = wait ? "Press..." : name(get.getAsInt());
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, wait ? 0xFFFFFFFF : Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, wait ? 0xFF14141B : 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                listening = this;
                return true;
            }
            return false;
        }
    }

    private class Note extends Row {
        final String text;

        Note(String text) {
            this.text = text;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.textMid(c, textRenderer, text, x + 12, y, RH, MUTED);
        }
    }

    private class AccentPicker extends Row {
        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.mix(PANEL, PANEL_HOVER, hover(Ui.in(mx, my, x, y, w, RH))));
            Ui.textMid(c, textRenderer, "Accent color", x + 12, y, RH, TEXT);
            String name = Config.accentName();
            int nw = Ui.width(textRenderer, name);
            Ui.textMid(c, textRenderer, name, x + w - 12 - nw, y, RH, MUTED);
            Ui.capsule(c, x + w - 12 - nw - 16, y + (RH - 10) / 2, 10, 10, Config.accent());
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                Config.accent++;
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------ экран

    private Slider slider(String label, float min, float max, String fmt, Supplier<Float> g, Consumer<Float> s) {
        return new Slider(label, min, max, fmt, g, s);
    }

    private Toggle toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        return new Toggle(label, g, s);
    }

    /** Модуль из общего списка: включатель + настройки (ПКМ) с клавишей включения в конце. */
    private Toggle mod(String id, Row... rows) {
        Modules.Mod m = Modules.get(id);
        List<Row> all = new ArrayList<>(Arrays.asList(rows));
        all.add(new BindRow("Toggle key", () -> Config.bind(id), v -> Config.setBind(id, v)));
        Toggle t = new Toggle(m.label(), m.get(), m.set());
        t.settings = all;
        return t;
    }

    @Override
    protected void init() {
        List<List<Row>> pages = new ArrayList<>();
        listening = null;
        dragging = null;
        movingWin = false;

        // ---- Visuals
        List<Row> visuals = new ArrayList<>();
        visuals.add(mod("esp",
                new Cycle("Mode", new String[]{"Corners", "Glow", "Fancy", "3D Box", "Skeleton", "Neon"}, () -> Config.espMode, v -> Config.espMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.espColor, v -> Config.espColor = v),
                slider("Opacity", 0.2f, 1.0f, "%.2f", () -> Config.espOpacity, v -> Config.espOpacity = v),
                toggle("Mobs", () -> Config.espMobs, v -> Config.espMobs = v),
                toggle("Fill", () -> Config.espFill, v -> Config.espFill = v),
                toggle("Health bar", () -> Config.espHealth, v -> Config.espHealth = v),
                toggle("Name + distance", () -> Config.espName, v -> { Config.espName = v; Config.espDistance = v; }),
                toggle("Soft glow", () -> Config.espGlowLayer, v -> Config.espGlowLayer = v),
                toggle("Pulse", () -> Config.espPulse, v -> Config.espPulse = v),
                toggle("Tracers", () -> Config.espTracer, v -> Config.espTracer = v)));
        visuals.add(mod("seeinv",
                toggle("Players only", () -> Config.siPlayersOnly, v -> Config.siPlayersOnly = v)));
        visuals.add(mod("nametags",
                slider("Scale", 0.6f, 1.8f, "%.2f", () -> Config.ntScale, v -> Config.ntScale = v),
                slider("Background", 0.0f, 1.0f, "%.2f", () -> Config.ntBg, v -> Config.ntBg = v),
                toggle("Health", () -> Config.ntHealth, v -> Config.ntHealth = v),
                toggle("Distance", () -> Config.ntDistance, v -> Config.ntDistance = v),
                toggle("Potions", () -> Config.ntPotions, v -> Config.ntPotions = v)));
        visuals.add(mod("fullbright",
                new Note("Клиентское ночное зрение")));
        visuals.add(mod("itemphysics",
                slider("Spin", 0.0f, 3.0f, "%.1f", () -> Config.ipSpin, v -> Config.ipSpin = v)));
        visuals.add(mod("freecam",
                slider("Speed", 0.2f, 4.0f, "%.1f", () -> Config.fcSpeed, v -> Config.fcSpeed = Math.round(v * 10.0f) / 10.0f),
                new Note("WASD летаешь камерой, пробел вверх, Shift вниз, Ctrl быстрее. Персонаж стоит")));
        visuals.add(mod("fovchanger",
                slider("FOV", 30.0f, 160.0f, "%.0f", () -> Config.fovValue, v -> Config.fovValue = (float) Math.round(v))));
        pages.add(visuals);

        // ---- World
        List<Row> world = new ArrayList<>();
        world.add(mod("sky",
                new Cycle("Sky color", Config.SKY_MODES, () -> Config.skyMode, v -> Config.skyMode = v),
                slider("Hue", 0.0f, 1.0f, "%.2f", () -> Config.skyHue, v -> Config.skyHue = v),
                slider("Saturation", 0.0f, 1.0f, "%.2f", () -> Config.skySat, v -> Config.skySat = v),
                slider("Brightness", 0.3f, 1.2f, "%.2f", () -> Config.skyBright, v -> Config.skyBright = v),
                toggle("Horizon fog", () -> Config.skyFog, v -> Config.skyFog = v),
                toggle("Clouds", () -> Config.skyClouds, v -> Config.skyClouds = v),
                new Cycle("Time", Config.SKY_TIMES, () -> Config.skyTime, v -> Config.skyTime = v),
                slider("Timelapse speed", 0.2f, 10.0f, "%.1fx", () -> Config.skySpeed, v -> Config.skySpeed = Math.round(v * 10.0f) / 10.0f),
                new Note("Hue/Saturation - для режима Custom. Время меняется только у тебя на экране")));
        world.add(mod("stretch",
                slider("Width", 0.6f, 2.0f, "%.2f", () -> Config.stretchX, v -> Config.stretchX = Math.round(v * 100.0f) / 100.0f),
                slider("Height", 0.6f, 1.6f, "%.2f", () -> Config.stretchY, v -> Config.stretchY = Math.round(v * 100.0f) / 100.0f),
                new Note("Растянутое разрешение: 1.30 = как 4:3 на широком экране")));
        world.add(mod("ambient",
                new Cycle("Effect", Config.AM_MODES, () -> Config.amMode, v -> Config.amMode = v),
                new Cycle("Color", Config.AM_COLORS, () -> Config.amColor, v -> Config.amColor = v),
                slider("Amount", 30.0f, 600.0f, "%.0f", () -> Config.amCount, v -> Config.amCount = (float) Math.round(v)),
                slider("Size", 0.4f, 2.5f, "%.1f", () -> Config.amSize, v -> Config.amSize = Math.round(v * 10.0f) / 10.0f),
                new Note("Светлячки, снег, угольки, лепестки, пылинки в солнечном свете")));
        world.add(mod("cinematic",
                slider("Vignette", 0.0f, 1.0f, "%.2f", () -> Config.cvVignette, v -> Config.cvVignette = v),
                slider("Bars", 0.0f, 0.14f, "%.2f", () -> Config.cvBars, v -> Config.cvBars = Math.round(v * 100.0f) / 100.0f),
                new Cycle("Tint", Config.CV_TINTS, () -> Config.cvTint, v -> Config.cvTint = v),
                slider("Tint amount", 0.0f, 1.0f, "%.2f", () -> Config.cvTintAmount, v -> Config.cvTintAmount = v),
                new Note("Киношная картинка: виньетка, чёрные полосы, цветокоррекция")));
        world.add(mod("particles",
                new Cycle("Mode", Config.FX_MODES, () -> Config.fxMode, v -> Config.fxMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.fxColor, v -> Config.fxColor = v),
                slider("Amount", 0.3f, 3.0f, "%.1f", () -> Config.fxAmount, v -> Config.fxAmount = v),
                slider("Size", 0.4f, 2.5f, "%.1f", () -> Config.fxSize, v -> Config.fxSize = v),
                toggle("Other players", () -> Config.fxOthers, v -> Config.fxOthers = v)));
        world.add(mod("blockesp",
                slider("Range", 8.0f, 48.0f, "%.0f", () -> Config.beRange, v -> Config.beRange = (float) Math.round(v)),
                slider("Max blocks", 30.0f, 400.0f, "%.0f", () -> Config.beMax, v -> Config.beMax = (float) Math.round(v)),
                toggle("Ores", () -> Config.beOres, v -> Config.beOres = v),
                toggle("Only rare ores", () -> Config.beRare, v -> Config.beRare = v),
                toggle("Chests / barrels", () -> Config.beChests, v -> Config.beChests = v),
                toggle("Spawners", () -> Config.beSpawners, v -> Config.beSpawners = v),
                new Note("Рамки сквозь стены вокруг руд и сундуков")));
        world.add(mod("blockfx",
                new Cycle("Effect", Config.BF_MODES, () -> Config.bfMode, v -> Config.bfMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.bfColor, v -> Config.bfColor = v),
                slider("Speed", 0.3f, 3.0f, "%.1f", () -> Config.bfSpeed, v -> Config.bfSpeed = v),
                toggle("Glow", () -> Config.bfGlow, v -> Config.bfGlow = v),
                toggle("Sparks", () -> Config.bfSparks, v -> Config.bfSparks = v),
                toggle("Fill", () -> Config.bfFill, v -> Config.bfFill = v),
                toggle("Outline", () -> Config.bfOutline, v -> Config.bfOutline = v),
                new Note("Эффект на блоке, на который смотришь")));
        world.add(mod("jumpcircle",
                new Cycle("Color", Config.COLOR_MODES, () -> Config.jcColor, v -> Config.jcColor = v),
                slider("Radius", 0.8f, 3.5f, "%.1f", () -> Config.jcRadius, v -> Config.jcRadius = v),
                slider("Time", 0.4f, 2.5f, "%.1fs", () -> Config.jcDuration, v -> Config.jcDuration = v),
                toggle("Other players", () -> Config.jcOthers, v -> Config.jcOthers = v)));
        world.add(mod("wings3d",
                new Cycle("Style", Config.WING_STYLES, () -> Config.wgStyle, v -> Config.wgStyle = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.wgColor, v -> Config.wgColor = v),
                slider("Size", 0.5f, 2.0f, "%.2f", () -> Config.wgSize, v -> Config.wgSize = Math.round(v * 20.0f) / 20.0f),
                slider("Flap speed", 0.3f, 3.0f, "%.1f", () -> Config.wgSpeed, v -> Config.wgSpeed = Math.round(v * 10.0f) / 10.0f),
                slider("Feathers", 3.0f, 10.0f, "%.0f", () -> Config.wgFeathers, v -> Config.wgFeathers = (float) Math.round(v)),
                slider("Opacity", 0.2f, 1.0f, "%.2f", () -> Config.wgAlpha, v -> Config.wgAlpha = v),
                toggle("Other players", () -> Config.wgOthers, v -> Config.wgOthers = v),
                new Note("Видно в третьем лице (F5). Крылья машут сильнее в прыжке и полёте")));
        world.add(mod("cosmetics",
                toggle("Halo", () -> Config.cosHalo, v -> Config.cosHalo = v),
                toggle("Horns", () -> Config.cosHorns, v -> Config.cosHorns = v),
                toggle("Tail", () -> Config.cosTail, v -> Config.cosTail = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.cosColor, v -> Config.cosColor = v),
                toggle("Other players", () -> Config.cosOthers, v -> Config.cosOthers = v),
                new Note("Нимб, рожки и хвост на твоём персонаже. Видно в третьем лице (F5)")));
        world.add(mod("chinahat",
                new Cycle("Color", Config.COLOR_MODES, () -> Config.chColor, v -> Config.chColor = v),
                slider("Radius", 0.3f, 0.95f, "%.2f", () -> Config.chRadius, v -> Config.chRadius = v),
                slider("Height", 0.15f, 0.9f, "%.2f", () -> Config.chHeight, v -> Config.chHeight = v),
                slider("Opacity", 0.15f, 1.0f, "%.2f", () -> Config.chAlpha, v -> Config.chAlpha = v),
                toggle("Other players", () -> Config.chOthers, v -> Config.chOthers = v)));
        world.add(mod("fpsboost",
                toggle("Remove particles", () -> Config.fbNoParticles, v -> Config.fbNoParticles = v),
                toggle("No entity shadows", () -> Config.fbShadows, v -> Config.fbShadows = v),
                toggle("No clouds", () -> Config.fbClouds, v -> Config.fbClouds = v),
                toggle("Fast graphics", () -> Config.fbFastGfx, v -> Config.fbFastGfx = v),
                toggle("No biome blend", () -> Config.fbBlend, v -> Config.fbBlend = v),
                toggle("Entity distance 50%", () -> Config.fbEntDist, v -> Config.fbEntDist = v),
                toggle("Lite main menu", () -> Config.fbLiteMenu, v -> Config.fbLiteMenu = v),
                new Note("Меняет ванильные настройки графики, при выключении возвращает прежние")));
        world.add(mod("noparticles",
                toggle("Keep totem", () -> Config.npKeepTotem, v -> Config.npKeepTotem = v),
                toggle("Keep hit/crit", () -> Config.npKeepHit, v -> Config.npKeepHit = v),
                new Note("Ванильные частицы не создаются")));
        world.add(mod("nohurtcam",
                toggle("Also no bobbing", () -> Config.noBob, v -> Config.noBob = v)));
        world.add(mod("nofire",
                new Note("Огонь не закрывает экран")));
        pages.add(world);

        // ---- Hands
        List<Row> hands = new ArrayList<>();
        hands.add(mod("viewmodel",
                slider("X", -1.0f, 1.0f, "%.2f", () -> Config.vmX, v -> Config.vmX = v),
                slider("Y", -1.0f, 1.0f, "%.2f", () -> Config.vmY, v -> Config.vmY = v),
                slider("Z", -1.5f, 0.5f, "%.2f", () -> Config.vmZ, v -> Config.vmZ = v),
                slider("Scale", 0.3f, 1.5f, "%.2f", () -> Config.vmScale, v -> Config.vmScale = v),
                slider("Tilt X", -180.0f, 180.0f, "%.0f", () -> Config.vmRotX, v -> Config.vmRotX = (float) Math.round(v)),
                slider("Tilt Y", -180.0f, 180.0f, "%.0f", () -> Config.vmRotY, v -> Config.vmRotY = (float) Math.round(v)),
                slider("Tilt Z", -180.0f, 180.0f, "%.0f", () -> Config.vmRotZ, v -> Config.vmRotZ = (float) Math.round(v)),
                toggle("Hide offhand", () -> Config.vmHideOffhand, v -> Config.vmHideOffhand = v),
                new Button("Reset viewmodel", Config::resetViewModel)));
        hands.add(mod("swing",
                new Cycle("Style", Config.SWING_STYLES, () -> Config.swingStyle, v -> Config.swingStyle = v),
                slider("Speed", 2.0f, 20.0f, "%.0f", () -> Config.swingSpeed, v -> Config.swingSpeed = (float) Math.round(v)),
                slider("Angle", -60.0f, 60.0f, "%.0f", () -> Config.swingAngle, v -> Config.swingAngle = (float) Math.round(v)),
                toggle("Bounce", () -> Config.swingBounce, v -> Config.swingBounce = v),
                toggle("Mirror", () -> Config.swingMirror, v -> Config.swingMirror = v),
                toggle("Idle sway", () -> Config.swingSway, v -> Config.swingSway = v),
                slider("Hit scale", 0.5f, 1.6f, "%.2f", () -> Config.swingScale, v -> Config.swingScale = Math.round(v * 20.0f) / 20.0f),
                slider("Shift X", -0.6f, 0.6f, "%.2f", () -> Config.swingShiftX, v -> Config.swingShiftX = Math.round(v * 20.0f) / 20.0f),
                slider("Shift Y", -0.6f, 0.6f, "%.2f", () -> Config.swingShiftY, v -> Config.swingShiftY = Math.round(v * 20.0f) / 20.0f),
                slider("Shift Z", -0.6f, 0.6f, "%.2f", () -> Config.swingShiftZ, v -> Config.swingShiftZ = Math.round(v * 20.0f) / 20.0f)));
        pages.add(hands);

        // ---- Combat
        List<Row> combat = new ArrayList<>();
        combat.add(mod("killaura",
                slider("Range", 1.0f, 6.0f, "%.1fm", () -> Config.kaRange, v -> { float st = Config.KA_STEPS[Config.kaStepIdx]; Config.kaRange = Math.max(1.0f, Math.round(v / st) * st); }),
                new Cycle("Range step", Config.KA_STEP_NAMES, () -> Config.kaStepIdx, v -> { Config.kaStepIdx = v; float st = Config.KA_STEPS[v]; Config.kaRange = Math.max(1.0f, Math.round(Config.kaRange / st) * st); }),
                toggle("Target: players", () -> Config.kaPlayers, v -> Config.kaPlayers = v),
                toggle("Target: hostile mobs", () -> Config.kaMobs, v -> Config.kaMobs = v),
                toggle("Target: animals / villagers", () -> Config.kaAnimals, v -> Config.kaAnimals = v),
                toggle("Target: invisible", () -> Config.kaInvis, v -> Config.kaInvis = v),
                new BindRow("Select target key", () -> Config.kaLockBind, v -> Config.kaLockBind = v),
                toggle("Hit selected only", () -> Config.kaLockOnly, v -> Config.kaLockOnly = v),
                new Note("Клавиша: целься в игрока и нажми - он станет целью"),
                slider("Charge", 0.1f, 1.0f, "%.2f", () -> Config.kaCharge, v -> Config.kaCharge = v),
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.kaDelay, v -> Config.kaDelay = (float) Math.round(v)),
                slider("FOV", 30.0f, 360.0f, "%.0f", () -> Config.kaFov, v -> Config.kaFov = (float) Math.round(v)),
                slider("Turn speed", 2.0f, 60.0f, "%.0f", () -> Config.kaRotSpeed, v -> Config.kaRotSpeed = (float) Math.round(v)),
                slider("Smooth", 0.05f, 1.0f, "%.2f", () -> Config.kaSmooth, v -> Config.kaSmooth = v),
                new Cycle("Sort", Config.KA_SORTS, () -> Config.kaSort, v -> Config.kaSort = v),
                toggle("Rotate", () -> Config.kaRotate, v -> Config.kaRotate = v),
                toggle("Through walls", () -> Config.kaWalls, v -> Config.kaWalls = v),
                toggle("Swing hand", () -> Config.kaSwing, v -> Config.kaSwing = v),
                toggle("Crits only", () -> Config.kaCritsOnly, v -> Config.kaCritsOnly = v),
                toggle("Auto jump (for crits)", () -> Config.critJump, v -> Config.critJump = v),
                new Note("Crits only: бьёт только при падении, спринт на это время гасится"),
                toggle("Target mark", () -> Config.kaMark, v -> Config.kaMark = v)));
        combat.add(mod("legitaura",
                slider("Range", 2.0f, 3.5f, "%.1fm", () -> Config.laRange, v -> Config.laRange = Math.round(v * 10.0f) / 10.0f),
                slider("FOV", 30.0f, 360.0f, "%.0f", () -> Config.laFov, v -> Config.laFov = (float) Math.round(v)),
                slider("Smooth", 0.05f, 0.8f, "%.2f", () -> Config.laSmooth, v -> Config.laSmooth = v),
                toggle("Target: players", () -> Config.laPlayers, v -> Config.laPlayers = v),
                toggle("Target: hostile mobs", () -> Config.laMobs, v -> Config.laMobs = v),
                toggle("Crits only", () -> Config.laCrits, v -> Config.laCrits = v),
                toggle("Through walls", () -> Config.laWalls, v -> Config.laWalls = v),
                new Note("Бьёт только когда прицел реально на цели, обычный reach")));
        combat.add(mod("hitinfo",
                slider("Hold", 3.0f, 30.0f, "%.0fs", () -> Config.hiHold, v -> Config.hiHold = (float) Math.round(v)),
                toggle("Show name", () -> Config.hiName, v -> Config.hiName = v),
                toggle("Last hit", () -> Config.hiLast, v -> Config.hiLast = v),
                toggle("Healed (+)", () -> Config.hiHealed, v -> Config.hiHealed = v),
                toggle("Health bar", () -> Config.hiBar, v -> Config.hiBar = v),
                new Button("Reset stats", HitInfo::reset)));
        combat.add(mod("triggerbot",
                slider("Charge", 0.1f, 1.0f, "%.2f", () -> Config.tbCharge, v -> Config.tbCharge = v),
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.tbDelay, v -> Config.tbDelay = (float) Math.round(v)),
                toggle("Players only", () -> Config.tbPlayersOnly, v -> Config.tbPlayersOnly = v),
                new Cycle("Crits", TriggerBot.CRIT_MODES, () -> Config.tbCritMode, v -> Config.tbCritMode = v),
                new Note("Any - любые удары, Only crits - бьёт только в крите, No crits - бьёт только без крита")));
        combat.add(mod("autototem",
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.atDelay, v -> Config.atDelay = (float) Math.round(v)),
                slider("Health", 0.0f, 20.0f, "%.0f", () -> Config.atHealth, v -> Config.atHealth = (float) Math.round(v)),
                toggle("Only if offhand empty", () -> Config.atEmptyOnly, v -> Config.atEmptyOnly = v),
                new Note("Health 0 = тотем всегда в руке")));
        combat.add(mod("clickpearl",
                new BindRow("Throw key", () -> Config.cpBind, v -> Config.cpBind = v),
                toggle("Swing hand", () -> Config.cpSwing, v -> Config.cpSwing = v)));
        combat.add(mod("clickwind",
                new BindRow("Use key", () -> Config.cwBind, v -> Config.cwBind = v),
                toggle("Aim down", () -> Config.cwAimDown, v -> Config.cwAimDown = v),
                toggle("Swing hand", () -> Config.cwSwing, v -> Config.cwSwing = v)));
        combat.add(mod("projaim",
                slider("Range", 10.0f, 120.0f, "%.0fm", () -> Config.paRange, v -> Config.paRange = (float) Math.round(v)),
                slider("FOV", 10.0f, 180.0f, "%.0f", () -> Config.paFov, v -> Config.paFov = (float) Math.round(v)),
                slider("Smooth", 0.05f, 1.0f, "%.2f", () -> Config.paSmooth, v -> Config.paSmooth = v),
                toggle("Bow", () -> Config.paBow, v -> Config.paBow = v),
                toggle("Crossbow", () -> Config.paCrossbow, v -> Config.paCrossbow = v),
                toggle("Trident", () -> Config.paTrident, v -> Config.paTrident = v),
                toggle("Snowball / egg / pearl", () -> Config.paThrown, v -> Config.paThrown = v),
                toggle("Lead target (prediction)", () -> Config.paPredict, v -> Config.paPredict = v),
                toggle("Gravity drop", () -> Config.paGravity, v -> Config.paGravity = v),
                toggle("Only while drawing", () -> Config.paOnlyUse, v -> Config.paOnlyUse = v),
                toggle("Include mobs", () -> Config.paMobs, v -> Config.paMobs = v),
                toggle("Hit point marker", () -> Config.paMark, v -> Config.paMark = v)));
        combat.add(mod("aimassist",
                slider("Range", 2.0f, 8.0f, "%.1f", () -> Config.aaRange, v -> Config.aaRange = Math.round(v * 10.0f) / 10.0f),
                slider("FOV", 10.0f, 180.0f, "%.0f", () -> Config.aaFov, v -> Config.aaFov = (float) Math.round(v)),
                slider("Strength", 1.0f, 100.0f, "%.0f", () -> Config.aaSpeed, v -> Config.aaSpeed = (float) Math.round(v)),
                new Cycle("Aim at", AimAssist.AIMS, () -> Config.aaPart, v -> Config.aaPart = v),
                toggle("Only while attacking", () -> Config.aaClickOnly, v -> Config.aaClickOnly = v),
                toggle("Weapon only", () -> Config.aaWeaponOnly, v -> Config.aaWeaponOnly = v),
                toggle("Vertical", () -> Config.aaVertical, v -> Config.aaVertical = v),
                toggle("Include mobs", () -> Config.aaMobs, v -> Config.aaMobs = v),
                toggle("Humanize (noise)", () -> Config.aaRandom, v -> Config.aaRandom = v),
                toggle("FOV circle", () -> Config.aaCircle, v -> Config.aaCircle = v)));
        pages.add(combat);

        // ---- Extra
        List<Row> extra = new ArrayList<>();
        extra.add(mod("killfx",
                new Cycle("Effect", KillFx.MODES, () -> Config.kfMode, v -> Config.kfMode = v),
                new Cycle("Color", Config.COLOR_MODES, () -> Config.kfColor, v -> Config.kfColor = v),
                slider("Amount", 0.3f, 3.0f, "%.1f", () -> Config.kfAmount, v -> Config.kfAmount = v),
                slider("Size", 0.4f, 2.5f, "%.1f", () -> Config.kfSize, v -> Config.kfSize = v),
                toggle("Only my kills", () -> Config.kfMine, v -> Config.kfMine = v),
                toggle("Include mobs", () -> Config.kfMobs, v -> Config.kfMobs = v)));
        extra.add(toggle("ESP: 3D Box", () -> Config.esp && Config.espMode == 3, v -> { Config.esp = v || Config.esp; if (v) Config.espMode = 3; else if (Config.espMode == 3) Config.espMode = 2; }));
        extra.add(toggle("ESP: Skeleton", () -> Config.esp && Config.espMode == 4, v -> { Config.esp = v || Config.esp; if (v) Config.espMode = 4; else if (Config.espMode == 4) Config.espMode = 2; }));
        extra.add(toggle("ESP: Tracers", () -> Config.espTracer, v -> Config.espTracer = v));
        extra.add(toggle("Aim FOV circle", () -> Config.aaCircle, v -> Config.aaCircle = v));
        extra.add(toggle("Hit marker", () -> Config.exHitMarker, v -> Config.exHitMarker = v));
        extra.add(toggle("Combo counter", () -> Config.exCombo, v -> Config.exCombo = v));
        extra.add(toggle("Neon screen border", () -> Config.exBorder, v -> Config.exBorder = v));
        extra.add(slider("Border size", 0.5f, 2.0f, "%.1f", () -> Config.exBorderSize, v -> Config.exBorderSize = v));
        extra.add(toggle("Low HP warning", () -> Config.exLowHp, v -> Config.exLowHp = v));
        extra.add(new Note("Режимы ESP также в Visuals > ESP > Mode"));
        pages.add(extra);

        // ---- Misc
        List<Row> misc = new ArrayList<>();
        misc.add(mod("invmove",
                toggle("Arrow keys look", () -> Config.invArrows, v -> Config.invArrows = v),
                slider("Look speed", 0.5f, 10.0f, "%.1f", () -> Config.invLook, v -> Config.invLook = Math.round(v * 10.0f) / 10.0f),
                new Note("Ходишь, бегаешь и прыгаешь с открытым инвентарём. Не работает в наковальне и поиске креатива")));
        misc.add(mod("fly",
                slider("Speed", 0.1f, 3.0f, "%.2f", () -> Config.flySpeed, v -> Config.flySpeed = v),
                slider("Vertical", 0.1f, 2.0f, "%.2f", () -> Config.flyVert, v -> Config.flyVert = v),
                new Note("Пробел вверх, Shift вниз")));
        misc.add(mod("spider",
                slider("Speed", 0.1f, 0.8f, "%.2f", () -> Config.spiderSpeed, v -> Config.spiderSpeed = v),
                new Note("Лезешь вверх, упираясь в стену")));
        misc.add(mod("noweb",
                new Note("Паутина не замедляет")));
        misc.add(mod("airswim",
                slider("Speed", 0.1f, 1.5f, "%.2f", () -> Config.asSpeed, v -> Config.asSpeed = v),
                new Note("Плывёшь по воздуху туда, куда смотришь (W)")));
        misc.add(mod("airstuck",
                new Note("Замирает на месте в воздухе")));
        misc.add(mod("reach",
                slider("Range", 3.0f, 6.0f, "%.1f", () -> Config.reachRange, v -> Config.reachRange = Math.round(v * 10.0f) / 10.0f),
                new Note("Бьёшь дальше ванили (3.0). Сервер может не принять")));
        misc.add(mod("nofall",
                slider("Min fall", 1.0f, 3.0f, "%.1f", () -> Config.nfDistance, v -> Config.nfDistance = Math.round(v * 10.0f) / 10.0f),
                new Note("Урон от падения не проходит")));
        misc.add(mod("jesus",
                slider("Speed", 0.8f, 1.6f, "%.2f", () -> Config.jesusSpeed, v -> Config.jesusSpeed = v),
                toggle("Lava too", () -> Config.jesusLava, v -> Config.jesusLava = v),
                new Note("Ходишь по воде. Shift - нырнуть")));
        misc.add(mod("antiafk",
                slider("Interval (s)", 5.0f, 120.0f, "%.0f", () -> Config.afkInterval, v -> Config.afkInterval = (float) Math.round(v)),
                toggle("Rotate", () -> Config.afkRotate, v -> Config.afkRotate = v),
                toggle("Jump", () -> Config.afkJump, v -> Config.afkJump = v),
                toggle("Swing hand", () -> Config.afkSwing, v -> Config.afkSwing = v),
                new Note("Раз в Interval секунд делает действие, чтобы не кикало за AFK")));
        misc.add(mod("noclip",
                slider("Speed", 0.1f, 2.0f, "%.2f", () -> Config.ncSpeed, v -> Config.ncSpeed = v),
                slider("Vertical", 0.1f, 1.5f, "%.2f", () -> Config.ncVert, v -> Config.ncVert = v),
                new Note("Летишь сквозь блоки. Пробел вверх, Shift вниз")));
        misc.add(mod("autosprint",
                new Note("Держит бег при ходьбе вперёд")));
        misc.add(mod("autorespawn",
                slider("Delay", 0.0f, 40.0f, "%.0ft", () -> Config.arDelay, v -> Config.arDelay = (float) Math.round(v))));
        misc.add(mod("zoom",
                new BindRow("Zoom key", () -> Config.zoomBind, v -> Config.zoomBind = v),
                slider("Level", 1.5f, 10.0f, "%.1fx", () -> Config.zoomLevel, v -> Config.zoomLevel = v),
                toggle("Smooth", () -> Config.zoomSmooth, v -> Config.zoomSmooth = v)));
        misc.add(mod("autotool",
                toggle("Restore slot", () -> Config.atRestore, v -> Config.atRestore = v),
                new Note("Сам берёт лучший инструмент из хотбара при копании")));
        misc.add(mod("autoeat",
                slider("Eat at hunger", 4.0f, 19.0f, "%.0f", () -> Config.aeHunger, v -> Config.aeHunger = (float) Math.round(v)),
                new Note("Ест еду из хотбара, когда голод ниже порога")));
        misc.add(mod("autowalk",
                new Note("Сам идёт вперёд. Выключи, чтобы остановиться")));
        misc.add(mod("noweather",
                new Note("Убирает дождь и грозу у тебя на экране")));
        misc.add(mod("trails",
                new Cycle("Particle", NewMods.TRAIL_MODES, () -> Config.trMode, v -> Config.trMode = v),
                slider("Amount", 1.0f, 8.0f, "%.0f", () -> Config.trAmount, v -> Config.trAmount = (float) Math.round(v))));
        misc.add(mod("deathcoords",
                new Note("После смерти пишет координаты в чат (только тебе)")));
        misc.add(mod("invsort",
                new BindRow("Sort key", () -> Config.sortBind, v -> Config.sortBind = v),
                new Note("Открой инвентарь и нажми клавишу: сортирует основную часть")));
        misc.add(mod("reconnect",
                slider("Delay (s)", 1.0f, 60.0f, "%.0f", () -> Config.reconSec, v -> Config.reconSec = (float) Math.round(v)),
                new Note("Переподключается к серверу после кика/вылета")));
        misc.add(mod("chattime",
                toggle("24-hour", () -> Config.chatTime24, v -> Config.chatTime24 = v),
                new Note("Время у сообщений сервера (системные сообщения)")));
        misc.add(mod("notify",
                new Note("Всплывашки при включении/выключении модулей")));
        misc.add(mod("infopanel",
                toggle("Speed", () -> Config.ipSpeed, v -> Config.ipSpeed = v),
                toggle("Biome", () -> Config.ipBiome, v -> Config.ipBiome = v),
                toggle("Light level", () -> Config.ipLight, v -> Config.ipLight = v),
                toggle("Day counter", () -> Config.ipDay, v -> Config.ipDay = v),
                toggle("Session time", () -> Config.ipSession, v -> Config.ipSession = v),
                toggle("Memory", () -> Config.ipMemory, v -> Config.ipMemory = v),
                toggle("Server + players", () -> Config.ipServer, v -> Config.ipServer = v)));
        pages.add(misc);

        // ---- HUD
        List<Row> hud = new ArrayList<>();
        hud.add(toggle("HUD", () -> Config.hud, v -> Config.hud = v).with(
                slider("Size", 0.6f, 2.0f, "%.2fx", () -> Config.hudScale, v -> Config.hudScale = Math.round(v * 20.0f) / 20.0f),
                new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())),
                new Button("Reset HUD positions", Config::resetHud)));
        hud.add(toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v).with(
                toggle("FPS", () -> Config.hudFps, v -> Config.hudFps = v),
                toggle("Ping", () -> Config.hudPing, v -> Config.hudPing = v),
                toggle("Time", () -> Config.hudTime, v -> Config.hudTime = v)));
        hud.add(toggle("Module list", () -> Config.hudModuleList, v -> Config.hudModuleList = v).with(
                toggle("Dots", () -> Config.mlDots, v -> Config.mlDots = v)));
        hud.add(toggle("Coordinates", () -> Config.hudInfo, v -> Config.hudInfo = v).with(
                toggle("Facing (N/E/S/W)", () -> Config.hudFacing, v -> Config.hudFacing = v)));
        hud.add(toggle("Keystrokes", () -> Config.hudKeys, v -> Config.hudKeys = v).with(
                toggle("Space bar", () -> Config.ksSpace, v -> Config.ksSpace = v)));
        hud.add(toggle("Armor", () -> Config.hudArmor, v -> Config.hudArmor = v).with(
                toggle("Vertical", () -> Config.haVertical, v -> Config.haVertical = v),
                toggle("Durability bar", () -> Config.haDurability, v -> Config.haDurability = v)));
        hud.add(toggle("Target HUD", () -> Config.hudTarget, v -> Config.hudTarget = v));
        hud.add(toggle("Player Radar", () -> Config.hudRadar, v -> Config.hudRadar = v));
        hud.add(toggle("Compass HUD", () -> Config.hudCompass, v -> Config.hudCompass = v));
        hud.add(toggle("Dimension HUD", () -> Config.hudDimension, v -> Config.hudDimension = v));
        hud.add(toggle("Low Health Warning", () -> Config.lowHealthWarning, v -> Config.lowHealthWarning = v).with(
                slider("Health threshold", 2.0f, 16.0f, "%.0f HP",
                        () -> Config.lowHealthThreshold, v -> Config.lowHealthThreshold = v)));
        hud.add(toggle("Custom Crosshair", () -> Config.customCrosshair, v -> Config.customCrosshair = v).with(
                new Cycle("Style", Config.CROSSHAIR_STYLES, () -> Config.crosshairStyle, v -> Config.crosshairStyle = v),
                slider("Size", 2.0f, 14.0f, "%.0f", () -> Config.crosshairSize, v -> Config.crosshairSize = v),
                slider("Gap", 0.0f, 10.0f, "%.1f", () -> Config.crosshairGap, v -> Config.crosshairGap = v),
                slider("Thickness", 1.0f, 4.0f, "%.1f", () -> Config.crosshairThickness, v -> Config.crosshairThickness = v),
                toggle("Dynamic while sprinting", () -> Config.crosshairDynamic, v -> Config.crosshairDynamic = v)));
        hud.add(toggle("Potions", () -> Config.hudPotions, v -> Config.hudPotions = v).with(
                toggle("Timer", () -> Config.hpTimer, v -> Config.hpTimer = v)));
        hud.add(toggle("Item counters", () -> Config.hudCounts, v -> Config.hudCounts = v).with(
                toggle("Totems", () -> Config.ctTotem, v -> Config.ctTotem = v),
                toggle("Ender pearls", () -> Config.ctPearl, v -> Config.ctPearl = v),
                toggle("Wind charges", () -> Config.ctWind, v -> Config.ctWind = v)));
        pages.add(hud);

        // ---- Style
        List<Row> style = new ArrayList<>();
        style.add(new Cycle("Font", Config.FONT_NAMES, () -> Config.font, v -> Config.font = v));
        style.add(slider("Flow speed", 0.2f, 3.0f, "%.1fx", () -> Config.flowSpeed, v -> Config.flowSpeed = Math.round(v * 10.0f) / 10.0f));
        style.add(toggle("Custom main menu", () -> Config.customMenu, v -> Config.customMenu = v));
        style.add(toggle("Pet button (pet screen)", () -> Config.menuPet, v -> Config.menuPet = v));
        style.add(toggle("Title screen: noomidlc", () -> Config.customTitle, v -> Config.customTitle = v));
        style.add(toggle("Menu animations", () -> Config.uiAnim, v -> Config.uiAnim = v));
        style.add(toggle("Menu particles", () -> Config.guiParticles, v -> Config.guiParticles = v));
        style.add(toggle("Menu glow", () -> Config.guiGlow, v -> Config.guiGlow = v));
        style.add(toggle("Click ripple", () -> Config.guiRipple, v -> Config.guiRipple = v));
        style.add(toggle("Background fade", () -> Config.guiBlur, v -> Config.guiBlur = v));
        style.add(new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())));
        style.add(new Button("Reset HUD positions", Config::resetHud));
        pages.add(style);

        // Отдельная вкладка с выбором цвета всего интерфейса.
        List<Row> colors = new ArrayList<>();
        colors.add(new AccentPicker());
        colors.add(slider("Color flow speed", 0.2f, 3.0f, "%.1fx", () -> Config.flowSpeed,
                v -> Config.flowSpeed = Math.round(v * 10.0f) / 10.0f));
        colors.add(new Note("Click the color row to cycle 40 themes"));
        pages.add(colors);

        tabs = pages;
        selTab = Math.floorMod(selTab, tabs.size());
        selectFirstModule();
        scrollList = scrollListT = scrollSet = scrollSetT = 0.0f;

        // фоновые частицы
        dots.clear();
        int n = Math.max(30, Math.min(90, width * height / 9000));
        for (int i = 0; i < n; i++) {
            Dot d = new Dot();
            d.x = rnd.nextFloat() * width;
            d.y = rnd.nextFloat() * height;
            float a = rnd.nextFloat() * 6.2831f;
            float sp = 4.0f + rnd.nextFloat() * 10.0f;
            d.vx = (float) Math.cos(a) * sp;
            d.vy = (float) Math.sin(a) * sp;
            d.r = 0.8f + rnd.nextFloat() * 1.4f;
            dots.add(d);
        }
        openAt = System.currentTimeMillis();
        openT = 0.0f;
    }

    // ------------------------------------------------------------ рисование эффектов

    private static void line(DrawContext c, float ax, float ay, float bx, float by, int color) {
        float dx = bx - ax, dy = by - ay;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0f) return;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(ax, ay, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        Ui.rect(c, 0.0f, 0.0f, len, 1.0f / Ui.scale(), color);
        m.pop();
    }

    private void drawBackground(DrawContext c, int mx, int my) {
        int accent = Config.accent();
        if (Config.guiBlur) {
            int top = Ui.alpha(0x04040A, 0.62f * openT);
            int bot = Ui.alpha(Ui.mix(0xFF04040A, accent, 0.32f), 0.55f * openT);
            c.fillGradient(0, 0, width, height, top, bot);
        } else {
            c.fill(0, 0, width, height, Ui.alpha(0x000000, 0.4f * openT));
        }

        if (!Config.guiParticles) return;
        float dt = Math.min(0.05f, Anim.dt());
        for (Dot d : dots) {
            d.x += d.vx * dt;
            d.y += d.vy * dt;
            // отталкивание от курсора
            float ddx = d.x - mx, ddy = d.y - my;
            float dist2 = ddx * ddx + ddy * ddy;
            if (dist2 < 3600.0f && dist2 > 0.01f) {
                float dist = (float) Math.sqrt(dist2);
                float push = (1.0f - dist / 60.0f) * 140.0f * dt;
                d.x += ddx / dist * push;
                d.y += ddy / dist * push;
            }
            if (d.x < -4) d.x = width + 4;
            if (d.x > width + 4) d.x = -4;
            if (d.y < -4) d.y = height + 4;
            if (d.y > height + 4) d.y = -4;
        }
        // линии между близкими точками (и к курсору)
        for (int i = 0; i < dots.size(); i++) {
            Dot a = dots.get(i);
            for (int j = i + 1; j < dots.size(); j++) {
                Dot b = dots.get(j);
                float dx = a.x - b.x, dy = a.y - b.y;
                float d2 = dx * dx + dy * dy;
                if (d2 < 3200.0f) {
                    float k = 1.0f - (float) Math.sqrt(d2) / 56.5f;
                    line(c, a.x, a.y, b.x, b.y, Ui.alpha(accent, 0.30f * k * openT));
                }
            }
            float mdx = a.x - mx, mdy = a.y - my;
            float m2 = mdx * mdx + mdy * mdy;
            if (m2 < 10000.0f) {
                float k = 1.0f - (float) Math.sqrt(m2) / 100.0f;
                line(c, a.x, a.y, mx, my, Ui.alpha(0xFFFFFF, 0.28f * k * openT));
            }
        }
        for (Dot d : dots) {
            Ui.rrectF(c, d.x - d.r * 2, d.y - d.r * 2, d.r * 4, d.r * 4, d.r * 2, Ui.alpha(accent, 0.10f * openT));
            Ui.rrectF(c, d.x - d.r, d.y - d.r, d.r * 2, d.r * 2, d.r, Ui.alpha(0xFFFFFF, 0.7f * openT));
        }
    }

    private void drawTrailAndRipples(DrawContext c, int mx, int my) {
        long now = System.currentTimeMillis();
        int accent = Config.accent();

        if (lastTx < 0 || Math.abs(mx - lastTx) + Math.abs(my - lastTy) > 1.5f) {
            trail[trailN % trail.length][0] = mx;
            trail[trailN % trail.length][1] = my;
            trail[trailN % trail.length][2] = now;
            trailN++;
            lastTx = mx;
            lastTy = my;
        }
        for (float[] t : trail) {
            float age = (now - t[2]) / 420.0f;
            if (t[2] == 0 || age >= 1.0f) continue;
            float r = 3.2f * (1.0f - age);
            Ui.rrectF(c, t[0] - r, t[1] - r, r * 2, r * 2, r, Ui.alpha(accent, 0.5f * (1.0f - age)));
        }

        if (Config.guiRipple) {
            for (int i = ripples.size() - 1; i >= 0; i--) {
                float[] rp = ripples.get(i);
                float age = (now - rp[2]) / 600.0f;
                if (age >= 1.0f) {
                    ripples.remove(i);
                    continue;
                }
                float e = Anim.ease(age);
                float r = 4.0f + e * 46.0f;
                // кольцо: внешний светлый круг и внутренний, который "прогрызает" центр
                Ui.rrectF(c, rp[0] - r, rp[1] - r, r * 2, r * 2, r, Ui.alpha(accent, 0.28f * (1.0f - age)));
                Ui.rrectF(c, rp[0] - r + 1.5f, rp[1] - r + 1.5f, r * 2 - 3, r * 2 - 3, r - 1.5f,
                        Ui.alpha(0x0A0A12, 0.30f * (1.0f - age)));
            }
        }
    }

    // ------------------------------------------------------------ окно: сайдбар + список + настройки

    private static final int SB = 84;       // ширина сайдбара
    private static final int LISTW = 122;    // ширина списка модулей
    private static final int TOP = 34;       // шапка окна

    private List<List<Row>> tabs = new ArrayList<>();
    private Toggle selMod = null;
    private float scrollList = 0.0f, scrollListT = 0.0f, scrollSet = 0.0f, scrollSetT = 0.0f;
    private float indicator = -1.0f;
    private final float[] tabHv = new float[16];
    private boolean movingWin = false;
    private float winOffX, winOffY;
    private int wx, wy, ww, wh;
    // области текущего кадра (для мыши и прокрутки)
    private int listX, listY, listH, setX, setW;

    private void selectFirstModule() {
        selMod = null;
        for (Row r : tabs.get(selTab)) {
            if (r instanceof Toggle t && t.settings != null) {
                selMod = t;
                break;
            }
        }
    }

    private static int contentH(List<Row> rows) {
        int h = 4;
        for (Row r : rows) h += r.height();
        return h;
    }

    private void addHit(int kind, Row r, Toggle parent, int x, int y, int w, int tab) {
        Hit h = new Hit();
        h.kind = kind;
        h.row = r;
        h.parent = parent;
        h.x = x;
        h.y = y;
        h.w = w;
        h.tab = tab;
        hits.add(h);
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        Anim.frame();
        openT = Anim.step(openT, 1.0f, 12.0f);
        int accent = Config.accent();
        long now = System.currentTimeMillis();

        drawBackground(c, mouseX, mouseY);

        ww = MathHelper.clamp(width - 40, 340, 430);
        wh = MathHelper.clamp(height - 30, 218, 240);
        wx = MathHelper.clamp((width - ww) / 2 + winDX, 0, Math.max(0, width - ww));
        wy = MathHelper.clamp((height - wh) / 2 + winDY, 0, Math.max(0, height - wh));
        float e = Config.uiAnim ? Anim.ease(openT) : 1.0f;
        int y0 = wy + Math.round((1.0f - e) * 16.0f);
        hits.clear();

        // свечение, рамка, тело окна
        if (Config.guiGlow) {
            for (int k = 5; k >= 1; k--) {
                Ui.rrectF(c, wx - k * 2.0f, y0 - k * 2.0f, ww + k * 4.0f, wh + k * 4.0f, 12 + k * 2.0f,
                        Ui.alpha(accent, 0.04f * e));
            }
        }
        Ui.rrectF(c, wx - 1, y0 - 1, ww + 2, wh + 2, 13, BORDER);
        Ui.rrectF(c, wx, y0, ww, wh, 12, BG);

        // ---------- сайдбар
        Ui.rrectF(c, wx, y0, SB, wh, 12, 0xF00D0D14);
        Ui.rect(c, wx + SB - 12, y0, wx + SB, y0 + wh, 0xF00D0D14);
        Ui.rect(c, wx + SB, y0 + 8, wx + SB + 1, y0 + wh - 8, BORDER);

        String title = "noomidls";
        int tw = Ui.width(textRenderer, title);
        float tx = wx + (SB - tw) / 2.0f;
        for (int i = 0; i < title.length(); i++) {
            String ch = String.valueOf(title.charAt(i));
            float wave = 0.5f + 0.5f * (float) Math.sin(now / 350.0 - i * 0.6);
            Ui.textF(c, textRenderer, ch, tx, y0 + 12, Ui.mix(0xFFFFFFFF, accent, wave));
            tx += Ui.width(textRenderer, title.substring(0, i + 1)) - Ui.width(textRenderer, title.substring(0, i));
        }
        String ver = "dlc 2.6";
        Ui.textF(c, textRenderer, ver, wx + (SB - Ui.width(textRenderer, ver)) / 2.0f, y0 + 24, Ui.alpha(0xFFFFFF, 0.35f));

        int tabY = y0 + 38;
        int th = 20;
        int sbHover = -1;
        for (int i = 0; i < tabs.size(); i++) {
            int ty = tabY + i * (th + 2);
            boolean in = Ui.in(mouseX, mouseY, wx + 6, ty, SB - 12, th) && movingWin == false && dragging == null;
            if (in) sbHover = i;
            tabHv[i] = Anim.step(tabHv[i], in ? 1.0f : 0.0f, 16.0f);
            addHit(2, null, null, wx + 6, ty, SB - 12, i);
        }
        float targetInd = tabY + selTab * (th + 2);
        indicator = indicator < 0 ? targetInd : Anim.step(indicator, targetInd, 16.0f);
        // скользящая плашка выбранной вкладки
        Ui.rrectF(c, wx + 6, indicator, SB - 12, th, 8, Ui.alpha(accent, 0.22f));
        Ui.rrectF(c, wx + 6, indicator + 5, 3, th - 10, 1.5f, accent);
        for (int i = 0; i < tabs.size(); i++) {
            int ty = tabY + i * (th + 3);
            if (tabHv[i] > 0.01f && i != selTab) {
                Ui.rrectF(c, wx + 6, ty, SB - 12, th, 8, Ui.alpha(0xFFFFFF, 0.06f * tabHv[i]));
            }
            int on = 0;
            for (Row r : tabs.get(i)) if (r instanceof Toggle t && t.get.getAsBoolean()) on++;
            int col = i == selTab ? 0xFFFFFFFF : Ui.mix(MUTED, 0xFFFFFFFF, tabHv[i] * 0.7f);
            Ui.textMid(c, textRenderer, TAB_NAMES[i], wx + 16 + Math.round(2 * tabHv[i]), ty, th, col);
            if (on > 0) {
                String cnt = String.valueOf(on);
                int cw = Ui.width(textRenderer, cnt) + 8;
                Ui.capsule(c, wx + SB - 12 - cw, ty + 6, cw, th - 12, Ui.alpha(accent, 0.55f));
                Ui.textMid(c, textRenderer, cnt, wx + SB - 8 - cw + 4, ty, th, 0xFFFFFFFF);
            }
        }

        // ---------- шапка (за неё окно таскается)
        int cx0 = wx + SB + 1;
        int cw0 = ww - SB - 1;
        addHit(3, null, null, cx0, y0, cw0, 0);
        Ui.textMid(c, textRenderer, TAB_NAMES[selTab], cx0 + 12, y0, TOP, TEXT);
        String hint = "ЛКМ - вкл/выкл   ПКМ - настройки   колесо - прокрутка";
        Ui.textMid(c, textRenderer, hint, cx0 + cw0 - 12 - Ui.width(textRenderer, hint), y0, TOP, Ui.alpha(0xFFFFFF, 0.38f));
        int segs = 28;
        float sw = (cw0 - 24) / (float) segs;
        for (int i = 0; i < segs; i++) {
            float ph = 0.5f + 0.5f * (float) Math.sin(now / 600.0 + i * 0.3);
            Ui.rect(c, cx0 + 12 + i * sw, y0 + TOP - 2, cx0 + 12 + (i + 1) * sw + 0.5f, y0 + TOP - 1,
                    Ui.mix(Ui.alpha(accent, 0.15f), accent, ph));
        }

        // ---------- список модулей
        listX = cx0 + 10;
        listY = y0 + TOP + 6;
        listH = wh - TOP - 14;
        List<Row> rows = tabs.get(selTab);
        int content = contentH(rows);
        int maxScroll = Math.max(0, content - listH);
        scrollListT = MathHelper.clamp(scrollListT, 0, maxScroll);
        scrollList = Anim.step(scrollList, scrollListT, 18.0f);

        boolean overList = Ui.in(mouseX, mouseY, listX - 2, listY, LISTW + 4, listH) && !movingWin;
        c.enableScissor(listX - 4, listY, listX + LISTW + 4, listY + listH);
        int y = listY + 2 - Math.round(scrollList);
        for (Row r : rows) {
            int rowH = r.height();
            if (y + rowH > listY - 2 && y < listY + listH + 2) {
                if (r == selMod) {
                    Ui.rrectF(c, listX - 1.5f, y - 1.5f, LISTW + 3, RH + 3, 7.5f, Ui.alpha(accent, 0.55f));
                }
                r.render(c, listX, y, LISTW, overList ? mouseX : -10000, overList ? mouseY : -10000);
                addHit(0, r, null, listX, y, LISTW, 0);
            }
            y += rowH;
        }
        c.disableScissor();
        if (maxScroll > 0) {
            float thumb = Math.max(14.0f, listH * (listH / (float) content));
            float ty = listY + 2 + (listH - 4 - thumb) * (scrollList / maxScroll);
            Ui.rrectF(c, listX + LISTW + 2, ty, 2, thumb, 1, Ui.alpha(accent, 0.7f));
        }

        // ---------- настройки выбранного модуля
        setX = listX + LISTW + 12;
        setW = wx + ww - 10 - setX;
        Ui.rrectF(c, setX - 6, listY, setW + 12, listH, 9, Ui.alpha(0x000000, 0.25f));
        if (selMod == null || selMod.settings == null) {
            String m = "Выбери модуль слева";
            Ui.textF(c, textRenderer, m, setX + (setW - Ui.width(textRenderer, m)) / 2.0f, listY + listH / 2.0f - 4, Ui.alpha(0xFFFFFF, 0.35f));
        } else {
            Ui.textF(c, textRenderer, selMod.label + " - настройки", setX + 2, listY + 7, TEXT);
            Ui.rect(c, setX + 2, listY + 20, setX + setW - 2, listY + 21, Ui.alpha(accent, 0.45f));
            int sTop = listY + 26;
            int sH = listH - 28;
            int sContent = contentH(selMod.settings);
            int sMax = Math.max(0, sContent - sH);
            scrollSetT = MathHelper.clamp(scrollSetT, 0, sMax);
            scrollSet = Anim.step(scrollSet, scrollSetT, 18.0f);
            boolean overSet = Ui.in(mouseX, mouseY, setX - 6, sTop, setW + 12, sH) && !movingWin;

            c.enableScissor(setX - 6, sTop, setX + setW + 6, sTop + sH);
            int yy = sTop + 1 - Math.round(scrollSet);
            for (Row s2 : selMod.settings) {
                int rowH = s2.height();
                if (yy + rowH > sTop - 2 && yy < sTop + sH + 2) {
                    s2.render(c, setX, yy, setW, overSet ? mouseX : -10000, overSet ? mouseY : -10000);
                    addHit(1, s2, selMod, setX, yy, setW, 0);
                }
                yy += rowH;
            }
            c.disableScissor();
            if (sMax > 0) {
                float thumb = Math.max(14.0f, sH * (sH / (float) sContent));
                float ty = sTop + 2 + (sH - 4 - thumb) * (scrollSet / sMax);
                Ui.rrectF(c, setX + setW + 2, ty, 2, thumb, 1, Ui.alpha(accent, 0.7f));
            }
        }

        drawTrailAndRipples(c, mouseX, mouseY);

        String foot = "RShift - закрыть";
        Ui.textF(c, textRenderer, foot, (width - Ui.width(textRenderer, foot)) / 2.0f, height - 12 + (1.0f - openT) * 14, Ui.alpha(0xFFFFFF, 0.4f * openT));
    }

    // ------------------------------------------------------------ ввод

    /** Попадание с учётом видимой области (под прокруткой). */
    private Hit hitAt(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            switch (h.kind) {
                case 0 -> {
                    if (my < listY || my >= listY + listH) continue;
                    if (Ui.in(mx, my, h.x, h.y, h.w, RH)) return h;
                }
                case 1 -> {
                    if (my < listY + 26 || my >= listY + listH - 2) continue;
                    if (Ui.in(mx, my, h.x, h.y, h.w, RH)) return h;
                }
                case 2 -> {
                    if (Ui.in(mx, my, h.x, h.y, h.w, 24)) return h;
                }
                default -> {
                    if (Ui.in(mx, my, h.x, h.y, h.w, TOP)) return h;
                }
            }
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (listening != null) {
            listening.set.accept(-100 - button);
            listening = null;
            return true;
        }
        if (Config.guiRipple) {
            ripples.add(new float[]{(float) mouseX, (float) mouseY, System.currentTimeMillis()});
        }

        Hit h = hitAt(mouseX, mouseY);
        if (h == null) return true;

        switch (h.kind) {
            case 2 -> {
                if (button == 0 && h.tab != selTab) {
                    selTab = h.tab;
                    scrollListT = scrollList = 0.0f;
                    scrollSetT = scrollSet = 0.0f;
                    selectFirstModule();
                }
            }
            case 3 -> {
                if (button == 0) {
                    movingWin = true;
                    winOffX = (float) mouseX - wx;
                    winOffY = (float) mouseY - wy;
                }
            }
            case 0 -> {
                if (h.row instanceof Toggle t) {
                    if (t.settings != null && selMod != t) {
                        selMod = t;
                        scrollSetT = scrollSet = 0.0f;
                    }
                    if (button == 0 && t.click(h.x, h.y, h.w, mouseX, mouseY)) return true;
                } else if (button == 0 && h.row.click(h.x, h.y, h.w, mouseX, mouseY)) {
                    dragging = h.row;
                }
            }
            default -> {
                if (button == 0 && h.row.click(h.x, h.y, h.w, mouseX, mouseY)) dragging = h.row;
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mouseX);
            return true;
        }
        if (movingWin) {
            winDX = Math.round((float) mouseX - winOffX) - (width - ww) / 2;
            winDY = Math.round((float) mouseY - winOffY) - (height - wh) / 2;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        movingWin = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (Ui.in(mouseX, mouseY, setX - 6, listY, setW + 12, listH)) {
            scrollSetT -= (float) verticalAmount * 24.0f;
            return true;
        }
        if (Ui.in(mouseX, mouseY, listX - 4, listY, LISTW + 8, listH)) {
            scrollListT -= (float) verticalAmount * 24.0f;
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            listening.set.accept(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listening = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
