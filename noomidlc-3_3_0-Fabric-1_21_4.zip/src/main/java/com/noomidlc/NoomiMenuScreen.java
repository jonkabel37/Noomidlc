package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Главное меню noomidlc: анимированный фон со светлячками, гладкие скруглённые кнопки с подсветкой,
 * виртуальный питомец с крыльями (псевдо-3D: перья в несколько слоёв, сжатие по ширине при взмахе).
 */
public final class NoomiMenuScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Client Settings", "Quit Game"};
    private static final int[] PET_COLORS = {0xFFFFB86B, 0xFF7BDFF2, 0xFFB388FF, 0xFFFF8FAB, 0xFF8CE99A, 0xFFF1F1F1};

    private static final String[] ANIMALS = {"Cat", "Dog", "Bunny", "Fox", "Panda", "Dragon"};
    private static final String[] FOODS = {"Apple", "Fish", "Carrot", "Cookie", "Cake", "Bone"};
    private static final int[] FAV = {1, 5, 2, 0, 4, 3};   // любимая еда каждого зверя
    private static final String[] STYLES = {"None", "Bow", "Crown", "Shades", "Party", "Scarf", "Phones"};
    private final float[] foodHov = new float[FOODS.length];
    private final float[] pillHov = new float[4];
    private final List<float[]> notes = new ArrayList<>();    // x, y, vx, vy, жизнь, оттенок
    private float dance = 0.0f, noteT = 0.0f;
    private final float[] hov = new float[LABELS.length];
    private final float[] prs = new float[LABELS.length];
    private final float[][] pt = new float[70][5];            // x, y (0..1), скорость, размер, фаза
    private final List<float[]> hearts = new ArrayList<>();   // x, y, vx, vy, жизнь
    private final List<float[]> food = new ArrayList<>();     // x, y, vy, жизнь
    private final List<float[]> stars = new ArrayList<>();    // x, y, vx, vy, жизнь
    private float nextStar = 1.5f;
    private final long start = System.currentTimeMillis();

    private float petJump = 0.0f, petJumpV = 0.0f;
    private float blink = 0.0f, nextBlink = 2.5f;
    private float eat = 0.0f;
    private float feedHov = 0.0f, colorHov = 0.0f;
    private float flapBoost = 0.0f;
    private float lastSave = 0.0f;

    // отдельный экран питомца и новые эффекты меню
    private boolean petView = false;
    private float petFade = 0.0f, petBtnHov = 0.0f, petBackHov = 0.0f;
    private final List<float[]> fx = new ArrayList<>();       // x, y, vx, vy, жизнь, макс. жизнь, размер, оттенок, тип
    private float sparkAcc = 0.0f, lastMx = -1.0f, lastMy = -1.0f;
    private final float[][] orbs = new float[7][4];           // x, y (0..1), радиус, фаза

    // раскладка (считается каждый кадр)
    private int bw = 170, bh = 24, gap = 9, bx, top;
    private float px, py, groundY;

    public NoomiMenuScreen() {
        super(Text.literal("noomidlc"));
        Random r = new Random(7);
        for (float[] p : pt) {
            p[0] = r.nextFloat();
            p[1] = r.nextFloat();
            p[2] = 0.01f + r.nextFloat() * 0.03f;
            p[3] = 0.7f + r.nextFloat() * 1.4f;
            p[4] = r.nextFloat() * 6.28f;
        }
        for (float[] o : orbs) {
            o[0] = r.nextFloat();
            o[1] = r.nextFloat();
            o[2] = 60.0f + r.nextFloat() * 70.0f;
            o[3] = r.nextFloat() * 6.28f;
        }
    }

    /** Подмена ванильного TitleScreen нашим меню. Вызывается каждый тик. */
    public static void tick(MinecraftClient mc) {
        if (!Config.customMenu) return;
        Screen s = mc.currentScreen;
        if (s != null && s.getClass() == net.minecraft.client.gui.screen.TitleScreen.class) {
            mc.setScreen(new NoomiMenuScreen());
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    // ---------------------------------------------------------------- вспомогательное рисование

    private static void circle(DrawContext c, float cx, float cy, float r, int color) {
        Ui.rrectF(c, cx - r, cy - r, r * 2.0f, r * 2.0f, r, color);
    }

    private static int shade(int c, float k) {
        int a = (c >>> 24) & 255;
        int r = Math.min(255, Math.round(((c >> 16) & 255) * k));
        int g = Math.min(255, Math.round(((c >> 8) & 255) * k));
        int b = Math.min(255, Math.round((c & 255) * k));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void heart(DrawContext c, float x, float y, float s, int color) {
        MatrixStack m = c.getMatrices();
        circle(c, x - s * 0.5f, y - s * 0.25f, s * 0.55f, color);
        circle(c, x + s * 0.5f, y - s * 0.25f, s * 0.55f, color);
        m.push();
        m.translate(x, y + s * 0.15f, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(45.0f));
        Ui.rrectF(c, -s * 0.78f, -s * 0.78f, s * 1.56f, s * 1.56f, s * 0.2f, color);
        m.pop();
    }

    // ---------------------------------------------------------------- рендер

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Anim.frame();
        float dt = Anim.dt();
        float t = (System.currentTimeMillis() - start) / 1000.0f;
        int acc = Config.accent() | 0xFF000000;
        float intro = Anim.ease(Math.min(1.0f, t / 0.9f));
        petFade = Anim.smooth(petFade, petView ? 1.0f : 0.0f, 10.0f);
        float introM = intro * (1.0f - petFade);   // прозрачность главного меню (гаснет, когда открыт питомец)

        // фон
        ctx.fillGradient(0, 0, width, height, Ui.mix(0xFF0A0A14, acc, 0.10f), Ui.mix(0xFF050509, acc, 0.04f));
        for (int i = 0; i < 4; i++) {
            float x = width * (0.12f + 0.25f * i) + (float) Math.sin(t * 0.25f + i * 1.7f) * 50.0f;
            float w = 46.0f + 26.0f * (i % 2);
            ctx.fillGradient(Math.round(x), 0, Math.round(x + w), height, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.06f + 0.02f * (i % 2)));
        }
        ctx.fillGradient(0, Math.round(height * 0.55f), width, height, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.20f));

        // мягкий свет вслед за курсором
        for (int k = 4; k >= 1; k--) {
            circle(ctx, mx, my, 22.0f + k * 16.0f, Ui.alpha(acc, 0.018f * (5 - k) * intro));
        }

        // новые визуалы: большие мягкие шары и северное сияние
        if (Config.menuFx()) {
            drawOrbs(ctx, t, acc, intro);
            drawAurora(ctx, t, acc, intro);
        }

        // падающие звёзды
        nextStar -= dt;
        if (nextStar <= 0.0f) {
            nextStar = 1.8f + (float) Math.random() * 3.5f;
            float sx = (float) Math.random() * width * 0.9f;
            stars.add(new float[]{sx, -10.0f, 150.0f + (float) Math.random() * 90.0f, 110.0f + (float) Math.random() * 60.0f, 1.0f});
        }
        for (int i = stars.size() - 1; i >= 0; i--) {
            float[] st = stars.get(i);
            st[0] += st[2] * dt;
            st[1] += st[3] * dt;
            st[4] -= dt * 0.55f;
            if (st[4] <= 0.0f || st[1] > height + 20 || st[0] > width + 40) {
                stars.remove(i);
                continue;
            }
            float ln = (float) Math.sqrt(st[2] * st[2] + st[3] * st[3]);
            float ux = st[2] / ln, uy = st[3] / ln;
            for (int q = 0; q < 8; q++) {
                float a = (1.0f - q / 8.0f) * Math.min(1.0f, st[4] * 2.0f) * 0.85f * intro;
                circle(ctx, st[0] - ux * q * 4.0f, st[1] - uy * q * 4.0f, 1.9f - q * 0.15f, Ui.alpha(q == 0 ? 0xFFFFFFFF : acc, a));
            }
        }

        // светлячки с лёгким параллаксом от курсора
        float pxo = (mx - width / 2.0f) * 0.02f, pyo = (my - height / 2.0f) * 0.02f;
        for (float[] p : pt) {
            p[1] -= p[2] * dt;
            p[0] += (float) Math.sin(p[4] + t * 0.5f) * 0.00035f;
            if (p[1] < -0.02f) {
                p[1] = 1.02f;
            }
            float x = p[0] * width + pxo * p[3];
            float y = p[1] * height + pyo * p[3];
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.0f + p[4]);
            circle(ctx, x, y, p[3] * 2.4f, Ui.alpha(acc, 0.10f * tw * intro));
            circle(ctx, x, y, p[3] * 0.65f, Ui.alpha(0xFFFFFF, (0.25f + 0.55f * tw) * intro));
        }

        // раскладка
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        top = Math.round(height / 2.0f - total / 2.0f + 20.0f);
        bx = Math.round(width / 2.0f - bw / 2.0f);

        drawLogo(ctx, mc, t, acc, introM);

        // стеклянная панель под кнопками с переливающейся рамкой
        {
            float pw = bw + 44.0f, ph = total + 34.0f;
            float pxx = bx - 22.0f, pyy = top - 17.0f;
            float sh2 = 0.5f + 0.5f * (float) Math.sin(t * 1.2f);
            Ui.rrectF(ctx, pxx - 1, pyy - 1, pw + 2, ph + 2, 19, Ui.alpha(Ui.mix(acc, 0xFFFFFFFF, 0.35f * sh2), 0.22f * introM));
            Ui.rrectF(ctx, pxx, pyy, pw, ph, 18, Ui.alpha(0xFF0C0C16, 0.62f * introM));
            Ui.rrectF(ctx, pxx + 1, pyy + 1, pw - 2, 18, 17, Ui.alpha(0xFFFFFFFF, 0.04f * introM));
            // бегущий блик по верхней и нижней кромке панели
            float run = (float) ((t * 0.28f) % 1.0f);
            Ui.rrectF(ctx, pxx + 14 + run * (pw - 68), pyy - 1, 40, 2, 1, Ui.alpha(0xFFFFFFFF, 0.55f * introM));
            Ui.rrectF(ctx, pxx + 14 + (1.0f - run) * (pw - 68), pyy + ph - 1, 40, 2, 1, Ui.alpha(acc, 0.7f * introM));
        }

        // кнопки
        for (int i = 0; i < LABELS.length; i++) {
            float slide = 1.0f - Anim.ease(Math.max(0.0f, Math.min(1.0f, (t - 0.12f * i - 0.1f) / 0.55f)));
            float a = (1.0f - slide) * (1.0f - petFade);
            int x = bx - Math.round(slide * 36.0f);
            int y = top + i * (bh + gap);
            boolean over = !petView && Ui.in(mx, my, bx, y, bw, bh);
            if (over && Config.menuFx() && Math.random() < dt * 22.0f) {
                emit(bx + (float) Math.random() * bw, y + (float) Math.random() * bh,
                        ((float) Math.random() - 0.5f) * 20.0f, -14.0f - (float) Math.random() * 18.0f,
                        0.7f + (float) Math.random() * 0.5f, 1.1f + (float) Math.random() * 0.9f, (float) Math.random(), 1);
            }
            hov[i] = Anim.smooth(hov[i], over ? 1.0f : 0.0f, 14.0f);
            prs[i] = Anim.smooth(prs[i], 0.0f, 12.0f);
            drawButton(ctx, mc, LABELS[i], x, y, bw, bh, hov[i], prs[i], acc, a);
        }

        // кнопка питомца (отдельный экран)
        if (Config.menuPet) {
            float bxp = 14.0f, byp = height - 52.0f;
            boolean overP = !petView && Ui.in(mx, my, Math.round(bxp), Math.round(byp), 96, 30);
            petBtnHov = Anim.smooth(petBtnHov, overP ? 1.0f : 0.0f, 14.0f);
            drawPetButton(ctx, mc, bxp, byp, t, acc, introM);
        }

        // экран питомца
        if (Config.menuPet && petFade > 0.01f) {
            drawPetScreen(ctx, mc, mx, my, t, dt, acc, petFade);
        }

        // частицы: фоновые искры, хвост за курсором, вспышки от кликов
        if (Config.menuFx()) {
            sparkAcc += dt * 16.0f;
            while (sparkAcc >= 1.0f) {
                sparkAcc -= 1.0f;
                emit((float) Math.random() * width, height * (0.3f + (float) Math.random() * 0.8f),
                        ((float) Math.random() - 0.5f) * 8.0f, -8.0f - (float) Math.random() * 16.0f,
                        2.2f + (float) Math.random() * 2.5f, 1.2f + (float) Math.random() * 1.6f, (float) Math.random(), 1);
            }
            if (lastMx >= 0.0f && Math.hypot(mx - lastMx, my - lastMy) > 2.0f) {
                for (int i = 0; i < 2; i++) {
                    emit(mx, my, ((float) Math.random() - 0.5f) * 22.0f, ((float) Math.random() - 0.5f) * 22.0f,
                            0.45f + (float) Math.random() * 0.4f, 1.0f + (float) Math.random() * 1.0f, (float) Math.random(), 0);
                }
            }
            lastMx = mx;
            lastMy = my;
        }
        drawFx(ctx, dt, acc, intro);

        // время и дата
        LocalDateTime now = LocalDateTime.now();
        String clock = now.format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT));
        String date = now.format(DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.ROOT));
        MatrixStack cm = ctx.getMatrices();
        cm.push();
        cm.translate(width - 10.0f, 10.0f, 0.0f);
        cm.scale(1.8f, 1.8f, 1.0f);
        Ui.textF(ctx, mc.textRenderer, clock, -Ui.width(mc.textRenderer, clock), 0, Ui.alpha(0xFFFFFF, 0.9f * introM));
        cm.pop();
        Ui.textF(ctx, mc.textRenderer, date, width - 10.0f - Ui.width(mc.textRenderer, date), 26.0f, Ui.alpha(acc, 0.8f * introM));

        // подпись
        String ver = "noomidlc 3.3.0  |  Fabric 1.21.4";
        Ui.textF(ctx, mc.textRenderer, ver, 6, height - 12, Ui.alpha(0xFFFFFF, 0.35f * introM));
    }

    private void drawLogo(DrawContext c, MinecraftClient mc, float t, int acc, float intro) {
        String text = "noomidlc";
        float scale = 3.4f;
        int w = Ui.width(mc.textRenderer, text);
        float cx = width / 2.0f;
        float y = Math.max(10.0f, top - 74.0f);
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(cx, y, 0.0f);
        m.scale(scale, scale, 1.0f);
        for (int i = 4; i >= 1; i--) {
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f - i * 0.45f, 0, Ui.alpha(acc, 0.07f * intro));
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f + i * 0.45f, 0, Ui.alpha(acc, 0.07f * intro));
        }
        float pulse = 0.88f + 0.12f * (float) Math.sin(t * 2.0f);
        Ui.textF(c, mc.textRenderer, text, -w / 2.0f, 0, Ui.alpha(0xFFFFFF, intro * pulse));
        m.pop();
        float lw = w * scale;
        float ly = y + 11.0f * scale + 3.0f;
        float sweep = (float) ((t * 0.5) % 1.0);
        Ui.rrectF(c, cx - lw / 2.0f, ly, lw, 2.0f, 1.0f, Ui.alpha(acc, 0.55f * intro));
        Ui.rrectF(c, cx - lw / 2.0f + sweep * (lw - 30.0f), ly, 30.0f, 2.0f, 1.0f, Ui.alpha(0xFFFFFF, 0.9f * intro));
        // огоньки, облетающие логотип по эллипсу
        if (Config.menuFx() && intro > 0.02f) {
            float ocy = y + 5.5f * scale;
            for (int d = 0; d < 5; d++) {
                for (int q = 0; q < 6; q++) {
                    float ang = t * 1.1f + d * 1.2566f - q * 0.07f;
                    float ox = cx + (float) Math.cos(ang) * (lw / 2.0f + 26.0f);
                    float oy = ocy + (float) Math.sin(ang) * 20.0f;
                    float k = 1.0f - q / 6.0f;
                    circle(c, ox, oy, 2.4f * k + 0.4f, Ui.alpha(q == 0 ? 0xFFFFFFFF : acc, 0.75f * k * intro));
                }
            }
        }
    }

    // ---------------------------------------------------------------- новые визуалы

    /** Большие мягкие светящиеся шары, медленно плывущие по фону. */
    private void drawOrbs(DrawContext c, float t, int acc, float intro) {
        for (int i = 0; i < orbs.length; i++) {
            float[] o = orbs[i];
            float x = o[0] * width + (float) Math.sin(t * 0.17f + o[3]) * 60.0f;
            float y = o[1] * height + (float) Math.cos(t * 0.13f + o[3] * 1.3f) * 40.0f;
            int col = Ui.mix(acc, i % 2 == 0 ? 0xFF7BDFF2 : 0xFFFF8FAB, 0.35f);
            for (int k = 6; k >= 1; k--) {
                circle(c, x, y, o[2] * k / 6.0f, Ui.alpha(col, 0.012f * intro));
            }
        }
    }

    /** Северное сияние: волнистые светящиеся полосы в верхней части экрана. */
    private void drawAurora(DrawContext c, float t, int acc, float intro) {
        int step = 8;
        int[] cols = {acc, Ui.mix(acc, 0xFF7BDFF2, 0.7f), Ui.mix(acc, 0xFFFF8FAB, 0.6f)};
        for (int b = 0; b < cols.length; b++) {
            for (int x = 0; x < width; x += step) {
                float w1 = (float) Math.sin(x * 0.008f + t * 0.35f + b * 2.1f);
                float w2 = (float) Math.sin(x * 0.019f - t * 0.55f + b);
                float yc = height * (0.20f + 0.09f * b) + w1 * height * 0.06f + w2 * 8.0f;
                float amp = 0.5f + 0.5f * (float) Math.sin(x * 0.004f + t * 0.3f + b * 1.7f);
                float a = (0.020f + 0.030f * amp) * intro;
                c.fillGradient(x, Math.round(yc - 34), x + step, Math.round(yc), Ui.alpha(cols[b], 0.0f), Ui.alpha(cols[b], a));
                c.fillGradient(x, Math.round(yc), x + step, Math.round(yc + 26), Ui.alpha(cols[b], a), Ui.alpha(cols[b], 0.0f));
            }
        }
    }

    /** Добавляет частицу. Типы: 0 - светящаяся точка, 1 - искра-звёздочка, 2 - вспышка с гравитацией. */
    private void emit(float x, float y, float vx, float vy, float life, float size, float hue, int kind) {
        if (fx.size() > 700) return;
        fx.add(new float[]{x, y, vx, vy, life, life, size, hue, kind});
    }

    private void drawFx(DrawContext c, float dt, int acc, float intro) {
        for (int i = fx.size() - 1; i >= 0; i--) {
            float[] f = fx.get(i);
            f[4] -= dt;
            if (f[4] <= 0.0f) {
                fx.remove(i);
                continue;
            }
            if ((int) f[8] == 2) f[3] += 90.0f * dt;
            f[0] += f[2] * dt;
            f[1] += f[3] * dt;
            float k = f[4] / f[5];
            float fade = Math.min(1.0f, k * 2.5f) * Math.min(1.0f, (1.0f - k) * 6.0f + 0.2f) * intro;
            int col = Ui.mix(Ui.mix(acc, 0xFF7BDFF2, f[7]), 0xFFFFFFFF, 0.3f);
            if ((int) f[8] == 1) {
                float tw = 0.6f + 0.4f * (float) Math.sin(f[4] * 9.0f + f[7] * 6.28f);
                float L = f[6] * 2.6f * tw;
                Ui.rrectF(c, f[0] - L, f[1] - 0.5f, L * 2.0f, 1.0f, 0.5f, Ui.alpha(col, 0.85f * fade));
                Ui.rrectF(c, f[0] - 0.5f, f[1] - L, 1.0f, L * 2.0f, 0.5f, Ui.alpha(col, 0.85f * fade));
                circle(c, f[0], f[1], f[6] * 1.8f, Ui.alpha(col, 0.14f * fade));
                circle(c, f[0], f[1], f[6] * 0.6f, Ui.alpha(0xFFFFFFFF, 0.9f * fade));
            } else {
                circle(c, f[0], f[1], f[6] * 2.6f, Ui.alpha(col, 0.12f * fade));
                circle(c, f[0], f[1], f[6], Ui.alpha(col, 0.85f * fade));
            }
        }
    }

    /** Круглая кнопка с лапкой слева внизу: открывает экран питомца. */
    private void drawPetButton(DrawContext c, MinecraftClient mc, float x, float y, float t, int acc, float a) {
        float h = petBtnHov;
        float w = 96.0f, hh = 30.0f;
        for (int k = 5; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.6f, y - k * 1.6f, w + k * 3.2f, hh + k * 3.2f, 15 + k * 1.6f,
                    Ui.alpha(acc, (0.02f + 0.05f * h) * (6 - k) / 5.0f * a));
        }
        Ui.rrectF(c, x - 1, y - 1, w + 2, hh + 2, 16, Ui.alpha(acc, (0.35f + 0.5f * h) * a));
        Ui.rrectF(c, x, y, w, hh, 15, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, h), 0.94f * a));
        // лапка: подушечка и четыре пальца (рисунок собственный)
        float cx = x + 16.0f, cy = y + 16.0f - h * 1.0f + (float) Math.sin(t * 2.4f) * 0.6f;
        int pc = Ui.alpha(Ui.mix(0xFFFFB86B, 0xFFFFFFFF, h * 0.4f), a);
        circle(c, cx, cy + 3.0f, 4.6f, pc);
        circle(c, cx - 5.6f, cy - 2.2f, 2.1f, pc);
        circle(c, cx - 2.0f, cy - 5.6f, 2.1f, pc);
        circle(c, cx + 2.0f, cy - 5.6f, 2.1f, pc);
        circle(c, cx + 5.6f, cy - 2.2f, 2.1f, pc);
        String label = "Pet  Lv " + (1 + Config.petXp / 25);
        Ui.textMidF(c, mc.textRenderer, label, x + 30.0f, y, hh, Ui.alpha(Ui.mix(0xFFD8D8E4, 0xFFFFFFFF, h), a));
    }

    /** Отдельный экран питомца: стеклянная панель, свечение под питомцем, кнопка Back. */
    private void drawPetScreen(DrawContext c, MinecraftClient mc, int mx, int my, float t, float dt, int acc, float pf) {
        px = width / 2.0f;
        py = height / 2.0f - 6.0f;
        groundY = py + 36.0f;
        float pw = 300.0f, ph = 252.0f;
        float pxx = px - pw / 2.0f, pyy = py - 112.0f;
        float rise = (1.0f - pf) * 14.0f;
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(0.0f, rise, 0.0f);
        float sh = 0.5f + 0.5f * (float) Math.sin(t * 1.3f);
        for (int k = 6; k >= 1; k--) {
            Ui.rrectF(c, pxx - k * 2.0f, pyy - k * 2.0f, pw + k * 4.0f, ph + k * 4.0f, 22 + k * 2.0f,
                    Ui.alpha(acc, 0.018f * (7 - k) / 6.0f * pf));
        }
        Ui.rrectF(c, pxx - 1, pyy - 1, pw + 2, ph + 2, 23, Ui.alpha(Ui.mix(acc, 0xFFFFFFFF, 0.35f * sh), 0.3f * pf));
        Ui.rrectF(c, pxx, pyy, pw, ph, 22, Ui.alpha(0xFF0C0C16, 0.80f * pf));
        Ui.rrectF(c, pxx + 1, pyy + 1, pw - 2, 22, 21, Ui.alpha(0xFFFFFFFF, 0.04f * pf));
        float run = (float) ((t * 0.3f) % 1.0f);
        Ui.rrectF(c, pxx + 16 + run * (pw - 72), pyy - 1, 40, 2, 1, Ui.alpha(0xFFFFFFFF, 0.6f * pf));

        // заголовок
        String title = "My Pet";
        int tw = Ui.width(mc.textRenderer, title);
        m.push();
        m.translate(px, pyy + 10.0f, 0.0f);
        m.scale(1.5f, 1.5f, 1.0f);
        Ui.textF(c, mc.textRenderer, title, -tw / 2.0f, 0, Ui.alpha(0xFFFFFF, 0.95f * pf));
        m.pop();

        // сияние под питомцем
        for (int k = 5; k >= 1; k--) {
            Ui.rrectF(c, px - 30.0f - k * 8.0f, groundY + 2.0f - k * 1.5f, 60.0f + k * 16.0f, 12.0f + k * 3.0f, 6.0f + k * 1.5f,
                    Ui.alpha(acc, 0.028f * (6 - k) / 5.0f * pf));
        }

        drawPetArea(c, mc, mx, my, t, dt, acc, pf);
        m.pop();

        // кнопка Back
        float bkx = pxx + 12.0f, bky = pyy + 10.0f + rise;
        boolean overB = Ui.in(mx, my, Math.round(bkx), Math.round(bky), 44, 16);
        petBackHov = Anim.smooth(petBackHov, overB ? 1.0f : 0.0f, 14.0f);
        smallPill(c, mc, "Back", bkx, bky, 44, 16, petBackHov, acc, pf);

        // искры вокруг питомца, чем лучше настроение - тем их больше
        if (Config.menuFx() && Math.random() < dt * (3.0f + Config.petMood * 0.12f)) {
            float ang = (float) (Math.random() * Math.PI * 2.0);
            float rr = 34.0f + (float) Math.random() * 40.0f;
            emit(px + (float) Math.cos(ang) * rr, py + 4.0f + (float) Math.sin(ang) * rr * 0.7f,
                    (float) Math.cos(ang) * 6.0f, -10.0f - (float) Math.random() * 12.0f,
                    1.0f + (float) Math.random() * 0.8f, 1.0f + (float) Math.random() * 1.2f, (float) Math.random(), 1);
        }
    }

    private void drawButton(DrawContext c, MinecraftClient mc, String label, int x, int y, int w, int h,
                            float hover, float press, int acc, float a) {
        float lift = hover * 1.5f;
        float yy = y - lift + press * 1.0f;
        float r = h / 2.0f;
        // подсветка вокруг кнопки
        for (int k = 5; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.6f, yy - k * 1.6f, w + k * 3.2f, h + k * 3.2f, r + k * 1.6f,
                    Ui.alpha(acc, (0.020f + 0.040f * hover) * (6 - k) / 5.0f * a));
        }
        // обводка и тело
        Ui.rrectF(c, x - 1, yy - 1, w + 2, h + 2, r + 1, Ui.alpha(acc, (0.35f + 0.55f * hover) * a));
        Ui.rrectF(c, x, yy, w, h, r, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, hover), 0.94f * a));
        Ui.rrectF(c, x + 1, yy + 1, w - 2, h * 0.5f, r - 1, Ui.alpha(0xFFFFFF, (0.05f + 0.06f * hover) * a));
        // полоска блика при наведении
        if (hover > 0.01f) {
            float sw = (float) ((System.currentTimeMillis() % 1400L) / 1400.0);
            float sx = x + 8 + sw * (w - 30);
            Ui.rrectF(c, sx, yy + 3, 14, h - 6, 3, Ui.alpha(0xFFFFFF, 0.06f * hover * a));
        }
        int tw = Ui.width(mc.textRenderer, label);
        Ui.textMidF(c, mc.textRenderer, label, x + (w - tw) / 2.0f, yy, h, Ui.alpha(Ui.mix(0xFFD8D8E4, 0xFFFFFFFF, hover), a));
    }

    // ---------------------------------------------------------------- питомец

    private void drawPetArea(DrawContext c, MinecraftClient mc, int mx, int my, float t, float dt, int acc, float intro) {
        // физика прыжка
        petJump += petJumpV * dt;
        petJumpV -= 520.0f * dt;
        if (petJump < 0.0f) {
            petJump = 0.0f;
            petJumpV = 0.0f;
        }
        flapBoost = Anim.smooth(flapBoost, petJump > 0.5f ? 1.0f : 0.0f, 8.0f);
        eat = Math.max(0.0f, eat - dt);
        if (dance > 0.0f) {
            dance = Math.max(0.0f, dance - dt);
            noteT -= dt;
            if (noteT <= 0.0f) {
                noteT = 0.22f;
                notes.add(new float[]{px + ((float) Math.random() - 0.5f) * 34.0f, py - 30.0f,
                        ((float) Math.random() - 0.5f) * 16.0f, -26.0f - (float) Math.random() * 12.0f, 1.3f, (float) Math.random()});
            }
        }

        // моргание
        nextBlink -= dt;
        if (nextBlink <= 0.0f) {
            blink = 0.16f;
            nextBlink = 2.0f + (float) Math.random() * 3.0f;
        }
        blink = Math.max(0.0f, blink - dt);

        // настроение медленно падает
        Config.petMood = Math.max(0.0f, Config.petMood - dt * 0.35f);

        int type = Math.floorMod(Config.petType, ANIMALS.length);
        int col = PET_COLORS[Math.floorMod(Config.petColor, PET_COLORS.length)];
        if (type == 4) col = 0xFFF2F2F2;   // панда всегда чёрно-белая
        float bob = (float) Math.sin(t * 2.2f) * 3.0f;
        float bx0 = px, by0 = py + bob - petJump - (dance > 0.0f ? Math.abs((float) Math.sin(t * 9.0f)) * 7.0f : 0.0f);
        float sc = 1.0f + (petJump > 0.5f ? 0.04f : 0.0f);

        // тень на земле
        float shw = 40.0f - petJump * 0.15f - bob * 0.5f;
        Ui.rrectF(c, px - shw / 2.0f, groundY + 6, shw, 6, 3, Ui.alpha(0xFF000000, 0.35f * intro));

        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(bx0, by0, 0.0f);
        m.scale(sc, sc, 1.0f);
        if (dance > 0.0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.sin(t * 9.0f) * 7.0f));

        drawTail(c, type, col, t);
        drawEars(c, type, col);
        // ноги
        int feet = type == 4 ? 0xFF26262E : shade(col, 0.82f);
        Ui.rrectF(c, -14, 18, 11, 7, 3.5f, feet);
        Ui.rrectF(c, 3, 18, 11, 7, 3.5f, feet);
        // тело и живот
        Ui.rrectF(c, -22, -19, 44, 41, 19, col);
        Ui.rrectF(c, -22, 6, 44, 16, 12, shade(col, 0.9f));
        Ui.rrectF(c, -13, -2, 26, 20, 10, Ui.mix(col, 0xFFFFFFFF, 0.55f));
        Ui.rrectF(c, -17, -17, 34, 9, 4.5f, Ui.alpha(0xFFFFFF, 0.12f));
        if (type == 4) {
            circle(c, -21.0f, 9.0f, 6.0f, 0xFF26262E);
            circle(c, 21.0f, 9.0f, 6.0f, 0xFF26262E);
        }
        if (type == 3) {   // белые щёчки лисы
            Ui.rrectF(c, -22, -1, 17, 13, 6.5f, Ui.alpha(0xFFFFFFFF, 0.92f));
            Ui.rrectF(c, 5, -1, 17, 13, 6.5f, Ui.alpha(0xFFFFFFFF, 0.92f));
        }
        if (type == 5) {   // светлое брюшко и гребень дракона
            Ui.rrectF(c, -10, 4, 20, 16, 8, Ui.alpha(0xFFFFF1C2, 0.8f));
            for (int q = -1; q <= 1; q++) Ui.rrectF(c, q * 7.0f - 2.0f, -24.0f + Math.abs(q) * 3.0f, 4, 7, 2, shade(col, 0.7f));
        }

        // глаза следят за курсором
        float ox = (mx - bx0), oy = (my - by0);
        float ln = Math.max(1.0f, (float) Math.sqrt(ox * ox + oy * oy));
        float k = Math.min(1.0f, ln / 90.0f);
        float dx = ox / ln * 2.4f * k, dy = oy / ln * 2.4f * k;
        float open = blink > 0.0f ? 0.12f : 1.0f;
        for (int s = -1; s <= 1; s += 2) {
            float ex = s * 9.0f, ey = -6.0f;
            if (type == 4) circle(c, ex, ey, 8.0f, 0xFF26262E);
            Ui.rrectF(c, ex - 6, ey - 6 * open, 12, 12 * open, 6 * open, 0xFFFFFFFF);
            if (open > 0.5f) {
                circle(c, ex + dx, ey + dy, 3.2f, 0xFF1A1A28);
                circle(c, ex + dx - 1.0f, ey + dy - 1.2f, 1.0f, 0xFFFFFFFF);
            }
            circle(c, s * 16.0f, 3.5f, 3.4f, Ui.alpha(0xFFFF7F9C, 0.45f));
        }
        // нос и особенности морды
        int noseCol = (type == 0 || type == 2) ? 0xFFFF8FAB : (type == 5 ? shade(col, 0.55f) : 0xFF1A1A24);
        circle(c, 0, 2.3f, type == 1 || type == 4 ? 2.6f : 1.7f, noseCol);
        if (type == 0 || type == 3) {   // усы
            for (int s = -1; s <= 1; s += 2) {
                for (int q = -1; q <= 1; q++) {
                    m.push();
                    m.translate(s * 13.0f, 4.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * q * 14.0f));
                    Ui.rrectF(c, s > 0 ? 0.0f : -9.0f, -0.4f, 9.0f, 0.9f, 0.45f, Ui.alpha(0xFFFFFFFF, 0.55f));
                    m.pop();
                }
            }
        }
        if (type == 5) {
            circle(c, -2.4f, 2.0f, 0.8f, 0xFF1A1A24);
            circle(c, 2.4f, 2.0f, 0.8f, 0xFF1A1A24);
        }
        // рот
        if (eat > 0.0f) {
            circle(c, 0, 6, 2.2f + (float) Math.abs(Math.sin(t * 14.0f)) * 1.6f, 0xFF3A1A24);
        } else if (Config.petMood >= 45.0f) {
            Ui.rrectF(c, -4.5f, 4.5f, 9, 4, 2.0f, 0xFF3A1A24);
            Ui.rrectF(c, -4.5f, 4.5f, 9, 1.6f, 0.8f, 0xFFFFFFFF);
            if (type == 2) {   // зубки зайца
                Ui.rrectF(c, -2.4f, 5.0f, 2.2f, 3.2f, 0.8f, 0xFFFFFFFF);
                Ui.rrectF(c, 0.2f, 5.0f, 2.2f, 3.2f, 0.8f, 0xFFFFFFFF);
            }
        } else {
            Ui.rrectF(c, -3.5f, 6.5f, 7, 2, 1.0f, 0xFF3A1A24);
        }

        drawStyle(c, Math.floorMod(Config.petStyle, STYLES.length), col, acc);
        m.pop();

        // яблоко
        for (int i = food.size() - 1; i >= 0; i--) {
            float[] f = food.get(i);
            f[3] -= dt;
            f[2] += 220.0f * dt;
            f[1] += f[2] * dt;
            float tx = px, ty = py - 2.0f;
            f[0] += (tx - f[0]) * Math.min(1.0f, dt * 6.0f);
            drawFood(c, (int) f[4], f[0], f[1], 1.0f);
            if (f[1] >= ty || f[3] <= 0.0f) {
                food.remove(i);
                eat = 1.2f;
                int ft = (int) f[4];
                boolean fav = FAV[type] == ft;
                float gain = (ft == 4 ? 22.0f : 12.0f) + (fav ? 12.0f : 0.0f);
                Config.petMood = Math.min(100.0f, Config.petMood + gain);
                spawnHearts(fav ? 7 : 3, px, py - 20.0f);
                if (fav) petJumpV = 130.0f;
                Config.petXp += 3;
                saveSoon();
            }
        }

        // сердечки
        for (int i = hearts.size() - 1; i >= 0; i--) {
            float[] h = hearts.get(i);
            h[4] -= dt;
            h[0] += h[2] * dt;
            h[1] += h[3] * dt;
            if (h[4] <= 0.0f) {
                hearts.remove(i);
                continue;
            }
            heart(c, h[0], h[1], 3.4f, Ui.alpha(0xFFFF5C8A, Math.min(1.0f, h[4] * 1.4f)));
        }

        // ноты во время танца
        for (int i = notes.size() - 1; i >= 0; i--) {
            float[] n = notes.get(i);
            n[4] -= dt;
            n[0] += n[2] * dt;
            n[1] += n[3] * dt;
            if (n[4] <= 0.0f) {
                notes.remove(i);
                continue;
            }
            int nc = Ui.alpha(Ui.mix(0xFF7BDFF2, 0xFFFF8FAB, n[5]), Math.min(1.0f, n[4] * 1.5f));
            circle(c, n[0], n[1], 2.1f, nc);
            Ui.rrectF(c, n[0] + 1.1f, n[1] - 7.5f, 1.3f, 7.5f, 0.6f, nc);
            Ui.rrectF(c, n[0] + 2.0f, n[1] - 7.5f, 3.4f, 1.6f, 0.8f, nc);
        }

        // кнопки под питомцем, выбор еды и шкала настроения
        float by1 = groundY + 14.0f;
        String[] pill = {"Animal", "Color", "Style", dance > 0.0f ? "Stop" : "Dance"};
        for (int i = 0; i < 4; i++) {
            boolean over = Ui.in(mx, my, Math.round(pillX(i)), Math.round(by1), 40, 16);
            pillHov[i] = Anim.smooth(pillHov[i], over ? 1.0f : 0.0f, 14.0f);
            smallPill(c, mc, pill[i], pillX(i), by1, 40, 16, pillHov[i], acc, intro);
        }

        float fy = foodY();
        String hint = "Choose food";
        for (int i = 0; i < FOODS.length; i++) {
            float x = foodX(i);
            boolean over = Ui.in(mx, my, Math.round(x - 9), Math.round(fy), 18, 18);
            foodHov[i] = Anim.smooth(foodHov[i], over ? 1.0f : 0.0f, 14.0f);
            if (over) hint = FOODS[i] + (FAV[type] == i ? "  (favorite)" : "");
            float h = foodHov[i];
            for (int q = 3; q >= 1; q--) {
                circle(c, x, fy + 9.0f, 9.0f + q * 1.4f, Ui.alpha(acc, (0.02f + 0.06f * h) * (4 - q) / 3.0f * intro));
            }
            circle(c, x, fy + 9.0f, 9.5f, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, h), 0.94f * intro));
            drawFood(c, i, x, fy + 9.0f - h * 1.0f, 0.95f + 0.12f * h);
            if (FAV[type] == i) heart(c, x + 6.0f, fy + 1.0f, 2.0f, Ui.alpha(0xFFFF5C8A, 0.9f * intro));
        }
        Ui.textF(c, mc.textRenderer, hint, px - Ui.width(mc.textRenderer, hint) / 2.0f, fy + 21.0f, Ui.alpha(0xFFFFFF, 0.6f * intro));

        float mood = Config.petMood / 100.0f;
        float barY = fy + 36.0f;
        Ui.rrectF(c, px - 52, barY, 104, 5, 2.5f, Ui.alpha(0xFFFFFFFF, 0.10f * intro));
        Ui.rrectF(c, px - 52, barY, Math.max(5.0f, 104.0f * mood), 5, 2.5f,
                Ui.alpha(Ui.mix(0xFFFF6B6B, 0xFF7CFFB2, mood), 0.95f * intro));
        String s = String.format(Locale.ROOT, "%s  Lv %d  |  Mood %d%%", ANIMALS[type], 1 + Config.petXp / 25, Math.round(Config.petMood));
        Ui.textF(c, mc.textRenderer, s, px - Ui.width(mc.textRenderer, s) / 2.0f, barY + 8.0f, Ui.alpha(0xFFFFFF, 0.55f * intro));
    }

    private float pillX(int i) {
        return px - 84.5f + i * 43.0f;
    }

    private float foodX(int i) {
        return px - 50.0f + i * 20.0f;
    }

    private float foodY() {
        return groundY + 36.0f;
    }

    /** Хвост (за телом), у каждого зверя свой. */
    private void drawTail(DrawContext c, int type, int col, float t) {
        MatrixStack m = c.getMatrices();
        m.push();
        switch (type) {
            case 0 -> {   // кот: изогнутый хвост
                m.translate(-19.0f, 10.0f, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(205.0f + (float) Math.sin(t * 2.5f) * 10.0f));
                Ui.rrectF(c, 0, -3, 24, 6, 3, col);
            }
            case 1 -> {   // пёс: виляет хвостом
                m.translate(20.0f, 9.0f, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-50.0f + (float) Math.sin(t * 9.0f) * 16.0f));
                Ui.rrectF(c, 0, -2.5f, 13, 5, 2.5f, shade(col, 0.85f));
            }
            case 2 -> {   // заяц: пушистый хвостик
                m.translate(-20.0f, 14.0f, 0.0f);
                circle(c, 0, 0, 5.5f, 0xFFFFFFFF);
            }
            case 3 -> {   // лиса: пушистый хвост с белым кончиком
                m.translate(20.0f, 12.0f, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-32.0f + (float) Math.sin(t * 3.0f) * 8.0f));
                Ui.rrectF(c, 0, -6.5f, 28, 13, 6.5f, col);
                Ui.rrectF(c, 19, -6.5f, 9, 13, 6.5f, 0xFFFFFFFF);
            }
            case 4 -> {   // панда: короткий хвостик
                m.translate(-20.0f, 15.0f, 0.0f);
                circle(c, 0, 0, 4.5f, 0xFF26262E);
            }
            default -> {  // дракон: хвост с шипом
                m.translate(-19.0f, 12.0f, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(170.0f + (float) Math.sin(t * 2.2f) * 8.0f));
                Ui.rrectF(c, 0, -3, 26, 6, 3, shade(col, 0.9f));
                Ui.rrectF(c, 22, -5.5f, 8, 11, 3, shade(col, 0.6f));
            }
        }
        m.pop();
    }

    /** Уши и рога: форма зависит от зверя. */
    private void drawEars(DrawContext c, int type, int col) {
        MatrixStack m = c.getMatrices();
        for (int s = -1; s <= 1; s += 2) {
            m.push();
            switch (type) {
                case 0 -> {
                    m.translate(s * 15.0f, -17.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 18.0f));
                    Ui.rrectF(c, -5, -12, 10, 15, 5, col);
                    Ui.rrectF(c, -2.5f, -9, 5, 10, 2.5f, Ui.alpha(0xFFFF9EB5, 0.85f));
                }
                case 1 -> {   // висячие уши
                    m.translate(s * 20.0f, -14.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * -10.0f));
                    Ui.rrectF(c, -4.5f, -2, 9, 19, 4.5f, shade(col, 0.68f));
                }
                case 2 -> {   // длинные заячьи уши
                    m.translate(s * 10.0f, -17.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 9.0f));
                    Ui.rrectF(c, -4.5f, -28, 9, 30, 4.5f, col);
                    Ui.rrectF(c, -2.2f, -24, 4.4f, 22, 2.2f, Ui.alpha(0xFFFF9EB5, 0.85f));
                }
                case 3 -> {   // острые уши лисы
                    m.translate(s * 15.0f, -17.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 22.0f));
                    Ui.rrectF(c, -5, -15, 10, 18, 4, col);
                    Ui.rrectF(c, -2.5f, -11, 5, 11, 2.5f, 0xFF2B2B33);
                }
                case 4 -> {   // круглые уши панды
                    circle(c, s * 16.0f, -18.0f, 6.5f, 0xFF26262E);
                }
                default -> {  // рожки дракона
                    m.translate(s * 11.0f, -18.0f, 0.0f);
                    m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 24.0f));
                    Ui.rrectF(c, -2.5f, -15, 5, 17, 2.5f, 0xFFF5E6B3);
                }
            }
            m.pop();
        }
    }

    /** Аксессуары питомца (Style). */
    private void drawStyle(DrawContext c, int style, int col, int acc) {
        switch (style) {
            case 1 -> {   // бантик
                circle(c, 8.0f, -20.0f, 3.6f, 0xFFFF6FA5);
                circle(c, 16.0f, -20.0f, 3.6f, 0xFFFF6FA5);
                circle(c, 12.0f, -20.0f, 1.8f, 0xFFD6336C);
            }
            case 2 -> {   // корона
                Ui.rrectF(c, -10, -24, 20, 6, 2, 0xFFFFD43B);
                for (int q = -1; q <= 1; q++) Ui.rrectF(c, q * 7.0f - 1.8f, -29.0f, 3.6f, 6.0f, 1.6f, 0xFFFFD43B);
                circle(c, 0, -21.0f, 1.3f, 0xFFE5484D);
            }
            case 3 -> {   // тёмные очки
                Ui.rrectF(c, -16, -12, 14, 10, 4.5f, 0xFF111118);
                Ui.rrectF(c, 2, -12, 14, 10, 4.5f, 0xFF111118);
                Ui.rrectF(c, -3, -9, 6, 2, 1, 0xFF111118);
                Ui.rrectF(c, -14, -10.5f, 5, 2, 1, Ui.alpha(0xFFFFFFFF, 0.35f));
                Ui.rrectF(c, 4, -10.5f, 5, 2, 1, Ui.alpha(0xFFFFFFFF, 0.35f));
            }
            case 4 -> {   // праздничный колпак
                Ui.rrectF(c, -8, -26, 16, 6, 2.5f, 0xFFFF6B6B);
                Ui.rrectF(c, -6, -32, 12, 6, 2.5f, 0xFFFFD43B);
                Ui.rrectF(c, -4, -38, 8, 6, 2.5f, 0xFF4DABF7);
                circle(c, 0, -39.0f, 2.4f, 0xFFFFFFFF);
            }
            case 5 -> {   // шарф
                Ui.rrectF(c, -19, 11, 38, 7, 3.5f, 0xFFE5484D);
                Ui.rrectF(c, -19, 14, 38, 2, 1, Ui.alpha(0xFFFFFFFF, 0.35f));
                Ui.rrectF(c, 7, 14, 7, 13, 3.5f, 0xFFC92A2A);
            }
            case 6 -> {   // наушники
                Ui.rrectF(c, -21, -26, 42, 4, 2, 0xFF1C1C26);
                circle(c, -22.0f, -9.0f, 6.0f, 0xFF1C1C26);
                circle(c, 22.0f, -9.0f, 6.0f, 0xFF1C1C26);
                circle(c, -22.0f, -9.0f, 3.2f, Ui.alpha(acc, 0.9f));
                circle(c, 22.0f, -9.0f, 3.2f, Ui.alpha(acc, 0.9f));
                Ui.rrectF(c, -23.5f, -22.0f, 3, 13, 1.5f, 0xFF1C1C26);
                Ui.rrectF(c, 20.5f, -22.0f, 3, 13, 1.5f, 0xFF1C1C26);
            }
            default -> { }
        }
    }

    /** Иконка еды (центр в x, y). */
    private void drawFood(DrawContext c, int id, float x, float y, float s) {
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x, y, 0.0f);
        m.scale(s, s, 1.0f);
        switch (id) {
            case 0 -> {   // яблоко
                circle(c, 0, 0.5f, 4.5f, 0xFFE5484D);
                Ui.rrectF(c, -0.5f, -7.0f, 1.5f, 3.5f, 0.7f, 0xFF6B4A2B);
                Ui.rrectF(c, 1.0f, -7.5f, 4.0f, 2.2f, 1.1f, 0xFF4CAF50);
            }
            case 1 -> {   // рыба
                Ui.rrectF(c, -6, -3, 11, 6, 3, 0xFF8EC9F5);
                m.push();
                m.translate(5.0f, 0.0f, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(45.0f));
                Ui.rrectF(c, -2.2f, -2.2f, 4.4f, 4.4f, 1.0f, 0xFF6FB3E8);
                m.pop();
                circle(c, -3.2f, -0.8f, 0.9f, 0xFF1A1A28);
            }
            case 2 -> {   // морковка
                m.push();
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-35.0f));
                Ui.rrectF(c, -1.8f, -2, 3.6f, 10, 1.8f, 0xFFFF8A2B);
                Ui.rrectF(c, -3.0f, -6.5f, 2.0f, 4.5f, 1.0f, 0xFF4CAF50);
                Ui.rrectF(c, 0.8f, -6.5f, 2.0f, 4.5f, 1.0f, 0xFF4CAF50);
                m.pop();
            }
            case 3 -> {   // печенье
                circle(c, 0, 0, 4.6f, 0xFFC98B4A);
                circle(c, -1.6f, -1.2f, 0.8f, 0xFF5A3A1E);
                circle(c, 1.8f, -0.4f, 0.8f, 0xFF5A3A1E);
                circle(c, -0.4f, 2.0f, 0.8f, 0xFF5A3A1E);
            }
            case 4 -> {   // тортик
                Ui.rrectF(c, -5, -1, 10, 6, 1.6f, 0xFFFFC2D9);
                Ui.rrectF(c, -5, -3, 10, 3.4f, 1.6f, 0xFFFFFFFF);
                circle(c, 0, -4.4f, 1.4f, 0xFFE5484D);
            }
            default -> {  // косточка
                m.push();
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-30.0f));
                Ui.rrectF(c, -5, -1.4f, 10, 2.8f, 1.4f, 0xFFF3F0E6);
                circle(c, -5.0f, -1.4f, 1.6f, 0xFFF3F0E6);
                circle(c, -5.0f, 1.4f, 1.6f, 0xFFF3F0E6);
                circle(c, 5.0f, -1.4f, 1.6f, 0xFFF3F0E6);
                circle(c, 5.0f, 1.4f, 1.6f, 0xFFF3F0E6);
                m.pop();
            }
        }
        m.pop();
    }

    private void smallPill(DrawContext c, MinecraftClient mc, String label, float x, float y, float w, float h,
                           float hover, int acc, float a) {
        float r = h / 2.0f;
        for (int k = 3; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.4f, y - k * 1.4f, w + k * 2.8f, h + k * 2.8f, r + k * 1.4f,
                    Ui.alpha(acc, (0.02f + 0.05f * hover) * (4 - k) / 3.0f * a));
        }
        Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, r + 1, Ui.alpha(acc, (0.30f + 0.55f * hover) * a));
        Ui.rrectF(c, x, y, w, h, r, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, hover), 0.94f * a));
        int tw = Ui.width(mc.textRenderer, label);
        Ui.textMidF(c, mc.textRenderer, label, x + (w - tw) / 2.0f, y, h, Ui.alpha(0xFFFFFFFF, a));
    }

    /**
     * Крыло из перьев. Псевдо-3D: ширина сжимается при взмахе (как будто крыло поворачивается),
     * перья идут слоями от тёмного заднего к светлому переднему, на кончиках осветление.
     */
    private void drawWing(DrawContext c, float sx, float sy, int dir, float phase, int col, float alpha) {
        MatrixStack m = c.getMatrices();
        float flap = (float) Math.sin(phase);
        float fore = 0.62f + 0.38f * (1.0f - Math.abs(flap) * 0.55f);
        int feathers = 6;
        m.push();
        m.translate(sx, sy, 0.0f);
        m.scale(dir * fore, 1.0f, 1.0f);
        for (int layer = 0; layer < 2; layer++) {
            float shadeK = layer == 0 ? 0.62f : 1.0f;
            float off = layer == 0 ? 3.0f : 0.0f;
            for (int i = 0; i < feathers; i++) {
                float ang = -78.0f + i * 20.0f + flap * 20.0f * (1.0f - i * 0.1f) + (layer == 0 ? 5.0f : 0.0f);
                float len = (layer == 0 ? 30.0f : 36.0f) - i * 3.0f;
                int fc = Ui.mix(shade(col, shadeK), 0xFFFFFFFF, 0.15f + i * 0.09f);
                m.push();
                m.translate(0.0f, off, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(ang));
                Ui.rrectF(c, 0.0f, -3.2f, len, 6.4f, 3.2f, Ui.alpha(fc, alpha * (layer == 0 ? 0.85f : 0.95f)));
                Ui.rrectF(c, len * 0.45f, -1.6f, len * 0.5f, 3.2f, 1.6f, Ui.alpha(0xFFFFFFFF, 0.22f * alpha));
                m.pop();
            }
        }
        m.pop();
    }

    // ---------------------------------------------------------------- ввод

    private void spawnHearts(int n, float x, float y) {
        for (int i = 0; i < n; i++) {
            hearts.add(new float[]{x + (float) (Math.random() - 0.5) * 22.0f, y,
                    (float) (Math.random() - 0.5) * 14.0f, -22.0f - (float) Math.random() * 16.0f, 1.1f + (float) Math.random() * 0.5f});
        }
    }

    private void saveSoon() {
        Config.save();
    }

    private void click() {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && petView) {   // Esc закрывает экран питомца
            petView = false;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        MinecraftClient mc = MinecraftClient.getInstance();

        // вспышка частиц от клика
        if (Config.menuFx()) {
            for (int i = 0; i < 16; i++) {
                float ang = (float) (Math.random() * Math.PI * 2.0);
                float sp = 30.0f + (float) Math.random() * 70.0f;
                emit((float) mx, (float) my, (float) Math.cos(ang) * sp, (float) Math.sin(ang) * sp - 20.0f,
                        0.5f + (float) Math.random() * 0.5f, 1.1f + (float) Math.random() * 1.2f, (float) Math.random(), 2);
            }
        }

        if (!petView && Config.menuPet && Ui.in(mx, my, 14, height - 52, 96, 30)) {
            click();
            petView = true;
            return true;
        }
        if (petView) {
            float bkx = px - 150.0f + 12.0f, bky = py - 112.0f + 10.0f;
            if (Ui.in(mx, my, Math.round(bkx), Math.round(bky), 44, 16)) {
                click();
                petView = false;
                return true;
            }
        }

        for (int i = 0; i < LABELS.length && !petView; i++) {
            int y = top + i * (bh + gap);
            if (Ui.in(mx, my, bx, y, bw, bh)) {
                prs[i] = 1.0f;
                click();
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new MultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    case 3 -> mc.setScreen(new ClickGuiScreen());
                    default -> mc.scheduleStop();
                }
                return true;
            }
        }

        if (Config.menuPet && petView) {
            float by1 = groundY + 14.0f;
            for (int i = 0; i < 4; i++) {
                if (!Ui.in(mx, my, Math.round(pillX(i)), Math.round(by1), 40, 16)) continue;
                click();
                switch (i) {
                    case 0 -> Config.petType = Math.floorMod(Config.petType + 1, ANIMALS.length);
                    case 1 -> Config.petColor = Math.floorMod(Config.petColor + 1, PET_COLORS.length);
                    case 2 -> Config.petStyle = Math.floorMod(Config.petStyle + 1, STYLES.length);
                    default -> {
                        if (dance > 0.0f) {
                            dance = 0.0f;
                        } else {
                            dance = 6.0f;
                            Config.petXp += 2;
                        }
                    }
                }
                petJumpV = 110.0f;
                saveSoon();
                return true;
            }
            for (int i = 0; i < FOODS.length; i++) {
                if (Ui.in(mx, my, Math.round(foodX(i) - 9), Math.round(foodY()), 18, 18)) {
                    click();
                    food.add(new float[]{px + 6.0f, py - 80.0f, 0.0f, 3.0f, i});
                    return true;
                }
            }
            if (Ui.in(mx, my, Math.round(px + 4), Math.round(by1), 48, 16)) {
                click();
                Config.petColor = Math.floorMod(Config.petColor + 1, PET_COLORS.length);
                saveSoon();
                return true;
            }
            if (Ui.in(mx, my, Math.round(px - 28), Math.round(py - 26), 56, 56)) {
                petJumpV = 150.0f;
                Config.petMood = Math.min(100.0f, Config.petMood + 6.0f);
                Config.petXp += 1;
                spawnHearts(2, px, py - 24.0f);
                saveSoon();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
