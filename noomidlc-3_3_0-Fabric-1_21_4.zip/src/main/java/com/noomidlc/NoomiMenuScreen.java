package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.RotationAxis;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Главное меню noomidlc: анимированный фон со светлячками, гладкие скруглённые кнопки с подсветкой,
 * виртуальный питомец с крыльями (псевдо-3D: перья в несколько слоёв, сжатие по ширине при взмахе).
 */
public final class NoomiMenuScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Quit Game"};
    private static final int[] PET_COLORS = {0xFFFFB86B, 0xFF7BDFF2, 0xFFB388FF, 0xFFFF8FAB, 0xFF8CE99A, 0xFFF1F1F1};

    private final float[] hov = new float[LABELS.length];
    private final float[] prs = new float[LABELS.length];
    private final float[][] pt = new float[70][5];            // x, y (0..1), скорость, размер, фаза
    private final List<float[]> hearts = new ArrayList<>();   // x, y, vx, vy, жизнь
    private final List<float[]> food = new ArrayList<>();     // x, y, vy, жизнь
    private final long start = System.currentTimeMillis();

    private float petJump = 0.0f, petJumpV = 0.0f;
    private float blink = 0.0f, nextBlink = 2.5f;
    private float eat = 0.0f;
    private float feedHov = 0.0f, colorHov = 0.0f;
    private float flapBoost = 0.0f;
    private float lastSave = 0.0f;

    // раскладка (считается каждый кадр)
    private int bw = 170, bh = 24, gap = 9, bx, top;
    private float px, py, groundY;

    public NoomiMenuScreen() {
        super(Text.literal("noomidlc"));
        Random r = new Random(7);
        for (float[] p : pt) {
            p[0] = r.nextFloat();
            p[1] = r.nextFloat();
            p[2] = 0.01f + r.nextFloat() * 0.03f;
            p[3] = 0.7f + r.nextFloat() * 1.4f;
            p[4] = r.nextFloat() * 6.28f;
        }
    }

    /** Подмена ванильного TitleScreen нашим меню. Вызывается каждый тик. */
    public static void tick(MinecraftClient mc) {
        if (!Config.customMenu) return;
        Screen s = mc.currentScreen;
        if (s != null && s.getClass() == net.minecraft.client.gui.screen.TitleScreen.class) {
            mc.setScreen(new NoomiMenuScreen());
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    // ---------------------------------------------------------------- вспомогательное рисование

    private static void circle(DrawContext c, float cx, float cy, float r, int color) {
        Ui.rrectF(c, cx - r, cy - r, r * 2.0f, r * 2.0f, r, color);
    }

    private static int shade(int c, float k) {
        int a = (c >>> 24) & 255;
        int r = Math.min(255, Math.round(((c >> 16) & 255) * k));
        int g = Math.min(255, Math.round(((c >> 8) & 255) * k));
        int b = Math.min(255, Math.round((c & 255) * k));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private void heart(DrawContext c, float x, float y, float s, int color) {
        MatrixStack m = c.getMatrices();
        circle(c, x - s * 0.5f, y - s * 0.25f, s * 0.55f, color);
        circle(c, x + s * 0.5f, y - s * 0.25f, s * 0.55f, color);
        m.push();
        m.translate(x, y + s * 0.15f, 0.0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(45.0f));
        Ui.rrectF(c, -s * 0.78f, -s * 0.78f, s * 1.56f, s * 1.56f, s * 0.2f, color);
        m.pop();
    }

    // ---------------------------------------------------------------- рендер

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Anim.frame();
        float dt = Anim.dt();
        float t = (System.currentTimeMillis() - start) / 1000.0f;
        int acc = Config.accent() | 0xFF000000;
        float intro = Anim.ease(Math.min(1.0f, t / 0.9f));

        // фон
        ctx.fillGradient(0, 0, width, height, Ui.mix(0xFF0A0A14, acc, 0.10f), Ui.mix(0xFF050509, acc, 0.04f));
        for (int i = 0; i < 4; i++) {
            float x = width * (0.12f + 0.25f * i) + (float) Math.sin(t * 0.25f + i * 1.7f) * 50.0f;
            float w = 46.0f + 26.0f * (i % 2);
            ctx.fillGradient(Math.round(x), 0, Math.round(x + w), height, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.06f + 0.02f * (i % 2)));
        }
        ctx.fillGradient(0, Math.round(height * 0.55f), width, height, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.20f));

        // светлячки с лёгким параллаксом от курсора
        float pxo = (mx - width / 2.0f) * 0.02f, pyo = (my - height / 2.0f) * 0.02f;
        for (float[] p : pt) {
            p[1] -= p[2] * dt;
            p[0] += (float) Math.sin(p[4] + t * 0.5f) * 0.00035f;
            if (p[1] < -0.02f) {
                p[1] = 1.02f;
            }
            float x = p[0] * width + pxo * p[3];
            float y = p[1] * height + pyo * p[3];
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.0f + p[4]);
            circle(ctx, x, y, p[3] * 2.4f, Ui.alpha(acc, 0.10f * tw * intro));
            circle(ctx, x, y, p[3] * 0.65f, Ui.alpha(0xFFFFFF, (0.25f + 0.55f * tw) * intro));
        }

        // раскладка
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        top = Math.round(height / 2.0f - total / 2.0f + 20.0f);
        bx = Math.round(width / 2.0f - bw / 2.0f);

        drawLogo(ctx, mc, t, acc, intro);

        // кнопки
        for (int i = 0; i < LABELS.length; i++) {
            float slide = 1.0f - Anim.ease(Math.max(0.0f, Math.min(1.0f, (t - 0.12f * i - 0.1f) / 0.55f)));
            float a = 1.0f - slide;
            int x = bx - Math.round(slide * 36.0f);
            int y = top + i * (bh + gap);
            boolean over = Ui.in(mx, my, bx, y, bw, bh);
            hov[i] = Anim.smooth(hov[i], over ? 1.0f : 0.0f, 14.0f);
            prs[i] = Anim.smooth(prs[i], 0.0f, 12.0f);
            drawButton(ctx, mc, LABELS[i], x, y, bw, bh, hov[i], prs[i], acc, a);
        }

        // питомец
        if (Config.menuPet) {
            px = Math.min(width - 78.0f, width / 2.0f + bw / 2.0f + 92.0f);
            py = top + total / 2.0f - 8.0f;
            groundY = py + 36.0f;
            drawPetArea(ctx, mc, mx, my, t, dt, acc, intro);
        }

        // подпись
        String ver = "noomidlc 3.3.0  |  Fabric 1.21.4";
        Ui.textF(ctx, mc.textRenderer, ver, 6, height - 12, Ui.alpha(0xFFFFFF, 0.35f * intro));
    }

    private void drawLogo(DrawContext c, MinecraftClient mc, float t, int acc, float intro) {
        String text = "noomidlc";
        float scale = 3.4f;
        int w = Ui.width(mc.textRenderer, text);
        float cx = width / 2.0f;
        float y = Math.max(10.0f, top - 74.0f);
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(cx, y, 0.0f);
        m.scale(scale, scale, 1.0f);
        for (int i = 4; i >= 1; i--) {
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f - i * 0.45f, 0, Ui.alpha(acc, 0.07f * intro));
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f + i * 0.45f, 0, Ui.alpha(acc, 0.07f * intro));
        }
        float pulse = 0.88f + 0.12f * (float) Math.sin(t * 2.0f);
        Ui.textF(c, mc.textRenderer, text, -w / 2.0f, 0, Ui.alpha(0xFFFFFF, intro * pulse));
        m.pop();
        float lw = w * scale;
        float ly = y + 11.0f * scale + 3.0f;
        float sweep = (float) ((t * 0.5) % 1.0);
        Ui.rrectF(c, cx - lw / 2.0f, ly, lw, 2.0f, 1.0f, Ui.alpha(acc, 0.55f * intro));
        Ui.rrectF(c, cx - lw / 2.0f + sweep * (lw - 30.0f), ly, 30.0f, 2.0f, 1.0f, Ui.alpha(0xFFFFFF, 0.9f * intro));
    }

    private void drawButton(DrawContext c, MinecraftClient mc, String label, int x, int y, int w, int h,
                            float hover, float press, int acc, float a) {
        float lift = hover * 1.5f;
        float yy = y - lift + press * 1.0f;
        float r = h / 2.0f;
        // подсветка вокруг кнопки
        for (int k = 5; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.6f, yy - k * 1.6f, w + k * 3.2f, h + k * 3.2f, r + k * 1.6f,
                    Ui.alpha(acc, (0.020f + 0.040f * hover) * (6 - k) / 5.0f * a));
        }
        // обводка и тело
        Ui.rrectF(c, x - 1, yy - 1, w + 2, h + 2, r + 1, Ui.alpha(acc, (0.35f + 0.55f * hover) * a));
        Ui.rrectF(c, x, yy, w, h, r, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, hover), 0.94f * a));
        Ui.rrectF(c, x + 1, yy + 1, w - 2, h * 0.5f, r - 1, Ui.alpha(0xFFFFFF, (0.05f + 0.06f * hover) * a));
        // полоска блика при наведении
        if (hover > 0.01f) {
            float sw = (float) ((System.currentTimeMillis() % 1400L) / 1400.0);
            float sx = x + 8 + sw * (w - 30);
            Ui.rrectF(c, sx, yy + 3, 14, h - 6, 3, Ui.alpha(0xFFFFFF, 0.06f * hover * a));
        }
        int tw = Ui.width(mc.textRenderer, label);
        Ui.textMidF(c, mc.textRenderer, label, x + (w - tw) / 2.0f, yy, h, Ui.alpha(Ui.mix(0xFFD8D8E4, 0xFFFFFFFF, hover), a));
    }

    // ---------------------------------------------------------------- питомец

    private void drawPetArea(DrawContext c, MinecraftClient mc, int mx, int my, float t, float dt, int acc, float intro) {
        // физика прыжка
        petJump += petJumpV * dt;
        petJumpV -= 520.0f * dt;
        if (petJump < 0.0f) {
            petJump = 0.0f;
            petJumpV = 0.0f;
        }
        flapBoost = Anim.smooth(flapBoost, petJump > 0.5f ? 1.0f : 0.0f, 8.0f);
        eat = Math.max(0.0f, eat - dt);

        // моргание
        nextBlink -= dt;
        if (nextBlink <= 0.0f) {
            blink = 0.16f;
            nextBlink = 2.0f + (float) Math.random() * 3.0f;
        }
        blink = Math.max(0.0f, blink - dt);

        // настроение медленно падает
        Config.petMood = Math.max(0.0f, Config.petMood - dt * 0.35f);

        int col = PET_COLORS[Math.floorMod(Config.petColor, PET_COLORS.length)];
        float bob = (float) Math.sin(t * 2.2f) * 3.0f;
        float bx0 = px, by0 = py + bob - petJump;
        float sc = 1.0f + (petJump > 0.5f ? 0.04f : 0.0f);

        // тень на земле
        float shw = 40.0f - petJump * 0.15f - bob * 0.5f;
        Ui.rrectF(c, px - shw / 2.0f, groundY + 6, shw, 6, 3, Ui.alpha(0xFF000000, 0.35f * intro));

        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(bx0, by0, 0.0f);
        m.scale(sc, sc, 1.0f);

        // крылья (за телом)
        if (Config.menuWings) {
            float phase = t * (4.2f + flapBoost * 9.0f);
            drawWing(c, -12.0f, -6.0f, -1, phase, col, 0.65f);
            drawWing(c, 12.0f, -6.0f, 1, phase, col, 0.65f);
        }

        // ушки
        for (int s = -1; s <= 1; s += 2) {
            m.push();
            m.translate(s * 15.0f, -17.0f, 0.0f);
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s * 18.0f));
            Ui.rrectF(c, -5, -12, 10, 15, 5, col);
            Ui.rrectF(c, -2.5f, -9, 5, 10, 2.5f, Ui.alpha(0xFFFF9EB5, 0.85f));
            m.pop();
        }
        // ноги
        Ui.rrectF(c, -14, 18, 11, 7, 3.5f, shade(col, 0.82f));
        Ui.rrectF(c, 3, 18, 11, 7, 3.5f, shade(col, 0.82f));
        // тело и живот
        Ui.rrectF(c, -22, -19, 44, 41, 19, col);
        Ui.rrectF(c, -22, 6, 44, 16, 12, shade(col, 0.9f));
        Ui.rrectF(c, -13, -2, 26, 20, 10, Ui.mix(col, 0xFFFFFFFF, 0.55f));
        Ui.rrectF(c, -17, -17, 34, 9, 4.5f, Ui.alpha(0xFFFFFF, 0.12f));

        // глаза следят за курсором
        float ox = (mx - bx0), oy = (my - by0);
        float ln = Math.max(1.0f, (float) Math.sqrt(ox * ox + oy * oy));
        float k = Math.min(1.0f, ln / 90.0f);
        float dx = ox / ln * 2.4f * k, dy = oy / ln * 2.4f * k;
        float open = blink > 0.0f ? 0.12f : 1.0f;
        for (int s = -1; s <= 1; s += 2) {
            float ex = s * 9.0f, ey = -6.0f;
            Ui.rrectF(c, ex - 6, ey - 6 * open, 12, 12 * open, 6 * open, 0xFFFFFFFF);
            if (open > 0.5f) {
                circle(c, ex + dx, ey + dy, 3.2f, 0xFF1A1A28);
                circle(c, ex + dx - 1.0f, ey + dy - 1.2f, 1.0f, 0xFFFFFFFF);
            }
            circle(c, s * 16.0f, 3.5f, 3.4f, Ui.alpha(0xFFFF7F9C, 0.45f));
        }
        // рот
        if (eat > 0.0f) {
            circle(c, 0, 6, 2.2f + (float) Math.abs(Math.sin(t * 14.0f)) * 1.6f, 0xFF3A1A24);
        } else if (Config.petMood >= 45.0f) {
            Ui.rrectF(c, -4.5f, 4.5f, 9, 4, 2.0f, 0xFF3A1A24);
            Ui.rrectF(c, -4.5f, 4.5f, 9, 1.6f, 0.8f, 0xFFFFFFFF);
        } else {
            Ui.rrectF(c, -3.5f, 6.5f, 7, 2, 1.0f, 0xFF3A1A24);
        }

        // крылья спереди (полупрозрачный верхний слой)
        if (Config.menuWings) {
            float phase = t * (4.2f + flapBoost * 9.0f);
            drawWing(c, -17.0f, -9.0f, -1, phase + 0.35f, col, 1.0f);
            drawWing(c, 17.0f, -9.0f, 1, phase + 0.35f, col, 1.0f);
        }
        m.pop();

        // яблоко
        for (int i = food.size() - 1; i >= 0; i--) {
            float[] f = food.get(i);
            f[3] -= dt;
            f[2] += 220.0f * dt;
            f[1] += f[2] * dt;
            float tx = px, ty = py - 2.0f;
            f[0] += (tx - f[0]) * Math.min(1.0f, dt * 6.0f);
            circle(c, f[0], f[1], 4.5f, 0xFFE5484D);
            Ui.rrectF(c, f[0] - 0.5f, f[1] - 7.0f, 1.5f, 3.5f, 0.7f, 0xFF6B4A2B);
            Ui.rrectF(c, f[0] + 1.0f, f[1] - 7.5f, 4.0f, 2.2f, 1.1f, 0xFF4CAF50);
            if (f[1] >= ty || f[3] <= 0.0f) {
                food.remove(i);
                eat = 1.2f;
                Config.petMood = Math.min(100.0f, Config.petMood + 18.0f);
                spawnHearts(3, px, py - 20.0f);
                saveSoon();
            }
        }

        // сердечки
        for (int i = hearts.size() - 1; i >= 0; i--) {
            float[] h = hearts.get(i);
            h[4] -= dt;
            h[0] += h[2] * dt;
            h[1] += h[3] * dt;
            if (h[4] <= 0.0f) {
                hearts.remove(i);
                continue;
            }
            heart(c, h[0], h[1], 3.4f, Ui.alpha(0xFFFF5C8A, Math.min(1.0f, h[4] * 1.4f)));
        }

        // кнопки под питомцем и шкала настроения
        float by1 = groundY + 14.0f;
        boolean overFeed = Ui.in(mx, my, Math.round(px - 52), Math.round(by1), 48, 16);
        boolean overCol = Ui.in(mx, my, Math.round(px + 4), Math.round(by1), 48, 16);
        feedHov = Anim.smooth(feedHov, overFeed ? 1.0f : 0.0f, 14.0f);
        colorHov = Anim.smooth(colorHov, overCol ? 1.0f : 0.0f, 14.0f);
        smallPill(c, mc, "Feed", px - 52, by1, 48, 16, feedHov, acc, intro);
        smallPill(c, mc, "Color", px + 4, by1, 48, 16, colorHov, acc, intro);

        float mood = Config.petMood / 100.0f;
        float barY = by1 + 24.0f;
        Ui.rrectF(c, px - 52, barY, 104, 5, 2.5f, Ui.alpha(0xFFFFFFFF, 0.10f * intro));
        Ui.rrectF(c, px - 52, barY, Math.max(5.0f, 104.0f * mood), 5, 2.5f,
                Ui.alpha(Ui.mix(0xFFFF6B6B, 0xFF7CFFB2, mood), 0.95f * intro));
        String s = String.format(Locale.ROOT, "Mood %d%%", Math.round(Config.petMood));
        Ui.textF(c, mc.textRenderer, s, px - Ui.width(mc.textRenderer, s) / 2.0f, barY + 8.0f, Ui.alpha(0xFFFFFF, 0.55f * intro));
    }

    private void smallPill(DrawContext c, MinecraftClient mc, String label, float x, float y, float w, float h,
                           float hover, int acc, float a) {
        float r = h / 2.0f;
        for (int k = 3; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.4f, y - k * 1.4f, w + k * 2.8f, h + k * 2.8f, r + k * 1.4f,
                    Ui.alpha(acc, (0.02f + 0.05f * hover) * (4 - k) / 3.0f * a));
        }
        Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, r + 1, Ui.alpha(acc, (0.30f + 0.55f * hover) * a));
        Ui.rrectF(c, x, y, w, h, r, Ui.alpha(Ui.mix(0xFF14141F, 0xFF262640, hover), 0.94f * a));
        int tw = Ui.width(mc.textRenderer, label);
        Ui.textMidF(c, mc.textRenderer, label, x + (w - tw) / 2.0f, y, h, Ui.alpha(0xFFFFFFFF, a));
    }

    /**
     * Крыло из перьев. Псевдо-3D: ширина сжимается при взмахе (как будто крыло поворачивается),
     * перья идут слоями от тёмного заднего к светлому переднему, на кончиках осветление.
     */
    private void drawWing(DrawContext c, float sx, float sy, int dir, float phase, int col, float alpha) {
        MatrixStack m = c.getMatrices();
        float flap = (float) Math.sin(phase);
        float fore = 0.62f + 0.38f * (1.0f - Math.abs(flap) * 0.55f);
        int feathers = 6;
        m.push();
        m.translate(sx, sy, 0.0f);
        m.scale(dir * fore, 1.0f, 1.0f);
        for (int layer = 0; layer < 2; layer++) {
            float shadeK = layer == 0 ? 0.62f : 1.0f;
            float off = layer == 0 ? 3.0f : 0.0f;
            for (int i = 0; i < feathers; i++) {
                float ang = -78.0f + i * 20.0f + flap * 20.0f * (1.0f - i * 0.1f) + (layer == 0 ? 5.0f : 0.0f);
                float len = (layer == 0 ? 30.0f : 36.0f) - i * 3.0f;
                int fc = Ui.mix(shade(col, shadeK), 0xFFFFFFFF, 0.15f + i * 0.09f);
                m.push();
                m.translate(0.0f, off, 0.0f);
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(ang));
                Ui.rrectF(c, 0.0f, -3.2f, len, 6.4f, 3.2f, Ui.alpha(fc, alpha * (layer == 0 ? 0.85f : 0.95f)));
                Ui.rrectF(c, len * 0.45f, -1.6f, len * 0.5f, 3.2f, 1.6f, Ui.alpha(0xFFFFFFFF, 0.22f * alpha));
                m.pop();
            }
        }
        m.pop();
    }

    // ---------------------------------------------------------------- ввод

    private void spawnHearts(int n, float x, float y) {
        for (int i = 0; i < n; i++) {
            hearts.add(new float[]{x + (float) (Math.random() - 0.5) * 22.0f, y,
                    (float) (Math.random() - 0.5) * 14.0f, -22.0f - (float) Math.random() * 16.0f, 1.1f + (float) Math.random() * 0.5f});
        }
    }

    private void saveSoon() {
        Config.save();
    }

    private void click() {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        MinecraftClient mc = MinecraftClient.getInstance();

        for (int i = 0; i < LABELS.length; i++) {
            int y = top + i * (bh + gap);
            if (Ui.in(mx, my, bx, y, bw, bh)) {
                prs[i] = 1.0f;
                click();
                switch (i) {
                    case 0 -> mc.setScreen(new SelectWorldScreen(this));
                    case 1 -> mc.setScreen(new MultiplayerScreen(this));
                    case 2 -> mc.setScreen(new OptionsScreen(this, mc.options));
                    default -> mc.scheduleStop();
                }
                return true;
            }
        }

        if (Config.menuPet) {
            float by1 = groundY + 14.0f;
            if (Ui.in(mx, my, Math.round(px - 52), Math.round(by1), 48, 16)) {
                click();
                food.add(new float[]{px + 6.0f, py - 80.0f, 0.0f, 3.0f});
                return true;
            }
            if (Ui.in(mx, my, Math.round(px + 4), Math.round(by1), 48, 16)) {
                click();
                Config.petColor = Math.floorMod(Config.petColor + 1, PET_COLORS.length);
                saveSoon();
                return true;
            }
            if (Ui.in(mx, my, Math.round(px - 28), Math.round(py - 26), 56, 56)) {
                petJumpV = 150.0f;
                Config.petMood = Math.min(100.0f, Config.petMood + 6.0f);
                spawnHearts(2, px, py - 24.0f);
                saveSoon();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
