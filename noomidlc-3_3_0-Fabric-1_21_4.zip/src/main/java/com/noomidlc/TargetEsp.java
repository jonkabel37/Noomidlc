package com.noomidlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.Locale;

/**
 * Target ESP: подсветка текущей цели (KillAura / LegitAura / прицел) в нескольких стилях.
 * Мировой рендер только запоминает камеру и цель, всё остальное рисуется в HUD, поэтому видно и сквозь стены.
 */
public final class TargetEsp {
    private TargetEsp() {}

    private static LivingEntity ent = null;
    private static boolean valid = false;
    private static float alpha = 0.0f;
    private static final Matrix4f V = new Matrix4f();
    private static final Matrix4f P = new Matrix4f();
    private static Vec3d cam = Vec3d.ZERO;
    private static double X, Y, Z, W, H;
    private static float hp, max, dist;
    private static String name = "";
    private static int sw, sh;
    private static float T = 0.0f;
    private static float hpRatio = 1.0f;

    private static LivingEntity auraTarget() {
        LivingEntity t = KillAura.target();
        return t != null ? t : LegitAura.target();
    }

    public static void collect(WorldRenderContext ctx) {
        valid = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (!Config.targetEsp || p == null || mc.world == null) {
            alpha = 0.0f;
            return;
        }
        LivingEntity e = Config.teOnlyAura ? auraTarget() : ModernHud.findTarget(mc, p);
        boolean want = e != null;
        if (e != null) ent = e;
        if (ent == null || ent.isRemoved() || !ent.isAlive()) {
            ent = null;
            alpha = 0.0f;
            return;
        }
        alpha += ((want ? 1.0f : 0.0f) - alpha) * (Config.teFade ? 0.18f : 1.0f);
        if (alpha < 0.02f) return;

        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d lp = ent.getLerpedPos(td);
        X = lp.x;
        Y = lp.y;
        Z = lp.z;
        W = ent.getWidth();
        H = ent.getHeight();
        cam = ctx.camera().getPos();
        V.set(ctx.positionMatrix());
        P.set(ctx.projectionMatrix());
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
        hp = ent.getHealth();
        max = Math.max(1.0f, ent.getMaxHealth());
        hpRatio = Math.max(0.0f, Math.min(1.0f, hp / max));
        dist = p.distanceTo(ent);
        name = ent.getName().getString();
        valid = true;
    }

    // ------------------------------------------------------------ вспомогательное

    private static float[] pr(double x, double y, double z) {
        Vector4f v = new Vector4f((float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z), 1.0f);
        v.mul(V);
        v.mul(P);
        if (v.w <= 0.05f) return null;
        return new float[]{(v.x / v.w * 0.5f + 0.5f) * sw, (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh};
    }

    private static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float hh = h * 6.0f;
        int i = (int) hh;
        float f = hh - i;
        float p = v * (1.0f - s), q = v * (1.0f - s * f), t = v * (1.0f - s * (1.0f - f));
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255.0f) << 16) | ((int) (g * 255.0f) << 8) | (int) (b * 255.0f);
    }

    /** Цвет по настройке; off (0..1) сдвигает оттенок вдоль фигуры у радужного режима. */
    private static int col(float off) {
        int c = switch (Config.teColor) {
            case 1 -> Ui.mix(0xFFFF4D4D, 0xFF5CE08A, hpRatio);
            case 2 -> hsv(T * 0.15f + off, 0.65f, 1.0f);
            case 3 -> 0xFFFFFFFF;
            case 4 -> 0xFFFF4040;
            default -> 0xFF000000 | Config.accent();
        };
        return c;
    }

    private static int cA(float off, float a) {
        return Ui.alpha(col(off), Math.max(0.0f, Math.min(1.0f, a * alpha)));
    }

    private static void ln(DrawContext c, float[] a, float[] b, int color, float half) {
        if (a == null || b == null) return;
        Esp.tracer(c, a[0], a[1], b[0], b[1], color, half);
    }

    private static void dot(DrawContext c, float[] a, float r, int color) {
        if (a == null) return;
        Ui.rrectF(c, a[0] - r, a[1] - r, r * 2.0f, r * 2.0f, r, color);
    }

    /** Экранный прямоугольник вокруг цели: x1, y1, x2, y2 (или null, если цель частично за камерой). */
    private static float[] bounds() {
        float x1 = Float.MAX_VALUE, y1 = Float.MAX_VALUE, x2 = -Float.MAX_VALUE, y2 = -Float.MAX_VALUE;
        double w2 = W / 2.0;
        for (int i = 0; i < 8; i++) {
            float[] p = pr(X + ((i & 1) == 0 ? -w2 : w2), Y + ((i & 2) == 0 ? 0.0 : H), Z + ((i & 4) == 0 ? -w2 : w2));
            if (p == null) return null;
            x1 = Math.min(x1, p[0]);
            y1 = Math.min(y1, p[1]);
            x2 = Math.max(x2, p[0]);
            y2 = Math.max(y2, p[1]);
        }
        return new float[]{x1, y1, x2, y2};
    }

    // ------------------------------------------------------------ рисование

    public static void draw(DrawContext c) {
        if (!valid || alpha < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        T = (System.currentTimeMillis() % 1000000L) / 1000.0f * Config.teSpeed;
        float half = Math.max(0.25f, Config.teLine / (2.0f * Ui.scale()));
        float size = Config.teSize;
        float rad = (float) (W / 2.0 + 0.3) * size;
        float[] bb = bounds();

        switch (Math.floorMod(Config.teStyle, Config.TE_STYLES.length)) {
            case 1 -> box2d(c, bb, half);
            case 2 -> box3d(c, half);
            case 3 -> ring(c, Y + 0.02, rad, half);
            case 4 -> orbit(c, rad, half);
            case 5 -> ring(c, Y + H + 0.2, rad * 0.55f, half);
            case 6 -> arrow(c, size, half);
            case 7 -> diamond(c, size, half);
            case 8 -> lock(c, bb, half);
            case 9 -> glow(c, bb);
            case 10 -> spiral(c, rad, half);
            default -> corners(c, bb, half);
        }

        if (Config.teTracer) {
            float[] mid = pr(X, Y + H / 2.0, Z);
            float[] from = {sw / 2.0f, (float) sh};
            ln(c, from, mid, cA(0.0f, 0.55f), half * 0.7f);
            dot(c, mid, 2.0f, cA(0.0f, 0.9f));
        }
        if (bb != null) {
            if (Config.teName) {
                String s = String.format(Locale.ROOT, "%s  %.1fm", name, dist);
                float cx = (bb[0] + bb[2]) / 2.0f;
                Ui.text(c, tr, s, Math.round(cx - Ui.width(tr, s) / 2.0f), Math.round(bb[1] - 12.0f), Ui.alpha(0xFFFFFF, 0.95f * alpha));
            }
            if (Config.teHealth) {
                float bx = bb[0] - 5.0f, top = bb[1], bot = bb[3];
                Ui.rect(c, bx - 1.0f, top, bx + 1.5f, bot, Ui.alpha(0x000000, 0.45f * alpha));
                Ui.rect(c, bx - 0.5f, bot - (bot - top) * hpRatio, bx + 1.0f, bot, Ui.alpha(Ui.mix(0xFFFF4D4D, 0xFF5CE08A, hpRatio), alpha));
            }
        }
    }

    private static void corners(DrawContext c, float[] bb, float half) {
        if (bb == null) return;
        float cl = Math.min(bb[2] - bb[0], bb[3] - bb[1]) * 0.28f;
        float[][] cs = {{bb[0], bb[1], 1, 1}, {bb[2], bb[1], -1, 1}, {bb[0], bb[3], 1, -1}, {bb[2], bb[3], -1, -1}};
        for (int i = 0; i < 4; i++) {
            float[] k = cs[i];
            int color = cA(i * 0.25f, 1.0f);
            ln(c, new float[]{k[0], k[1]}, new float[]{k[0] + k[2] * cl, k[1]}, color, half);
            ln(c, new float[]{k[0], k[1]}, new float[]{k[0], k[1] + k[3] * cl}, color, half);
        }
        if (Config.teFill) Ui.rect(c, bb[0], bb[1], bb[2], bb[3], cA(0.0f, 0.07f));
    }

    private static void box2d(DrawContext c, float[] bb, float half) {
        if (bb == null) return;
        if (Config.teFill) Ui.rect(c, bb[0], bb[1], bb[2], bb[3], cA(0.0f, 0.10f));
        float[] a = {bb[0], bb[1]}, b = {bb[2], bb[1]}, d = {bb[2], bb[3]}, e = {bb[0], bb[3]};
        ln(c, a, b, cA(0.0f, 1.0f), half);
        ln(c, b, d, cA(0.25f, 1.0f), half);
        ln(c, d, e, cA(0.5f, 1.0f), half);
        ln(c, e, a, cA(0.75f, 1.0f), half);
    }

    private static void box3d(DrawContext c, float half) {
        double w2 = W / 2.0;
        float[][] p = new float[8][];
        for (int i = 0; i < 8; i++) {
            p[i] = pr(X + ((i & 1) == 0 ? -w2 : w2), Y + ((i & 2) == 0 ? 0.0 : H), Z + ((i & 4) == 0 ? -w2 : w2));
        }
        for (int[] e : Esp.BOX_EDGES) ln(c, p[e[0]], p[e[1]], cA(e[0] / 8.0f, 1.0f), half);
    }

    /** Кольцо вокруг цели на высоте y; по нему бежит яркий отрезок. */
    private static void ring(DrawContext c, double y, float rad, float half) {
        int n = 40;
        float[] prev = null;
        for (int k = 0; k <= n; k++) {
            double ang = Math.PI * 2.0 * k / n;
            float[] pt = pr(X + Math.cos(ang) * rad, y, Z + Math.sin(ang) * rad);
            if (k > 0) {
                double d = Math.abs(((ang - T * 2.0) % (Math.PI * 2.0) + Math.PI * 3.0) % (Math.PI * 2.0) - Math.PI);
                float bright = (float) Math.max(0.0, 1.0 - d / 1.1);
                ln(c, prev, pt, cA(k / (float) n, 0.35f + 0.65f * bright), half * (1.0f + bright * 0.6f));
            }
            prev = pt;
        }
    }

    /** Три огонька с шлейфом вращаются вокруг цели и ходят вверх-вниз. */
    private static void orbit(DrawContext c, float rad, float half) {
        for (int k = 0; k < 3; k++) {
            float[] last = null;
            for (int j = 0; j < 9; j++) {
                double ang = T * 2.0 + k * 2.094 - j * 0.13;
                double yy = Y + H * (0.5 + 0.45 * Math.sin(T * 1.5 + k * 2.0 - j * 0.08));
                float[] pt = pr(X + Math.cos(ang) * rad, yy, Z + Math.sin(ang) * rad);
                float f = 1.0f - j / 9.0f;
                if (j > 0) ln(c, last, pt, cA(k / 3.0f, 0.7f * f), half * f);
                else dot(c, pt, 2.6f * Config.teSize, cA(k / 3.0f, 1.0f));
                last = pt;
            }
        }
    }

    private static void arrow(DrawContext c, float size, float half) {
        float bob = (float) Math.sin(T * 3.0) * 0.1f;
        float[] tip = pr(X, Y + H + 0.45 + bob, Z);
        if (tip == null) return;
        float s = 7.0f * size;
        float[] l = {tip[0] - s, tip[1] - s * 1.7f}, r = {tip[0] + s, tip[1] - s * 1.7f};
        for (int i = 0; i <= 5; i++) {   // заливка
            float[] b = {l[0] + (r[0] - l[0]) * i / 5.0f, l[1]};
            ln(c, tip, b, cA(0.0f, 0.55f), half);
        }
        ln(c, tip, l, cA(0.0f, 1.0f), half);
        ln(c, tip, r, cA(0.3f, 1.0f), half);
        ln(c, l, r, cA(0.6f, 1.0f), half);
    }

    private static void diamond(DrawContext c, float size, float half) {
        float[] cp = pr(X, Y + H + 0.55, Z);
        if (cp == null) return;
        float wd = (float) Math.abs(Math.cos(T * 2.0)) * 8.0f * size + 1.0f;
        float ht = 11.0f * size;
        float[] top = {cp[0], cp[1] - ht}, right = {cp[0] + wd, cp[1]}, bot = {cp[0], cp[1] + ht}, left = {cp[0] - wd, cp[1]};
        ln(c, top, right, cA(0.0f, 1.0f), half);
        ln(c, right, bot, cA(0.25f, 1.0f), half);
        ln(c, bot, left, cA(0.5f, 1.0f), half);
        ln(c, left, top, cA(0.75f, 1.0f), half);
        ln(c, top, bot, cA(0.0f, 0.5f), half * 0.7f);
    }

    /** Четыре скобки вращаются вокруг цели как прицел. */
    private static void lock(DrawContext c, float[] bb, float half) {
        float[] cs = pr(X, Y + H / 2.0, Z);
        if (cs == null) return;
        float r2 = bb != null ? Math.max(bb[2] - bb[0], bb[3] - bb[1]) * 0.62f : 30.0f;
        r2 = Math.max(14.0f, r2) * Config.teSize;
        for (int k = 0; k < 4; k++) {
            float base = T * 1.4f + k * (float) (Math.PI / 2.0);
            float[] prev = null;
            for (int j = 0; j <= 6; j++) {
                float ang = base - 0.38f + j * 0.127f;
                float[] pt = {cs[0] + (float) Math.cos(ang) * r2, cs[1] + (float) Math.sin(ang) * r2};
                if (j > 0) ln(c, prev, pt, cA(k / 4.0f, 1.0f), half);
                prev = pt;
            }
        }
        dot(c, cs, 1.8f, cA(0.0f, 0.9f));
    }

    private static void glow(DrawContext c, float[] bb) {
        if (bb == null) return;
        float pulse = 0.75f + 0.25f * (float) Math.sin(T * 3.0);
        float w = bb[2] - bb[0], h = bb[3] - bb[1];
        for (int k = 6; k >= 1; k--) {
            float g = k * 2.5f * Config.teSize;
            Ui.rrectF(c, bb[0] - g, bb[1] - g, w + g * 2.0f, h + g * 2.0f, 6.0f + g, cA(k / 6.0f, 0.06f * (7 - k) / 6.0f * pulse));
        }
    }

    /** Двойная спираль вдоль тела. */
    private static void spiral(DrawContext c, float rad, float half) {
        int n = 30;
        for (int s = 0; s < 2; s++) {
            float[] prev = null;
            for (int k = 0; k <= n; k++) {
                float t = k / (float) n;
                double ang = T * 2.0 + t * 12.5 + s * Math.PI;
                float[] pt = pr(X + Math.cos(ang) * rad * 0.9, Y + H * t, Z + Math.sin(ang) * rad * 0.9);
                if (k > 0) ln(c, prev, pt, cA(t, 0.95f), half);
                prev = pt;
            }
        }
    }
}
