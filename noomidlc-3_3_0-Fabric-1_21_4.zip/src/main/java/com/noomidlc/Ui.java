package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Помощники для рисования. Вся геометрия растеризуется в НАТИВНОМ разрешении окна,
 * а не в "больших" пикселях GUI-масштаба, поэтому скругления и края получаются гладкими.
 */
public final class Ui {
    private Ui() {}

    /** Рисует буфер, только если в нём есть вершины (пустой buffer.end() в 1.21.4 бросает исключение и роняет игру). */
    public static void flush(net.minecraft.client.render.BufferBuilder b) {
        net.minecraft.client.render.BuiltBuffer built = b.endNullable();
        if (built != null) net.minecraft.client.render.BufferRenderer.drawWithGlobalProgram(built);
    }

    /** Идентификаторы TTF-шрифтов (0 = ванильный). Для каждого есть варианты _1.._5 с oversample = масштаб GUI. */
    private static final String[] FONT_KEYS = {null, "ui_jetbrains", "ui_geist", "ui_carlito"};
    private static final int MAX_OS = 5;
    private static final Style[][] STYLES = new Style[FONT_KEYS.length][MAX_OS + 1];

    /**
     * oversample шрифта = масштаб GUI: один пиксель текстуры глифа = один физический пиксель экрана.
     * Без этого буква уменьшается в несколько раз без сглаживания и выглядит "пиксельной".
     */
    private static Style style(int idx, int os) {
        Style st = STYLES[idx][os];
        if (st == null) {
            st = Style.EMPTY.withFont(Identifier.of("noomidlc", FONT_KEYS[idx] + "_" + os));
            STYLES[idx][os] = st;
        }
        return st;
    }

    /** Высота заглавных букв: по ней центруем текст по вертикали. */
    public static final int CAP = 7;

    public static Text t(String s) {
        MutableText m = Text.literal(s);
        int idx = Math.floorMod(Config.font, FONT_KEYS.length);
        if (idx == 0) return m;
        int os = Math.max(1, Math.min(MAX_OS, Math.round(scale())));
        return m.setStyle(style(idx, os));
    }

    public static final Identifier LOGO = Identifier.of("noomidlc", "textures/gui/logo.png");

    /** Логотип софта (текстура 128x128), size - сторона квадрата в пикселях интерфейса. */
    public static void logo(DrawContext c, float x, float y, float size) {
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(x, y, 0.0f);
        float s = size / 128.0f;
        m.scale(s, s, 1.0f);
        c.drawTexture(RenderLayer::getGuiTextured, LOGO, 0, 0, 0.0f, 0.0f, 128, 128, 128, 128);
        m.pop();
    }

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(t(s));
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        textF(c, tr, s, x, y, color);
    }

    /** Текст, привязанный к физическим пикселям окна (плавное движение, без "прыжков" по GUI-сетке). */
    public static void textF(DrawContext c, TextRenderer tr, String s, float x, float y, int color) {
        float sc = scale();
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(Math.round(x * sc) / sc, Math.round(y * sc) / sc, 0.0f);
        c.drawText(tr, t(s), 0, 0, color, false);
        m.pop();
    }

    /** Текст, выровненный по центру строки высотой h. */
    public static void textMid(DrawContext c, TextRenderer tr, String s, int x, int y, int h, int color) {
        textF(c, tr, s, x, y + (h - CAP) / 2.0f, color);
    }

    public static void textMidF(DrawContext c, TextRenderer tr, String s, float x, float y, float h, int color) {
        textF(c, tr, s, x, y + (h - CAP) / 2.0f, color);
    }

    // ------------------------------------------------------------ цвета

    /** Линейная интерполяция ARGB-цветов. */
    public static int mix(int a, int b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int al = Math.round(((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (al << 24) | (r << 16) | (g << 8) | bl;
    }

    /** Цвет с заменённой прозрачностью (0..1). */
    public static int alpha(int color, float a) {
        int al = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        return (al << 24) | (color & 0xFFFFFF);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------ нативное разрешение

    public static float scale() {
        return (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
    }

    /** Прямоугольник с краями, выровненными по физическим пикселям. */
    public static void rect(DrawContext c, float x1, float y1, float x2, float y2, int color) {
        float s = scale();
        MatrixStack m = c.getMatrices();
        m.push();
        m.scale(1.0f / s, 1.0f / s, 1.0f);
        c.fill(Math.round(x1 * s), Math.round(y1 * s), Math.round(x2 * s), Math.round(y2 * s), color);
        m.pop();
    }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        rrectF(c, x, y, w, h, r, color);
    }

    /** Скруглённый прямоугольник со сглаженными краями. r = h/2 даёт капсулу. */
    public static void rrectF(DrawContext c, float x, float y, float w, float h, float r, int color) {
        float s = scale();
        int X = Math.round(x * s), Y = Math.round(y * s);
        int W = Math.round(w * s), H = Math.round(h * s);
        int R = Math.min(Math.round(r * s), Math.min(W, H) / 2);
        if (W <= 0 || H <= 0) return;

        MatrixStack m = c.getMatrices();
        m.push();
        m.scale(1.0f / s, 1.0f / s, 1.0f);

        if (R <= 0) {
            c.fill(X, Y, X + W, Y + H, color);
            m.pop();
            return;
        }

        int alpha = color >>> 24;
        int rgb = color & 0xFFFFFF;

        if (Y + R < Y + H - R) c.fill(X, Y + R, X + W, Y + H - R, color);

        int i = 0;
        while (i < R) {
            double inset = inset(R, i);
            int full = (int) Math.ceil(inset);
            // строки с одинаковым отступом склеиваем в один прямоугольник
            int j = i + 1;
            while (j < R && (int) Math.ceil(inset(R, j)) == full) j++;

            if (X + full < X + W - full) {
                c.fill(X + full, Y + i, X + W - full, Y + j, color);
                c.fill(X + full, Y + H - j, X + W - full, Y + H - i, color);
            }
            if (full > 0) {
                for (int k = i; k < j; k++) {
                    double cov = full - inset(R, k);
                    if (cov <= 0.04) continue;
                    int edge = (Math.round((float) (alpha * cov)) << 24) | rgb;
                    c.fill(X + full - 1, Y + k, X + full, Y + k + 1, edge);
                    c.fill(X + W - full, Y + k, X + W - full + 1, Y + k + 1, edge);
                    c.fill(X + full - 1, Y + H - 1 - k, X + full, Y + H - k, edge);
                    c.fill(X + W - full, Y + H - 1 - k, X + W - full + 1, Y + H - k, edge);
                }
            }
            i = j;
        }
        m.pop();
    }

    private static double inset(int r, int row) {
        double dy = r - row - 0.5;
        return r - Math.sqrt((double) r * r - dy * dy);
    }

    public static void capsule(DrawContext c, int x, int y, int w, int h, int color) {
        rrectF(c, x, y, w, h, h / 2.0f, color);
    }

    public static void capsuleF(DrawContext c, float x, float y, float w, float h, int color) {
        rrectF(c, x, y, w, h, h / 2.0f, color);
    }

    /** Мягкая тень под плашкой. */
    public static void shadow(DrawContext c, int x, int y, int w, int h, int r) {
        for (int k = 5; k >= 1; k--) {
            int a = 0x0E - k;   // 0x09..0x0D - очень слабая прозрачность, слои складываются в мягкий край
            if (a < 2) a = 2;
            rrectF(c, x - k * 1.5f, y - k * 1.5f + 2, w + k * 3.0f, h + k * 3.0f, r + k * 1.5f, a << 24);
        }
    }
}
