package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** Auto Armor (лучшая броня из инвентаря) и Hotbar Refill (пополнение стаков в хотбаре). */
public final class InvMods {
    private InvMods() {}

    private static final String[] MATERIALS = {"leather", "golden", "chainmail", "iron", "turtle", "diamond", "netherite"};
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final String[] SUFFIX = {"_helmet", "_chestplate", "_leggings", "_boots"};
    private static final int[] ARMOR_SLOT_ID = {5, 6, 7, 8};   // номера слотов брони в PlayerScreenHandler

    private static int armorTimer = 0, refillTimer = 0;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null || p.isSpectator()) return;
        if (Config.autoArmor && armorTimer-- <= 0) {
            armorTimer = Math.max(1, Math.round(Config.aaDelay));
            autoArmor(mc, p);
        }
        if (Config.hotbarRefill && refillTimer-- <= 0) {
            refillTimer = 6;
            refill(mc, p);
        }
    }

    /** Оценка вещи для слота: материал важнее, при равенстве выигрывает более целая. -1 - не подходит. */
    private static int score(ItemStack s, int slot) {
        if (s.isEmpty()) return -1;
        String path = Registries.ITEM.getId(s.getItem()).getPath();
        if (!path.endsWith(SUFFIX[slot])) return -1;
        int mat = 0;
        for (int i = 0; i < MATERIALS.length; i++) {
            if (path.startsWith(MATERIALS[i])) mat = i + 1;
        }
        int left = s.isDamageable() ? Math.max(0, s.getMaxDamage() - s.getDamage()) : 0;
        return mat * 1000 + Math.min(999, left / 4);
    }

    private static int slotId(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    private static void autoArmor(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int slot = 0; slot < 4; slot++) {
            ItemStack cur = p.getEquippedStack(SLOTS[slot]);
            if (slot == 1 && cur.isOf(Items.ELYTRA)) continue;   // элитры на груди не трогаем
            int curScore = score(cur, slot);
            int best = curScore;
            int found = -1;
            for (int i = 0; i < 36; i++) {
                int sc = score(inv.getStack(i), slot);
                if (sc > best) {
                    best = sc;
                    found = i;
                }
            }
            if (found < 0) continue;
            int sync = p.playerScreenHandler.syncId;
            int src = slotId(found);
            // взять новую вещь, положить в слот брони, вернуть снятую на место
            mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(sync, ARMOR_SLOT_ID[slot], 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p);
            return;   // одна замена за проход
        }
    }

    private static void refill(MinecraftClient mc, ClientPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty() || !s.isStackable() || s.getCount() >= s.getMaxCount() || s.getCount() > Config.hrAt) continue;
            for (int j = 9; j < 36; j++) {
                ItemStack o = inv.getStack(j);
                if (!o.isEmpty() && ItemStack.areItemsAndComponentsEqual(s, o)) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, j, 0, SlotActionType.QUICK_MOVE, p);
                    return;
                }
            }
        }
    }
}
