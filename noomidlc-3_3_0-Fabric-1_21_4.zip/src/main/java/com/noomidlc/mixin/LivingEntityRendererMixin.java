package com.noomidlc.mixin;

import com.noomidlc.Config;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Прячет ванильные ники (NameTags) и показывает невидимых существ полупрозрачными (See invisibles). */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$hideVanillaTag(LivingEntity entity, double squaredDistance,
                                          CallbackInfoReturnable<Boolean> cir) {
        if (Config.nameTags && entity instanceof PlayerEntity) {
            cir.setReturnValue(false);
        }
    }

    /** Как у спектатора: невидимый рисуется призраком, а не пропадает. */
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;"
            + "Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
            at = @At("TAIL"), require = 0)
    private void noomidlc$seeInvisibles(LivingEntity entity, LivingEntityRenderState state, float tickDelta,
                                         CallbackInfo ci) {
        if (Config.seeInvisibles && state.invisible && (!Config.siPlayersOnly || entity instanceof PlayerEntity)) {
            state.invisibleToPlayer = false;
        }
    }
}
