package com.noomidlc.mixin;

import com.noomidlc.Config;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Reach: дистанция удара по существам (клиентская проверка прицела). */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    @Inject(method = "getEntityInteractionRange()D", at = @At("RETURN"), cancellable = true, require = 0)
    private void noomidlc$reach(CallbackInfoReturnable<Double> cir) {
        if (Config.reach && (Object) this instanceof ClientPlayerEntity) {
            cir.setReturnValue(Math.max(cir.getReturnValueD(), (double) Config.reachRange));
        }
    }
}
