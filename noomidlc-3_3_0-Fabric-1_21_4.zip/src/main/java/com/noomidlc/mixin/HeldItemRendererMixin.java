package com.noomidlc.mixin;

import com.noomidlc.Config;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** ViewModel (положение/размер предмета) и дополнительный наклон при взмахе. */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), require = 0)
    private void noomidlc$viewModel(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                     Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     CallbackInfo ci) {
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;

        if (Config.viewModel) {
            matrices.translate(Config.vmX * side, Config.vmY, Config.vmZ);
            matrices.scale(Config.vmScale, Config.vmScale, Config.vmScale);
        }

        if (Config.swingAnim && swingProgress > 0.0f && Config.swingAngle != 0.0f) {
            float s = (float) Math.sin(swingProgress * Math.PI);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-Config.swingAngle * s));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(Config.swingAngle * 0.5f * s * side));
        }
    }

    /**
     * Стили взмаха. Vanilla не трогаем; Sideways и Push полностью заменяют ванильный взмах предмета.
     */
    @Inject(method = "applySwingOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$swingStyle(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (!Config.swingAnim || Config.swingStyle == 0) return;

        int i = arm == Arm.RIGHT ? 1 : -1;
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);

        float p = swingProgress;
        float sq = MathHelper.sin(p * (float) Math.PI);                  // 0 -> 1 -> 0, плавная дуга
        float bounce = Config.swingBounce ? (float) Math.sin(p * Math.PI * 3.0) * (1.0f - p) * 0.06f : 0.0f;

        switch (Config.swingStyle) {
            case 1 -> {   // Sideways: боковой удар справа налево, клинок идёт плашмя
                float a = p * p * (3.0f - 2.0f * p);
                matrices.translate(i * (0.40f - a * 0.95f), -0.04f * sq, -0.30f * sq);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (50.0f - a * 105.0f)));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-i * 70.0f * sq));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-12.0f * sq));
            }
            case 10 -> {  // Side Slash: широкий горизонтальный росчерк слева направо
                float a = p * p * (3.0f - 2.0f * p);
                matrices.translate(i * (-0.55f + a * 1.10f) * 0.8f, -0.06f * sq, -0.35f * sq);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * (-60.0f + a * 120.0f)));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * 85.0f * sq));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-10.0f * sq));
            }
            case 2 -> {   // Push: толчок вперёд-вниз
                matrices.translate(0.0f, -g * 0.12f, -g * 0.45f);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-g * 28.0f));
            }
            case 3 -> {   // Slash: широкий диагональный взмах сверху вниз
                float a = MathHelper.sin(p * (float) Math.PI * 0.5f);
                matrices.translate(-i * (a - 0.5f) * 0.55f, (0.35f - a * 0.55f) * sq, -sq * 0.25f);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * (-70.0f + a * 120.0f) * sq));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40.0f * sq));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * 35.0f * sq));
            }
            case 4 -> {   // Spin: предмет прокручивается вокруг своей оси
                matrices.translate(0.0f, -sq * 0.1f, -sq * 0.3f);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * p * 360.0f));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-sq * 20.0f));
            }
            case 5 -> {   // Stab: быстрый укол вперёд и назад
                float k = p < 0.35f ? p / 0.35f : 1.0f - (p - 0.35f) / 0.65f;
                k = k * k * (3.0f - 2.0f * k);
                matrices.translate(0.0f, 0.02f * k, -k * 0.75f);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-k * 12.0f));
            }
            case 6 -> {   // Whip: хлёсткий замах с затуханием
                float w = (float) Math.sin(p * Math.PI * 2.0) * (1.0f - p);
                matrices.translate(-i * w * 0.35f, -sq * 0.08f, -sq * 0.2f);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * w * 55.0f));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(i * w * 25.0f));
            }
            case 7 -> {   // Smooth: мягкая дуга без рывков
                float e = p * p * (3.0f - 2.0f * p);
                float arc = (float) Math.sin(e * Math.PI);
                matrices.translate(-i * arc * 0.2f, -arc * 0.1f, -arc * 0.3f);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-arc * 40.0f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-i * arc * 15.0f));
            }
            case 8 -> {   // Chop: рубящий удар сверху вниз
                float c = p < 0.4f ? -p / 0.4f * 0.5f : -0.5f + (p - 0.4f) / 0.6f * 0.5f;
                float d = (float) Math.sin(p * Math.PI);
                matrices.translate(0.0f, d * 0.12f, -d * 0.35f);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-d * 70.0f + c * 30.0f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-i * d * 10.0f));
            }
            default -> {  // Wave: волна из стороны в сторону
                float wv = (float) Math.sin(p * Math.PI * 2.0);
                matrices.translate(i * wv * 0.28f, -sq * 0.1f, -sq * 0.25f);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-i * wv * 35.0f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * wv * 20.0f));
            }
        }
        if (bounce != 0.0f) matrices.translate(0.0f, bounce, -bounce);
        ci.cancel();
    }
}
