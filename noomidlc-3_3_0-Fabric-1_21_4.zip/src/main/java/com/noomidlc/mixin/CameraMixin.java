package com.noomidlc.mixin;

import com.noomidlc.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freecam: подменяет позицию камеры после обычного расчёта (поворот остаётся от игрока). */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Inject(method = "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V",
            at = @At("TAIL"), require = 0)
    private void noomidlc$freecam(BlockView area, Entity focused, boolean thirdPerson, boolean inverted,
                                   float tickDelta, CallbackInfo ci) {
        if (!Freecam.active()) return;
        double[] p = Freecam.pos(tickDelta);
        setPos(p[0], p[1], p[2]);
    }
}
