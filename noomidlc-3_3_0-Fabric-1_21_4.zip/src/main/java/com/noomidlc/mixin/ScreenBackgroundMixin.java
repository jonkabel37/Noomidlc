package com.noomidlc.mixin;

import com.noomidlc.Config;
import com.noomidlc.MenuFx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Одиночная игра, серверы, настройки и прочие экраны вне мира: фон с эффектами главного меню. */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {
    @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$menuBackground(DrawContext c, int mx, int my, float delta, CallbackInfo ci) {
        if (!Config.menuBgAll) return;
        if (MinecraftClient.getInstance().world != null) return;   // в игре оставляем обычный фон
        Screen self = (Screen) (Object) this;
        if (self.getClass().getName().startsWith("com.noomidlc.")) return;   // свои экраны рисуют фон сами
        MenuFx.draw(c, self.width, self.height, mx, my);
        ci.cancel();
    }
}
