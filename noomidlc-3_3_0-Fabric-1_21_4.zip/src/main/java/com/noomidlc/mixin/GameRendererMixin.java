package com.noomidlc.mixin;

import com.noomidlc.Config;
import com.noomidlc.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No Hurt Cam, No Bob и Zoom (FOV). Все инжекты с require = 0: если метод не найден - просто не работает, без вылета. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.noHurtCam) ci.cancel();
    }

    @Inject(method = "bobView(Lnet/minecraft/client/util/math/MatrixStack;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$noBob(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.noHurtCam && Config.noBob) ci.cancel();
    }

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void noomidlc$zoom(Camera camera, float tickDelta, boolean changingFov,
                                CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue((float) Zoom.apply((double) cir.getReturnValueF()));
    }

    /** Stretch: растягивает картинку по ширине / высоте (как растянутое разрешение). */
    @Inject(method = "getBasicProjectionMatrix(F)Lorg/joml/Matrix4f;", at = @At("RETURN"), cancellable = true, require = 0)
    private void noomidlc$stretch(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        if (Config.stretch) {
            cir.setReturnValue(cir.getReturnValue().scale(Config.stretchX, Config.stretchY, 1.0f));
        }
    }
}
