package com.noomidlc.mixin;

import com.noomidlc.ItemStateExt;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Запоминает, лежит ли предмет на земле (для Item Physics). */
@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements ItemStateExt {
    @Unique
    private boolean noomidlc$onGround;

    @Override
    public boolean noomidlc$isOnGround() {
        return noomidlc$onGround;
    }

    @Override
    public void noomidlc$setOnGround(boolean onGround) {
        this.noomidlc$onGround = onGround;
    }
}
