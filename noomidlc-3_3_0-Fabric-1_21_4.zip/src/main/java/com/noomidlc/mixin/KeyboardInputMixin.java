package com.noomidlc.mixin;

import com.noomidlc.InvMove;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Inventory Move: пока открыт инвентарь, подставляем в ввод игрока реальное состояние клавиш.
 * Это работает независимо от того, что игра делает с состоянием KeyBinding при открытом экране.
 */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick()V", at = @At("TAIL"), require = 0)
    private void noomidlc$invMove(CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!InvMove.active(mc)) return;
        boolean f = InvMove.down(mc, mc.options.forwardKey);
        boolean b = InvMove.down(mc, mc.options.backKey);
        boolean l = InvMove.down(mc, mc.options.leftKey);
        boolean r = InvMove.down(mc, mc.options.rightKey);
        boolean j = InvMove.down(mc, mc.options.jumpKey);
        boolean sn = InvMove.down(mc, mc.options.sneakKey);
        boolean sp = InvMove.down(mc, mc.options.sprintKey);
        Input self = (Input) (Object) this;
        self.playerInput = new PlayerInput(f, b, l, r, j, sn, sp);
        self.movementForward = f == b ? 0.0f : (f ? 1.0f : -1.0f);
        self.movementSideways = l == r ? 0.0f : (l ? 1.0f : -1.0f);
    }
}
