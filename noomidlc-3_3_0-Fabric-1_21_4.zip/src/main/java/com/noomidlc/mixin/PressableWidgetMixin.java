package com.noomidlc.mixin;

import com.noomidlc.ButtonFx;
import com.noomidlc.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Обычные кнопки ванильных экранов рисуем в стиле меню noomidlc. */
@Mixin(PressableWidget.class)
public abstract class PressableWidgetMixin {
    @Inject(method = "renderWidget(Lnet/minecraft/client/gui/DrawContext;IIF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$button(DrawContext c, int mx, int my, float delta, CallbackInfo ci) {
        if (!Config.menuBtn) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen == null) return;
        if (mc.currentScreen.getClass().getName().startsWith("com.noomidlc.")) return;
        PressableWidget self = (PressableWidget) (Object) this;
        Class<?> k = self.getClass();
        if (k != ButtonWidget.class && k != CyclingButtonWidget.class) return;   // иконочные и особые кнопки не трогаем
        ButtonFx.draw(c, self, mx, my);
        ci.cancel();
    }
}
