package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Jump Circle (кольцо от прыжка) и China Hat (китайская шляпа) - рисуются прямо в мире, с глубиной. */
public final class WorldFx {
    private WorldFx() {}

    private static final int SEG = 48;

    private record Circle(double x, double y, double z, long t0) {}

    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final Map<UUID, double[]> LAST = new HashMap<>();   // [Y прошлого тика, был ли на земле]

    // ------------------------------------------------------------ детект прыжка

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) {
            CIRCLES.clear();
            LAST.clear();
            return;
        }
        if (!Config.jumpCircle) {
            if (!CIRCLES.isEmpty()) CIRCLES.clear();
            LAST.clear();
            return;
        }
        long now = System.currentTimeMillis();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p != mc.player && !Config.jcOthers) continue;
            double[] st = LAST.get(p.getUuid());
            boolean ground = p.isOnGround();
            if (st != null && st[1] > 0.5 && !ground && p.getY() - st[0] > 0.02) {
                CIRCLES.add(new Circle(p.getX(), st[0], p.getZ(), now));
            }
            LAST.put(p.getUuid(), new double[]{p.getY(), ground ? 1.0 : 0.0});
        }
        long life = (long) (Config.jcDuration * 1000.0f) + 50L;
        CIRCLES.removeIf(c -> now - c.t0() > life);
        if (CIRCLES.size() > 64) CIRCLES.subList(0, CIRCLES.size() - 64).clear();
    }

    // ------------------------------------------------------------ цвет

    /** RGB для режимов Accent / Rainbow / White (используется и ESP). */
    public static int rgbOf(int mode, float hueOffset) {
        if (mode == 1) {
            float hue = (hueOffset + (System.currentTimeMillis() % 4000L) / 4000.0f) % 1.0f;
            return MathHelper.hsvToRgb(hue, 0.65f, 1.0f) & 0xFFFFFF;
        }
        if (mode == 2) return 0xFFFFFF;
        if (Config.isFlow()) return Config.flow(hueOffset) & 0xFFFFFF;
        return Config.accent() & 0xFFFFFF;
    }

    private static int color(int mode, float hueOffset, float alpha) {
        int rgb = rgbOf(mode, hueOffset);
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }


    /**
     * В 1.21.4 матрица стека мирового рендера может не содержать поворота камеры (он лежит в ctx.positionMatrix()).
     * Из-за этого эффекты были видны только при определённом направлении взгляда и пропадали при повороте.
     * Если в переданной матрице нет поворота, добавляем его из positionMatrix.
     */
    public static Matrix4f fixMatrix(WorldRenderContext ctx, Matrix4f m) {
        boolean noRot = Math.abs(m.m00() - 1.0f) < 1.0e-4f && Math.abs(m.m11() - 1.0f) < 1.0e-4f
                && Math.abs(m.m22() - 1.0f) < 1.0e-4f
                && Math.abs(m.m01()) < 1.0e-4f && Math.abs(m.m02()) < 1.0e-4f
                && Math.abs(m.m10()) < 1.0e-4f && Math.abs(m.m12()) < 1.0e-4f
                && Math.abs(m.m20()) < 1.0e-4f && Math.abs(m.m21()) < 1.0e-4f;
        if (!noRot) return m;
        Matrix4f pm = ctx.positionMatrix();
        if (pm == null) return m;
        return new Matrix4f(pm).mul(m);
    }

    // ------------------------------------------------------------ рендер

    public static void render(WorldRenderContext ctx) {
        boolean circles = Config.jumpCircle && !CIRCLES.isEmpty();
        if (!circles && !Config.chinaHat) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(true);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = WorldFx.fixMatrix(ctx, ms.peek().getPositionMatrix());

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        if (circles) drawCircles(mat);
        if (Config.chinaHat) drawHats(mc, mat, td);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static void drawCircles(Matrix4f mat) {
        long now = System.currentTimeMillis();
        float dur = Math.max(0.2f, Config.jcDuration) * 1000.0f;
        Iterator<Circle> it = CIRCLES.iterator();
        while (it.hasNext()) {
            Circle c = it.next();
            float t = (now - c.t0()) / dur;
            if (t >= 1.0f) continue;
            float ease = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
            float r = 0.25f + (Config.jcRadius - 0.25f) * ease;
            float alpha = (1.0f - t);
            float band = Math.min(r, 0.30f);
            float y = (float) c.y() + 0.02f;
            float cx = (float) c.x(), cz = (float) c.z();

            // мягкая полоса: прозрачная внутри, плотная снаружи
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= SEG; i++) {
                float h = (float) i / SEG;
                double a = h * Math.PI * 2.0;
                float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
                int col = color(Config.jcColor, h, alpha * 0.85f);
                int clear = color(Config.jcColor, h, 0.0f);
                b.vertex(mat, cx + cs * (r - band), y, cz + sn * (r - band)).color(clear);
                b.vertex(mat, cx + cs * r, y, cz + sn * r).color(col);
            }
            Ui.flush(b);

            // тонкий яркий контур
            BufferBuilder o = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= SEG; i++) {
                float h = (float) i / SEG;
                double a = h * Math.PI * 2.0;
                float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
                int col = color(Config.jcColor, h, Math.min(1.0f, alpha * 1.2f));
                o.vertex(mat, cx + cs * (r - 0.035f), y + 0.002f, cz + sn * (r - 0.035f)).color(col);
                o.vertex(mat, cx + cs * (r + 0.02f), y + 0.002f, cz + sn * (r + 0.02f)).color(col);
            }
            Ui.flush(o);
        }
    }

    private static void drawHats(MinecraftClient mc, Matrix4f mat, float td) {
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) {
                if (firstPerson) continue;
            } else if (!Config.chOthers) {
                continue;
            }
            if (p.isInvisible() || !p.isAlive()) continue;

            Vec3d pos = p.getLerpedPos(td);
            float baseY = (float) pos.y + p.getHeight() + 0.02f;
            float apexY = baseY + Config.chHeight;
            float cx = (float) pos.x, cz = (float) pos.z;
            float r = Config.chRadius;
            float al = Config.chAlpha;

            // конус: вершина плотнее, края прозрачнее
            BufferBuilder cone = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
            cone.vertex(mat, cx, apexY, cz).color(color(Config.chColor, 0.0f, al));
            for (int i = 0; i <= SEG; i++) {
                float h = (float) i / SEG;
                double a = h * Math.PI * 2.0;
                cone.vertex(mat, cx + (float) Math.cos(a) * r, baseY, cz + (float) Math.sin(a) * r)
                        .color(color(Config.chColor, h, al * 0.55f));
            }
            Ui.flush(cone);

            // яркий ободок по краю
            BufferBuilder rim = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= SEG; i++) {
                float h = (float) i / SEG;
                double a = h * Math.PI * 2.0;
                float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
                int col = color(Config.chColor, h, Math.min(1.0f, al + 0.3f));
                rim.vertex(mat, cx + cs * (r - 0.03f), baseY, cz + sn * (r - 0.03f)).color(col);
                rim.vertex(mat, cx + cs * (r + 0.015f), baseY, cz + sn * (r + 0.015f)).color(col);
            }
            Ui.flush(rim);
        }
    }
}
