package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/** Анимированный Target HUD: плавное появление, плавная полоска здоровья и красный "хвост" урона. */
public final class TargetHud {
    private TargetHud() {}

    private static LivingEntity shown;
    private static float alpha, hp, trail;
    private static long lastSeen;

    private static int col(int rgb, float a) {
        return (Math.max(0, Math.min(255, Math.round(a * 255.0f))) << 24) | (rgb & 0xFFFFFF);
    }

    public static void render(DrawContext ctx, MinecraftClient mc, int sw, int sh, int accent) {
        Anim.frame();
        long now = System.currentTimeMillis();
        PlayerEntity cand = null;
        if (KillAura.target() instanceof PlayerEntity p && p.isAlive()) cand = p;
        else if (mc.targetedEntity instanceof PlayerEntity p2 && p2.isAlive() && p2 != mc.player) cand = p2;

        if (cand != null) {
            if (cand != shown) {
                shown = cand;
                float r = MathHelper.clamp(cand.getHealth() / Math.max(1.0f, cand.getMaxHealth()), 0.0f, 1.0f);
                hp = trail = r;
            }
            lastSeen = now;
        }
        boolean want = shown != null && shown.isAlive() && now - lastSeen < 1500L;
        alpha = Anim.smooth(alpha, want ? 1.0f : 0.0f, 10.0f);
        if (alpha <= 0.01f) {
            if (!want) shown = null;
            return;
        }
        if (shown == null) return;

        float ratio = MathHelper.clamp(shown.getHealth() / Math.max(1.0f, shown.getMaxHealth()), 0.0f, 1.0f);
        hp = Anim.smooth(hp, ratio, 14.0f);
        trail = ratio > trail ? ratio : Anim.smooth(trail, ratio, 2.5f);

        int w = 150, h = 40;
        int x = sw / 2 - w / 2;
        int y = sh / 2 + 34 + Math.round((1.0f - alpha) * 10.0f);
        ctx.fill(x, y, x + w, y + h, col(0x101018, alpha * 0.8f));
        ctx.fill(x, y, x + 2, y + h, col(accent, alpha));

        String name = shown.getName().getString();
        ctx.drawText(mc.textRenderer, name, x + 8, y + 6, col(0xFFFFFF, alpha), true);
        String info = String.format(Locale.ROOT, "%.1f HP  %.1fm", shown.getHealth(), mc.player.distanceTo(shown));
        ctx.drawText(mc.textRenderer, info, x + 8, y + 17, col(0xB8B8C8, alpha), true);

        int bx = x + 8, by = y + 29, bw = w - 16, bh = 6;
        ctx.fill(bx, by, bx + bw, by + bh, col(0x353541, alpha));
        ctx.fill(bx, by, bx + Math.round(bw * trail), by + bh, col(0xFF8A8A, alpha * 0.7f));
        int bar = hp > 0.5f ? 0x55DD88 : hp > 0.25f ? 0xFFC04D : 0xFF5555;
        ctx.fill(bx, by, bx + Math.round(bw * hp), by + bh, col(bar, alpha));
    }
}
