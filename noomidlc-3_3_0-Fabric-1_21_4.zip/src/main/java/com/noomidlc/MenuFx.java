package com.noomidlc;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Анимированный фон главного меню, используется на всех остальных экранах меню (миры, серверы, настройки). */
public final class MenuFx {
    private MenuFx() {}

    private static final long START = System.currentTimeMillis();
    private static final float[][] PT = new float[60][5];      // светлячки: x, y (0..1), скорость, размер, фаза
    private static final float[][] ORBS = new float[6][4];     // шары: x, y (0..1), радиус, фаза
    private static final List<float[]> STARS = new ArrayList<>();
    private static final List<float[]> FX = new ArrayList<>(); // x, y, vx, vy, жизнь, макс. жизнь, размер, оттенок
    private static float nextStar = 1.2f, sparkAcc = 0.0f, lastMx = -1.0f, lastMy = -1.0f;
    private static long lastNs = System.nanoTime();

    static {
        Random r = new Random(11);
        for (float[] p : PT) {
            p[0] = r.nextFloat();
            p[1] = r.nextFloat();
            p[2] = 0.01f + r.nextFloat() * 0.03f;
            p[3] = 0.7f + r.nextFloat() * 1.4f;
            p[4] = r.nextFloat() * 6.28f;
        }
        for (float[] o : ORBS) {
            o[0] = r.nextFloat();
            o[1] = r.nextFloat();
            o[2] = 60.0f + r.nextFloat() * 70.0f;
            o[3] = r.nextFloat() * 6.28f;
        }
    }

    private static void circle(DrawContext c, float cx, float cy, float r, int color) {
        Ui.rrectF(c, cx - r, cy - r, r * 2.0f, r * 2.0f, r, color);
    }

    public static void draw(DrawContext c, int w, int h, int mx, int my) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1.0e9f);
        lastNs = now;
        float t = (System.currentTimeMillis() - START) / 1000.0f;
        int acc = Config.accent() | 0xFF000000;

        // фон: градиент, световые столбы, подсветка снизу
        c.fillGradient(0, 0, w, h, Ui.mix(0xFF0A0A14, acc, 0.10f), Ui.mix(0xFF050509, acc, 0.04f));
        for (int i = 0; i < 4; i++) {
            float x = w * (0.12f + 0.25f * i) + (float) Math.sin(t * 0.25f + i * 1.7f) * 50.0f;
            float bw = 46.0f + 26.0f * (i % 2);
            c.fillGradient(Math.round(x), 0, Math.round(x + bw), h, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.06f + 0.02f * (i % 2)));
        }
        c.fillGradient(0, Math.round(h * 0.55f), w, h, Ui.alpha(acc, 0.0f), Ui.alpha(acc, 0.20f));

        // мягкий свет вслед за курсором
        for (int k = 4; k >= 1; k--) {
            circle(c, mx, my, 22.0f + k * 16.0f, Ui.alpha(acc, 0.018f * (5 - k)));
        }

        boolean fx = Config.menuFx();
        if (fx) {
            drawOrbs(c, w, h, t, acc);
            drawAurora(c, w, h, t, acc);
        }

        // падающие звёзды
        nextStar -= dt;
        if (nextStar <= 0.0f) {
            nextStar = 1.8f + (float) Math.random() * 3.5f;
            STARS.add(new float[]{(float) Math.random() * w * 0.9f, -10.0f, 150.0f + (float) Math.random() * 90.0f, 110.0f + (float) Math.random() * 60.0f, 1.0f});
        }
        for (int i = STARS.size() - 1; i >= 0; i--) {
            float[] st = STARS.get(i);
            st[0] += st[2] * dt;
            st[1] += st[3] * dt;
            st[4] -= dt * 0.55f;
            if (st[4] <= 0.0f || st[1] > h + 20 || st[0] > w + 40) {
                STARS.remove(i);
                continue;
            }
            float ln = (float) Math.sqrt(st[2] * st[2] + st[3] * st[3]);
            float ux = st[2] / ln, uy = st[3] / ln;
            for (int q = 0; q < 8; q++) {
                float a = (1.0f - q / 8.0f) * Math.min(1.0f, st[4] * 2.0f) * 0.85f;
                circle(c, st[0] - ux * q * 4.0f, st[1] - uy * q * 4.0f, 1.9f - q * 0.15f, Ui.alpha(q == 0 ? 0xFFFFFFFF : acc, a));
            }
        }

        // светлячки с лёгким параллаксом от курсора
        float pxo = (mx - w / 2.0f) * 0.02f, pyo = (my - h / 2.0f) * 0.02f;
        for (float[] p : PT) {
            p[1] -= p[2] * dt;
            p[0] += (float) Math.sin(p[4] + t * 0.5f) * 0.00035f;
            if (p[1] < -0.02f) p[1] = 1.02f;
            float x = p[0] * w + pxo * p[3];
            float y = p[1] * h + pyo * p[3];
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.0f + p[4]);
            circle(c, x, y, p[3] * 2.4f, Ui.alpha(acc, 0.10f * tw));
            circle(c, x, y, p[3] * 0.65f, Ui.alpha(0xFFFFFF, 0.25f + 0.55f * tw));
        }

        // искры и хвост за курсором
        if (fx) {
            sparkAcc += dt * 14.0f;
            while (sparkAcc >= 1.0f) {
                sparkAcc -= 1.0f;
                emit((float) Math.random() * w, h * (0.3f + (float) Math.random() * 0.8f),
                        ((float) Math.random() - 0.5f) * 8.0f, -8.0f - (float) Math.random() * 16.0f,
                        2.2f + (float) Math.random() * 2.5f, 1.2f + (float) Math.random() * 1.6f, (float) Math.random(), 1);
            }
            if (lastMx >= 0.0f && Math.hypot(mx - lastMx, my - lastMy) > 2.0f) {
                for (int i = 0; i < 2; i++) {
                    emit(mx, my, ((float) Math.random() - 0.5f) * 22.0f, ((float) Math.random() - 0.5f) * 22.0f,
                            0.45f + (float) Math.random() * 0.4f, 1.0f + (float) Math.random(), (float) Math.random(), 0);
                }
            }
            lastMx = mx;
            lastMy = my;
        }
        drawFx(c, dt, acc);
    }

    private static void drawOrbs(DrawContext c, int w, int h, float t, int acc) {
        for (int i = 0; i < ORBS.length; i++) {
            float[] o = ORBS[i];
            float x = o[0] * w + (float) Math.sin(t * 0.17f + o[3]) * 60.0f;
            float y = o[1] * h + (float) Math.cos(t * 0.13f + o[3] * 1.3f) * 40.0f;
            int col = Ui.mix(acc, i % 2 == 0 ? 0xFF7BDFF2 : 0xFFFF8FAB, 0.35f);
            for (int k = 6; k >= 1; k--) circle(c, x, y, o[2] * k / 6.0f, Ui.alpha(col, 0.012f));
        }
    }

    private static void drawAurora(DrawContext c, int w, int h, float t, int acc) {
        int step = 8;
        int[] cols = {acc, Ui.mix(acc, 0xFF7BDFF2, 0.7f), Ui.mix(acc, 0xFFFF8FAB, 0.6f)};
        for (int b = 0; b < cols.length; b++) {
            for (int x = 0; x < w; x += step) {
                float w1 = (float) Math.sin(x * 0.008f + t * 0.35f + b * 2.1f);
                float w2 = (float) Math.sin(x * 0.019f - t * 0.55f + b);
                float yc = h * (0.20f + 0.09f * b) + w1 * h * 0.06f + w2 * 8.0f;
                float amp = 0.5f + 0.5f * (float) Math.sin(x * 0.004f + t * 0.3f + b * 1.7f);
                float a = 0.020f + 0.030f * amp;
                c.fillGradient(x, Math.round(yc - 34), x + step, Math.round(yc), Ui.alpha(cols[b], 0.0f), Ui.alpha(cols[b], a));
                c.fillGradient(x, Math.round(yc), x + step, Math.round(yc + 26), Ui.alpha(cols[b], a), Ui.alpha(cols[b], 0.0f));
            }
        }
    }

    private static void emit(float x, float y, float vx, float vy, float life, float size, float hue, int kind) {
        if (FX.size() > 500) return;
        FX.add(new float[]{x, y, vx, vy, life, life, size, hue, kind});
    }

    private static void drawFx(DrawContext c, float dt, int acc) {
        for (int i = FX.size() - 1; i >= 0; i--) {
            float[] f = FX.get(i);
            f[4] -= dt;
            if (f[4] <= 0.0f) {
                FX.remove(i);
                continue;
            }
            f[0] += f[2] * dt;
            f[1] += f[3] * dt;
            float k = f[4] / f[5];
            float fade = Math.min(1.0f, k * 2.5f) * Math.min(1.0f, (1.0f - k) * 6.0f + 0.2f);
            int col = Ui.mix(Ui.mix(acc, 0xFF7BDFF2, f[7]), 0xFFFFFFFF, 0.3f);
            if ((int) f[8] == 1) {
                float tw = 0.6f + 0.4f * (float) Math.sin(f[4] * 9.0f + f[7] * 6.28f);
                float L = f[6] * 2.6f * tw;
                Ui.rrectF(c, f[0] - L, f[1] - 0.5f, L * 2.0f, 1.0f, 0.5f, Ui.alpha(col, 0.85f * fade));
                Ui.rrectF(c, f[0] - 0.5f, f[1] - L, 1.0f, L * 2.0f, 0.5f, Ui.alpha(col, 0.85f * fade));
                circle(c, f[0], f[1], f[6] * 1.8f, Ui.alpha(col, 0.14f * fade));
                circle(c, f[0], f[1], f[6] * 0.6f, Ui.alpha(0xFFFFFFFF, 0.9f * fade));
            } else {
                circle(c, f[0], f[1], f[6] * 2.6f, Ui.alpha(col, 0.12f * fade));
                circle(c, f[0], f[1], f[6], Ui.alpha(col, 0.85f * fade));
            }
        }
    }
}
