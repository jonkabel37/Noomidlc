package com.noomidlc;

import net.minecraft.client.MinecraftClient;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Список всех модулей (один источник правды для меню и для клавиш включения). */
public final class Modules {
    private Modules() {}

    public record Mod(String id, String label, BooleanSupplier get, Consumer<Boolean> set) {}

    private static final Map<String, Mod> MODS = new LinkedHashMap<>();
    private static final Map<String, Boolean> DOWN = new HashMap<>();

    private static void add(String id, String label, BooleanSupplier g, Consumer<Boolean> s) {
        MODS.put(id, new Mod(id, label, g, s));
    }

    static {
        add("esp", "ESP", () -> Config.esp, v -> Config.esp = v);
        add("seeinv", "See invisibles", () -> Config.seeInvisibles, v -> Config.seeInvisibles = v);
        add("nametags", "NameTags", () -> Config.nameTags, v -> Config.nameTags = v);
        add("fullbright", "Fullbright", () -> Config.fullbright, v -> Config.fullbright = v);
        add("itemphysics", "Item Physics", () -> Config.itemPhysics, v -> Config.itemPhysics = v);
        add("jumpcircle", "Jump Circle", () -> Config.jumpCircle, v -> Config.jumpCircle = v);
        add("chinahat", "China Hat", () -> Config.chinaHat, v -> Config.chinaHat = v);
        add("noparticles", "No Particles", () -> Config.noParticles, v -> Config.noParticles = v);
        add("nohurtcam", "No Hurt Cam", () -> Config.noHurtCam, v -> Config.noHurtCam = v);
        add("nofire", "No Fire Overlay", () -> Config.noFire, v -> Config.noFire = v);
        add("zoom", "Zoom", () -> Config.zoom, v -> Config.zoom = v);
        add("viewmodel", "ViewModel", () -> Config.viewModel, v -> Config.viewModel = v);
        add("swing", "Swing Animation", () -> Config.swingAnim, v -> Config.swingAnim = v);
        add("hitinfo", "Hit Info", () -> Config.hitInfo, v -> Config.hitInfo = v);
        add("killaura", "Kill Aura", () -> Config.killAura, v -> Config.killAura = v);
        add("legitaura", "Legit Aura", () -> Config.legitAura, v -> Config.legitAura = v);
        add("particles", "Particles", () -> Config.fxParticles, v -> Config.fxParticles = v);
        add("triggerbot", "Trigger Bot", () -> Config.triggerBot, v -> Config.triggerBot = v);
        add("autototem", "Auto Totem", () -> Config.autoTotem, v -> Config.autoTotem = v);
        add("clickpearl", "Click Pearl", () -> Config.clickPearl, v -> Config.clickPearl = v);
        add("clickwind", "Click Wind Charge", () -> Config.clickWind, v -> Config.clickWind = v);
        add("invmove", "Inventory Move", () -> Config.invMove, v -> Config.invMove = v);
        add("blockesp", "Block ESP", () -> Config.blockEsp, v -> Config.blockEsp = v);
        add("blockfx", "Block Effect", () -> Config.blockFx, v -> Config.blockFx = v);
        add("fly", "Fly", () -> Config.fly, v -> Config.fly = v);
        add("spider", "Spider", () -> Config.spider, v -> Config.spider = v);
        add("noweb", "No Web", () -> Config.noWeb, v -> Config.noWeb = v);
        add("airswim", "Air Swim", () -> Config.airSwim, v -> Config.airSwim = v);
        add("airstuck", "Air Stuck", () -> Config.airStuck, v -> Config.airStuck = v);
        add("sky", "Custom Sky", () -> Config.sky, v -> Config.sky = v);
        add("stretch", "Stretch", () -> Config.stretch, v -> Config.stretch = v);
        add("ambient", "Ambient", () -> Config.ambient, v -> Config.ambient = v);
        add("cinematic", "Cinematic", () -> Config.cinematic, v -> Config.cinematic = v);
        add("reach", "Reach", () -> Config.reach, v -> Config.reach = v);
        add("nofall", "No Fall", () -> Config.noFall, v -> Config.noFall = v);
        add("jesus", "Jesus", () -> Config.jesus, v -> Config.jesus = v);
        add("antiafk", "Anti AFK", () -> Config.antiAfk, v -> Config.antiAfk = v);
        add("noclip", "No Clip", () -> Config.noClip, v -> Config.noClip = v);
        add("autosprint", "Auto Sprint", () -> Config.autoSprint, v -> Config.autoSprint = v);
        add("aimassist", "Aim Assist", () -> Config.aimAssist, v -> Config.aimAssist = v);
        add("projaim", "Projectile Aim", () -> Config.projAim, v -> Config.projAim = v);
        add("killfx", "Kill Effect", () -> Config.killFx, v -> Config.killFx = v);
        add("freecam", "Freecam", () -> Config.freecam, v -> Config.freecam = v);
        add("fovchanger", "FOV Changer", () -> Config.fovChanger, v -> Config.fovChanger = v);
        add("autotool", "Auto Tool", () -> Config.autoTool, v -> Config.autoTool = v);
        add("autoeat", "Auto Eat", () -> Config.autoEat, v -> Config.autoEat = v);
        add("autowalk", "Auto Walk", () -> Config.autoWalk, v -> Config.autoWalk = v);
        add("noweather", "No Weather", () -> Config.noWeather, v -> Config.noWeather = v);
        add("trails", "Trails", () -> Config.trails, v -> Config.trails = v);
        add("deathcoords", "Death Coords", () -> Config.deathCoords, v -> Config.deathCoords = v);
        add("invsort", "Inventory Sorter", () -> Config.invSort, v -> Config.invSort = v);
        add("reconnect", "Auto Reconnect", () -> Config.autoReconnect, v -> Config.autoReconnect = v);
        add("chattime", "Chat Timestamps", () -> Config.chatTime, v -> Config.chatTime = v);
        add("notify", "Notifications", () -> Config.notify, v -> Config.notify = v);
        add("infopanel", "Info Panel", () -> Config.infoPanel, v -> Config.infoPanel = v);
        add("autorespawn", "Auto Respawn", () -> Config.autoRespawn, v -> Config.autoRespawn = v);
    }

    public static Mod get(String id) {
        return MODS.get(id);
    }

    public static Collection<Mod> all() {
        return MODS.values();
    }

    /** Клавиши включения/выключения модулей (работают только когда нет открытого экрана). */
    public static void tick(MinecraftClient mc) {
        boolean free = mc.currentScreen == null && mc.player != null;
        for (Mod m : MODS.values()) {
            int code = Config.bind(m.id());
            boolean d = free && code != -1 && Actions.isDown(mc, code);
            if (d && !DOWN.getOrDefault(m.id(), false)) {
                m.set().accept(!m.get().getAsBoolean());
            }
            DOWN.put(m.id(), d);
        }
    }
}
