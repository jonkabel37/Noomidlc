package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;

/**
 * FPS Boost: убирает частицы и временно переключает ванильные настройки графики на лёгкие.
 * При выключении модуля (или отдельной опции) прежние значения возвращаются.
 */
public final class FpsBoost {
    private FpsBoost() {}

    private static int timer = 0;

    // что именно мы изменили и какое значение было раньше
    private static boolean chShadows, chClouds, chGfx, chBlend, chDist;
    private static boolean oShadows;
    private static CloudRenderMode oClouds;
    private static GraphicsMode oGfx;
    private static int oBlend;
    private static double oDist;

    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        // сверяем настройки раз в полсекунды, чтобы переключатели в меню действовали сразу
        if (timer-- > 0) return;
        timer = 10;
        GameOptions o = mc.options;
        boolean on = Config.fpsBoost;

        // частицы режет ParticleManagerMixin (см. ParticleFilter.active)

        // тени сущностей
        if (on && Config.fbShadows) {
            if (!chShadows) {
                oShadows = o.getEntityShadows().getValue();
                chShadows = true;
            }
            if (o.getEntityShadows().getValue()) o.getEntityShadows().setValue(false);
        } else if (chShadows) {
            o.getEntityShadows().setValue(oShadows);
            chShadows = false;
        }

        // облака
        if (on && Config.fbClouds) {
            if (!chClouds) {
                oClouds = o.getCloudRenderMode().getValue();
                chClouds = true;
            }
            if (o.getCloudRenderMode().getValue() != CloudRenderMode.OFF) o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        } else if (chClouds) {
            o.getCloudRenderMode().setValue(oClouds);
            chClouds = false;
        }

        // быстрая графика (вместо Fancy / Fabulous)
        if (on && Config.fbFastGfx) {
            if (!chGfx) {
                oGfx = o.getGraphicsMode().getValue();
                chGfx = true;
            }
            if (o.getGraphicsMode().getValue() != GraphicsMode.FAST) o.getGraphicsMode().setValue(GraphicsMode.FAST);
        } else if (chGfx) {
            o.getGraphicsMode().setValue(oGfx);
            chGfx = false;
        }

        // сглаживание цвета биомов
        if (on && Config.fbBlend) {
            if (!chBlend) {
                oBlend = o.getBiomeBlendRadius().getValue();
                chBlend = true;
            }
            if (o.getBiomeBlendRadius().getValue() != 0) o.getBiomeBlendRadius().setValue(0);
        } else if (chBlend) {
            o.getBiomeBlendRadius().setValue(oBlend);
            chBlend = false;
        }

        // дальность прорисовки сущностей
        if (on && Config.fbEntDist) {
            if (!chDist) {
                oDist = o.getEntityDistanceScaling().getValue();
                chDist = true;
            }
            if (o.getEntityDistanceScaling().getValue() > 0.5) o.getEntityDistanceScaling().setValue(0.5);
        } else if (chDist) {
            o.getEntityDistanceScaling().setValue(oDist);
            chDist = false;
        }
    }
}
