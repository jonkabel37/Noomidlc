package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Общая логика критов для Kill Aura и Legit Aura: бьём только в момент настоящего ванильного крита (падение после прыжка). */
public final class Crit {
    private Crit() {}

    /** Пока true - Auto Sprint не включает бег (в спринте крита нет). */
    public static boolean suppress = false;
    private static boolean jumpHeld = false;

    private static boolean resprint = false;

    private static boolean groundOk(ClientPlayerEntity p) {
        return p.isOnGround() && !p.isClimbing() && !p.isTouchingWater() && !p.isInLava()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !p.hasVehicle() && !p.getAbilities().flying;
    }

    /** Ground Crits: перед ударом шлём короткий "прыжок" (вверх и вниз без земли), чтобы удар засчитался критом. */
    public static void groundCritBefore(MinecraftClient mc, ClientPlayerEntity p) {
        resprint = false;
        ClientPlayNetworkHandler net = mc.getNetworkHandler();
        if (!Config.critGround || net == null || !groundOk(p)) return;
        if (p.isSprinting()) {   // в спринте крита нет - на момент удара сбрасываем бег
            net.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            resprint = true;
        }
        double x = p.getX(), y = p.getY(), z = p.getZ();
        boolean hc = p.horizontalCollision;
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, hc));
        net.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
    }

    /** Вызывается сразу после удара: возвращает бег, если мы его сбрасывали. */
    public static void groundCritAfter(MinecraftClient mc, ClientPlayerEntity p) {
        if (!resprint) return;
        resprint = false;
        ClientPlayNetworkHandler net = mc.getNetworkHandler();
        if (net != null && p.isSprinting()) net.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_SPRINTING));
    }

    /** Условия ванильного крита (их же проверяет сервер). */
    public static boolean ready(ClientPlayerEntity p) {
        if (Config.critGround && groundOk(p)) return !p.isSprinting();   // с Ground Crits крит возможен и на земле
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.isInLava()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting()
                && !p.getAbilities().flying;
    }

    /** Готовит почву для крита: гасит бег и (по желанию) прыгает с земли. */
    public static void prepare(MinecraftClient mc, ClientPlayerEntity p) {
        suppress = true;
        if (p.isSprinting()) p.setSprinting(false);
        if (Config.critJump && !Config.critGround && p.isOnGround() && !p.isTouchingWater() && !p.isClimbing()
                && !p.hasVehicle() && mc.currentScreen == null) {
            mc.options.jumpKey.setPressed(true);
            jumpHeld = true;
        } else if (jumpHeld) {
            release(mc);
        }
    }

    public static void release(MinecraftClient mc) {
        if (jumpHeld) {
            mc.options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
    }
}
