package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Общая логика критов для Kill Aura и Legit Aura: бьём только в момент настоящего ванильного крита (падение после прыжка). */
public final class Crit {
    private Crit() {}

    /** Пока true - Auto Sprint не включает бег (в спринте крита нет). */
    public static boolean suppress = false;
    private static boolean jumpHeld = false;

    /** Условия ванильного крита (их же проверяет сервер). */
    public static boolean ready(ClientPlayerEntity p) {
        return p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.isInLava()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting()
                && !p.getAbilities().flying;
    }

    /** Готовит почву для крита: гасит бег и (по желанию) прыгает с земли. */
    public static void prepare(MinecraftClient mc, ClientPlayerEntity p) {
        suppress = true;
        if (p.isSprinting()) p.setSprinting(false);
        if (Config.critJump && p.isOnGround() && !p.isTouchingWater() && !p.isClimbing()
                && !p.hasVehicle() && mc.currentScreen == null) {
            mc.options.jumpKey.setPressed(true);
            jumpHeld = true;
        } else if (jumpHeld) {
            release(mc);
        }
    }

    public static void release(MinecraftClient mc) {
        if (jumpHeld) {
            mc.options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
    }
}
