package com.noomidlc;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Всплывающие цифры урона над целями и звук попадания. */
public final class HitFx {
    private HitFx() {}

    private static final Map<Integer, Float> HP = new HashMap<>();
    private static final List<float[]> NUMS = new ArrayList<>();   // x, y, z, возраст, урон
    private static final List<float[]> SCR = new ArrayList<>();    // экранные x, y, прозрачность, урон
    private static int swingAge = 99;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || (!Config.damageNumbers && !Config.hitSound)) {
            HP.clear();
            NUMS.clear();
            return;
        }
        swingAge = p.handSwinging ? 0 : swingAge + 1;
        Set<Integer> seen = new HashSet<>();
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(40.0),
                x -> x != p && x.isAlive() && !(x instanceof ArmorStandEntity))) {
            int id = e.getId();
            seen.add(id);
            float hp = e.getHealth() + e.getAbsorptionAmount();
            Float prev = HP.put(id, hp);
            if (prev != null && hp < prev - 0.05f) {
                float dmg = prev - hp;
                if (Config.damageNumbers) {
                    NUMS.add(new float[]{(float) e.getX() + (float) (Math.random() - 0.5) * 0.8f,
                            (float) (e.getY() + e.getHeight() + 0.1), (float) e.getZ() + (float) (Math.random() - 0.5) * 0.8f, 0.0f, dmg});
                }
                if (Config.hitSound && swingAge <= 6 && p.distanceTo(e) < 7.0f) playHit(mc);
            }
        }
        HP.keySet().retainAll(seen);
        for (Iterator<float[]> it = NUMS.iterator(); it.hasNext(); ) {
            float[] n = it.next();
            n[3] += 1.0f;
            n[1] += 0.03f;
            if (n[3] > 26.0f) it.remove();
        }
    }

    private static void playHit(MinecraftClient mc) {
        SoundEvent s = switch (Config.hsSound) {
            case 1 -> SoundEvents.ENTITY_ARROW_HIT_PLAYER;
            case 2 -> SoundEvents.ENTITY_ITEM_PICKUP;
            case 3 -> SoundEvents.ENTITY_PLAYER_ATTACK_CRIT;
            default -> SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
        };
        mc.getSoundManager().play(PositionedSoundInstance.master(s, 1.0f, Config.hsVolume));
    }

    /** Переводим мировые точки цифр в экранные (как NameTags). */
    public static void collect(WorldRenderContext ctx) {
        SCR.clear();
        if (!Config.damageNumbers || NUMS.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        for (float[] n : NUMS) {
            Vector4f v = new Vector4f((float) (n[0] - cam.x), (float) (n[1] - cam.y), (float) (n[2] - cam.z), 1.0f);
            v.mul(view);
            v.mul(proj);
            if (v.w <= 0.05f) continue;
            float nx = v.x / v.w, ny = v.y / v.w;
            if (Math.abs(nx) > 1.2f || Math.abs(ny) > 1.2f) continue;
            SCR.add(new float[]{(nx * 0.5f + 0.5f) * sw, (1.0f - (ny * 0.5f + 0.5f)) * sh, 1.0f - n[3] / 26.0f, n[4]});
        }
    }

    public static void draw(DrawContext c) {
        if (SCR.isEmpty() || !Config.damageNumbers) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        MatrixStack m = c.getMatrices();
        for (float[] s : SCR) {
            String txt = String.format(Locale.ROOT, "-%.1f", s[3]);
            int col = s[3] >= 6.0f ? 0xFFFF5555 : 0xFFFFD166;
            int w = Ui.width(mc.textRenderer, txt);
            m.push();
            m.translate(s[0], s[1], 0.0f);
            m.scale(Config.dnScale, Config.dnScale, 1.0f);
            Ui.textF(c, mc.textRenderer, txt, -w / 2.0f, 0, Ui.alpha(col, Math.min(1.0f, s[2] * 1.5f)));
            m.pop();
        }
    }
}
