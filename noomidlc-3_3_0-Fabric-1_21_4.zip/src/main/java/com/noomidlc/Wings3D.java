package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * 3D Wings: настоящие трёхмерные крылья за спиной игрока. Каждое перо - объёмная пластина в мире,
 * с освещением по нормали, глубиной (скрываются за телом и блоками) и взмахом.
 */
public final class Wings3D {
    private Wings3D() {}

    public static void render(WorldRenderContext ctx) {
        if (!Config.wings3d) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Matrix4f mat = WorldFx.fixMatrix(ctx, null);
        float td = ctx.tickCounter().getTickDelta(true);
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        double time = (System.currentTimeMillis() % 1_000_000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) {
                if (firstPerson) continue;
            } else if (!Config.wgOthers) {
                continue;
            }
            if (p.isInvisible() || !p.isAlive() || p.isSpectator()) continue;
            drawPlayer(mat, p, td, time);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void drawPlayer(Matrix4f mat, PlayerEntity p, float td, double time) {
        Vec3d pos = p.getLerpedPos(td);
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
        float fx = (float) -Math.sin(yaw), fz = (float) Math.cos(yaw);   // вперёд
        Vector3f back = new Vector3f(-fx, 0.0f, -fz);
        Vector3f right = new Vector3f(-fz, 0.0f, fx);                    // вправо относительно взгляда тела
        right.set((float) -Math.cos(yaw), 0.0f, (float) -Math.sin(yaw));
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);

        float sz = Config.wgSize;
        boolean air = !p.isOnGround() && !p.isTouchingWater();
        double speed = Config.wgSpeed * (air ? 2.6 : 1.0);
        float flap = (float) Math.sin(time * 3.2 * speed);
        float spread = air ? 1.0f : 0.0f;
        float sneak = p.isSneaking() ? -0.2f : 0.0f;

        Vector3f base = new Vector3f((float) pos.x, (float) pos.y + p.getHeight() * 0.72f + sneak, (float) pos.z);
        base.add(new Vector3f(back).mul(0.16f));

        int n = Math.max(3, Math.min(10, Math.round(Config.wgFeathers)));
        for (int side = -1; side <= 1; side += 2) {
            Vector3f o = new Vector3f(base).add(new Vector3f(right).mul(side * 0.10f));
            Vector3f out = new Vector3f(right).mul(side);
            for (int layer = 0; layer < 2; layer++) {
                for (int i = 0; i < n; i++) {
                    float k = n == 1 ? 0.0f : (float) i / (n - 1);
                    float angle = -28.0f + k * 100.0f
                            + flap * (16.0f + 10.0f * spread) * (1.0f - k * 0.35f)
                            + (layer == 0 ? 4.0f : 0.0f);
                    double ar = Math.toRadians(angle);
                    Vector3f dir = new Vector3f(out).mul((float) Math.cos(ar))
                            .add(new Vector3f(up).mul((float) Math.sin(ar)))
                            .add(new Vector3f(back).mul(0.40f - 0.25f * spread + k * 0.1f));
                    dir.normalize();
                    float len = (layer == 0 ? 0.80f : 0.92f) * sz * (1.0f - 0.09f * Math.abs(k - 0.7f) * 4.0f);
                    float w = (layer == 0 ? 0.075f : 0.085f) * sz;
                    float lift = layer == 0 ? -0.02f * sz : 0.0f;
                    Vector3f origin = new Vector3f(o).add(0.0f, lift, 0.0f).add(new Vector3f(back).mul(layer == 0 ? 0.015f : 0.0f));
                    feather(mat, origin, dir, back, len, w, k, layer);
                }
            }
        }
    }

    private static void feather(Matrix4f mat, Vector3f o, Vector3f dir, Vector3f back, float len, float w, float k, int layer) {
        // ширина пера идёт вдоль "назад", ортогонально направлению пера
        Vector3f wv = new Vector3f(back).sub(new Vector3f(dir).mul(back.dot(dir)));
        if (wv.lengthSquared() < 1.0e-6f) return;
        wv.normalize();
        Vector3f n = new Vector3f(dir).cross(wv).normalize();
        Vector3f light = new Vector3f(0.35f, 0.85f, 0.4f).normalize();
        float shade = 0.55f + 0.45f * Math.abs(n.dot(light));

        int rgb = WorldFx.rgbOf(Config.wgColor, k * 0.6f);
        float al = Config.wgAlpha * (layer == 0 ? 0.65f : 1.0f);
        float lr = (layer == 0 ? 0.62f : 1.0f) * shade;
        int baseCol = argb(rgb, lr, al * 0.55f);
        int tipCol = argb(mix(rgb, 0xFFFFFF, 0.28f + 0.2f * k), Math.min(1.15f, lr + 0.1f), al);
        int capCol = argb(mix(rgb, 0xFFFFFF, 0.5f), Math.min(1.2f, lr + 0.2f), al * 0.55f);

        Vector3f p0 = new Vector3f(o).add(new Vector3f(dir).mul(0.05f));
        Vector3f p1 = new Vector3f(o).add(new Vector3f(dir).mul(len));
        float w0 = w * 0.55f, w1 = w;
        Vector3f tip = new Vector3f(p1).add(new Vector3f(dir).mul(w * 1.3f));

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        v(b, mat, new Vector3f(p0).sub(new Vector3f(wv).mul(w0)), baseCol);
        v(b, mat, new Vector3f(p0).add(new Vector3f(wv).mul(w0)), baseCol);
        v(b, mat, new Vector3f(p1).sub(new Vector3f(wv).mul(w1)), tipCol);
        v(b, mat, new Vector3f(p1).add(new Vector3f(wv).mul(w1)), tipCol);
        v(b, mat, tip, capCol);
        Ui.flush(b);
    }

    private static void v(BufferBuilder b, Matrix4f mat, Vector3f p, int argb) {
        b.vertex(mat, p.x, p.y, p.z).color(argb);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static int argb(int rgb, float light, float alpha) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 255) * light));
        int g = Math.min(255, Math.round(((rgb >> 8) & 255) * light));
        int b = Math.min(255, Math.round((rgb & 255) * light));
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
