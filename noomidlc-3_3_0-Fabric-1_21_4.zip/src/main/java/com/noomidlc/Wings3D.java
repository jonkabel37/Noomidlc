package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * 3D Wings: объёмные крылья за спиной игрока. Стили: Feathers, Angel, Bat, Dragon, Butterfly, Fairy.
 * Всё строится из настоящих 3D-полигонов в мире: есть глубина, освещение по нормали и взмах.
 */
public final class Wings3D {
    private Wings3D() {}

    /** Система координат крыла: o - плечо, out - наружу, up - вверх, back - назад; поворот взмаха вокруг оси back. */
    private static final class Frame {
        final Vector3f o, out, up, back;
        final float cosF, sinF;

        Frame(Vector3f o, Vector3f out, Vector3f up, Vector3f back, float flapRad) {
            this.o = o;
            this.out = out;
            this.up = up;
            this.back = back;
            this.cosF = (float) Math.cos(flapRad);
            this.sinF = (float) Math.sin(flapRad);
        }

        Vector3f pt(float u, float v, float w) {
            float uu = u * cosF - v * sinF;
            float vv = u * sinF + v * cosF;
            return new Vector3f(o).add(new Vector3f(out).mul(uu)).add(new Vector3f(up).mul(vv)).add(new Vector3f(back).mul(w));
        }
    }

    public static void render(WorldRenderContext ctx) {
        if (!Config.wings3d) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Matrix4f mat = WorldFx.fixMatrix(ctx, null);
        float td = ctx.tickCounter().getTickDelta(true);
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        double time = (System.currentTimeMillis() % 1_000_000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) {
                if (firstPerson) continue;
            } else if (!Config.wgOthers) {
                continue;
            }
            if (p.isInvisible() || !p.isAlive() || p.isSpectator()) continue;
            drawPlayer(mat, p, td, time);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void drawPlayer(Matrix4f mat, PlayerEntity p, float td, double time) {
        Vec3d pos = p.getLerpedPos(td);
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
        float fx = (float) -Math.sin(yaw), fz = (float) Math.cos(yaw);   // вперёд
        Vector3f back = new Vector3f(-fx, 0.0f, -fz);
        Vector3f right = new Vector3f((float) -Math.cos(yaw), 0.0f, (float) -Math.sin(yaw));
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);

        int style = Math.floorMod(Config.wgStyle, Config.WING_STYLES.length);
        float sz = Config.wgSize;
        boolean air = !p.isOnGround() && !p.isTouchingWater();
        double speedMul = switch (style) {
            case 5 -> 2.4;
            case 4 -> 1.3;
            case 2, 3 -> 0.9;
            default -> 1.0;
        };
        double speed = Config.wgSpeed * speedMul * (air ? 2.4 : 1.0);
        float flap = (float) Math.sin(time * 3.2 * speed);
        float spread = air ? 1.0f : 0.0f;
        float sneak = p.isSneaking() ? -0.2f : 0.0f;

        Vector3f base = new Vector3f((float) pos.x, (float) pos.y + p.getHeight() * 0.72f + sneak, (float) pos.z);
        base.add(new Vector3f(back).mul(0.16f));

        for (int side = -1; side <= 1; side += 2) {
            Vector3f o = new Vector3f(base).add(new Vector3f(right).mul(side * 0.10f));
            Vector3f out = new Vector3f(right).mul(side);
            switch (style) {
                case 2, 3 -> membraneWing(mat, new Frame(o, out, up, back, flap * (0.30f + 0.12f * spread) - 0.15f), style == 3, sz);
                case 4 -> butterflyWing(mat, new Frame(o, out, up, back, flap * 0.45f - 0.1f), sz);
                case 5 -> fairyWing(mat, new Frame(o, out, up, back, flap * 0.35f), sz);
                default -> featherWing(mat, o, out, up, back, flap, spread, style == 1, sz);
            }
        }
    }

    // ------------------------------------------------------------ перья (Feathers / Angel)

    private static void featherWing(Matrix4f mat, Vector3f o, Vector3f out, Vector3f up, Vector3f back,
                                    float flap, float spread, boolean angel, float szIn) {
        float sz = szIn * (angel ? 1.3f : 1.0f);
        int n = Math.max(3, Math.min(10, Math.round(Config.wgFeathers)));
        if (angel) n = Math.max(n, 8);
        for (int layer = 0; layer < 2; layer++) {
            for (int i = 0; i < n; i++) {
                float k = n == 1 ? 0.0f : (float) i / (n - 1);
                float angle = -28.0f + k * 100.0f
                        + flap * (16.0f + 10.0f * spread) * (1.0f - k * 0.35f)
                        + (layer == 0 ? 4.0f : 0.0f);
                double ar = Math.toRadians(angle);
                Vector3f dir = new Vector3f(out).mul((float) Math.cos(ar))
                        .add(new Vector3f(up).mul((float) Math.sin(ar)))
                        .add(new Vector3f(back).mul(0.40f - 0.25f * spread + k * 0.1f));
                dir.normalize();
                float len = (layer == 0 ? 0.80f : 0.92f) * sz * (1.0f - 0.09f * Math.abs(k - 0.7f) * 4.0f);
                float w = (layer == 0 ? 0.075f : 0.085f) * sz;
                float lift = layer == 0 ? -0.02f * sz : 0.0f;
                Vector3f origin = new Vector3f(o).add(0.0f, lift, 0.0f).add(new Vector3f(back).mul(layer == 0 ? 0.015f : 0.0f));
                feather(mat, origin, dir, back, len, w, k, layer, angel);
            }
        }
    }

    private static void feather(Matrix4f mat, Vector3f o, Vector3f dir, Vector3f back, float len, float w, float k, int layer, boolean angel) {
        Vector3f wv = new Vector3f(back).sub(new Vector3f(dir).mul(back.dot(dir)));
        if (wv.lengthSquared() < 1.0e-6f) return;
        wv.normalize();
        Vector3f n = new Vector3f(dir).cross(wv).normalize();
        Vector3f light = new Vector3f(0.35f, 0.85f, 0.4f).normalize();
        float shade = 0.55f + 0.45f * Math.abs(n.dot(light));

        int rgb = angel ? mix(0xF2F6FF, WorldFx.rgbOf(Config.wgColor, k * 0.6f), 0.12f) : WorldFx.rgbOf(Config.wgColor, k * 0.6f);
        float al = Config.wgAlpha * (layer == 0 ? 0.65f : 1.0f);
        float lr = (layer == 0 ? 0.62f : 1.0f) * shade;
        int baseCol = argb(rgb, lr, al * 0.55f);
        int tipCol = argb(mix(rgb, 0xFFFFFF, 0.28f + 0.2f * k), Math.min(1.15f, lr + 0.1f), al);
        int capCol = argb(mix(rgb, 0xFFFFFF, 0.5f), Math.min(1.2f, lr + 0.2f), al * 0.55f);

        Vector3f p0 = new Vector3f(o).add(new Vector3f(dir).mul(0.05f));
        Vector3f p1 = new Vector3f(o).add(new Vector3f(dir).mul(len));
        float w0 = w * 0.55f, w1 = w;
        Vector3f tip = new Vector3f(p1).add(new Vector3f(dir).mul(w * 1.3f));

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        v(b, mat, new Vector3f(p0).sub(new Vector3f(wv).mul(w0)), baseCol);
        v(b, mat, new Vector3f(p0).add(new Vector3f(wv).mul(w0)), baseCol);
        v(b, mat, new Vector3f(p1).sub(new Vector3f(wv).mul(w1)), tipCol);
        v(b, mat, new Vector3f(p1).add(new Vector3f(wv).mul(w1)), tipCol);
        v(b, mat, tip, capCol);
        Ui.flush(b);
    }

    // ------------------------------------------------------------ перепончатые (Bat / Dragon)

    private static final float[][] BAT = {
            {0.00f, 0.05f}, {0.42f, 0.38f}, {0.98f, 0.62f}, {0.86f, 0.18f}, {0.98f, -0.12f},
            {0.66f, -0.18f}, {0.62f, -0.46f}, {0.30f, -0.30f}, {0.05f, -0.38f}};

    private static void membraneWing(Matrix4f mat, Frame f, boolean dragon, float szIn) {
        float sz = szIn * (dragon ? 1.25f : 1.0f);
        int rgb = WorldFx.rgbOf(Config.wgColor, 0.0f);
        float al = Config.wgAlpha;
        Vector3f center = f.pt(0.12f * sz, 0.0f, 0.0f);

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        v(b, mat, center, argb(rgb, 0.55f, al * 0.85f));
        for (int i = 0; i <= BAT.length; i++) {
            float[] q = BAT[i % BAT.length];
            Vector3f p = f.pt(q[0] * sz, q[1] * sz, q[0] * sz * 0.16f);
            float edge = Math.min(1.0f, q[0] * 1.1f);
            v(b, mat, p, argb(mix(rgb, 0xFFFFFF, 0.12f * edge), 0.75f + 0.25f * edge, al * (0.55f + 0.2f * edge)));
        }
        Ui.flush(b);

        // кости: плечо-запястье и пальцы
        int boneCol = argb(mix(rgb, 0xFFFFFF, dragon ? 0.15f : 0.3f), 0.95f, al);
        float bw = 0.022f * sz;
        Vector3f shoulder = f.pt(0.0f, 0.05f * sz, 0.0f);
        Vector3f wrist = f.pt(BAT[1][0] * sz, BAT[1][1] * sz, BAT[1][0] * sz * 0.16f);
        bone(mat, shoulder, wrist, f.back, bw * 1.4f, boneCol);
        int[] fingers = {2, 3, 4, 6};
        for (int idx : fingers) {
            float[] q = BAT[idx];
            Vector3f tip = f.pt(q[0] * sz, q[1] * sz, q[0] * sz * 0.16f);
            bone(mat, wrist, tip, f.back, bw, boneCol);
            if (dragon) {   // шипы на концах пальцев
                Vector3f dir = new Vector3f(tip).sub(wrist).normalize();
                bone(mat, tip, new Vector3f(tip).add(dir.mul(0.13f * sz)), f.back, 0.02f * sz, argb(0xFFEBC8, 1.0f, al));
            }
        }
        if (dragon) {   // коготь на запястье
            bone(mat, wrist, new Vector3f(wrist).add(new Vector3f(f.up).mul(0.1f * sz)), f.back, 0.026f * sz, argb(0xFFEBC8, 1.0f, al));
        }
    }

    // ------------------------------------------------------------ бабочка

    private static void butterflyWing(Matrix4f mat, Frame f, float sz) {
        float al = Config.wgAlpha;
        int rgbA = WorldFx.rgbOf(Config.wgColor, 0.05f);
        int rgbB = WorldFx.rgbOf(Config.wgColor, 0.45f);
        ellipse(mat, f, 0.50f * sz, 0.38f * sz, 0.50f * sz, 0.36f * sz, 0.45f, 0.0f, rgbA, al, 18);
        ellipse(mat, f, 0.34f * sz, -0.30f * sz, 0.34f * sz, 0.28f * sz, -0.35f, 0.03f * sz, rgbB, al, 16);
        // светлые пятна
        ellipse(mat, f, 0.62f * sz, 0.44f * sz, 0.12f * sz, 0.12f * sz, 0.0f, 0.012f * sz, 0xFFFFFF, al * 0.7f, 10);
        ellipse(mat, f, 0.36f * sz, -0.34f * sz, 0.09f * sz, 0.09f * sz, 0.0f, 0.045f * sz, 0xFFFFFF, al * 0.7f, 10);
        bone(mat, f.pt(0.0f, 0.0f, 0.0f), f.pt(0.9f * sz, 0.62f * sz, 0.012f * sz), f.back, 0.014f * sz, argb(0x303040, 1.0f, al));
    }

    // ------------------------------------------------------------ фея

    private static void fairyWing(Matrix4f mat, Frame f, float sz) {
        float al = Config.wgAlpha * 0.7f;
        int rgb = mix(WorldFx.rgbOf(Config.wgColor, 0.2f), 0xDDF6FF, 0.5f);
        ellipse(mat, f, 0.52f * sz, 0.30f * sz, 0.54f * sz, 0.15f * sz, 0.55f, 0.0f, rgb, al, 18);
        ellipse(mat, f, 0.36f * sz, -0.12f * sz, 0.38f * sz, 0.11f * sz, -0.40f, 0.02f * sz, rgb, al * 0.85f, 16);
        int vein = argb(0xFFFFFF, 1.0f, Config.wgAlpha * 0.6f);
        bone(mat, f.pt(0.0f, 0.0f, 0.0f), f.pt(0.9f * sz, 0.60f * sz, 0.0f), f.back, 0.008f * sz, vein);
        bone(mat, f.pt(0.0f, 0.0f, 0.0f), f.pt(0.65f * sz, -0.28f * sz, 0.02f * sz), f.back, 0.008f * sz, vein);
    }

    // ------------------------------------------------------------ примитивы

    /** Эллипс в плоскости крыла: центр светлее, к краю насыщеннее. */
    private static void ellipse(Matrix4f mat, Frame f, float cu, float cv, float ru, float rv, float rot, float w,
                                int rgb, float alpha, int seg) {
        float cr = (float) Math.cos(rot), sr = (float) Math.sin(rot);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        v(b, mat, f.pt(cu, cv, w), argb(mix(rgb, 0xFFFFFF, 0.45f), 1.0f, alpha * 0.9f));
        for (int i = 0; i <= seg; i++) {
            double a = i * (Math.PI * 2.0 / seg);
            float ex = (float) Math.cos(a) * ru, ey = (float) Math.sin(a) * rv;
            float u = cu + ex * cr - ey * sr;
            float vv = cv + ex * sr + ey * cr;
            v(b, mat, f.pt(u, vv, w + u * 0.05f), argb(rgb, 0.85f, alpha * 0.8f));
        }
        Ui.flush(b);
    }

    /** Тонкая палочка между двумя точками (ширина вдоль back). */
    private static void bone(Matrix4f mat, Vector3f a, Vector3f b2, Vector3f back, float w, int argb) {
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        Vector3f s = new Vector3f(back).mul(w);
        v(b, mat, new Vector3f(a).sub(s), argb);
        v(b, mat, new Vector3f(a).add(s), argb);
        v(b, mat, new Vector3f(b2).sub(s), argb);
        v(b, mat, new Vector3f(b2).add(s), argb);
        Ui.flush(b);
    }

    private static void v(BufferBuilder b, Matrix4f mat, Vector3f p, int argb) {
        b.vertex(mat, p.x, p.y, p.z).color(argb);
    }

    static int mix(int a, int b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    static int argb(int rgb, float light, float alpha) {
        int r = Math.min(255, Math.round(((rgb >> 16) & 255) * light));
        int g = Math.min(255, Math.round(((rgb >> 8) & 255) * light));
        int b = Math.min(255, Math.round((rgb & 255) * light));
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
