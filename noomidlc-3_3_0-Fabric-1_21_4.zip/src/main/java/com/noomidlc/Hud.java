package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Раньше тут жил старый HUD. Теперь рисует только ModernHud, остались общие помощники по эффектам и цвету. */
public final class Hud {
    private Hud() {}

    private static final String[] ROMAN = {"", "", " II", " III", " IV", " V", " VI", " VII", " VIII", " IX", " X"};

    public static void render(DrawContext c, RenderTickCounter tickCounter) {
        Anim.frame();
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        ModernHud.render(c, mc);
    }

    public static String effName(StatusEffectInstance in) {
        String n = in.getEffectType().value().getName().getString();
        int a = in.getAmplifier();
        if (a >= 1) n += a < ROMAN.length ? ROMAN[a] : " " + (a + 1);
        return n;
    }

    public static String effTime(StatusEffectInstance in) {
        if (in.isInfinite()) return "inf";
        int s = Math.max(0, in.getDuration() / 20);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    public static int effColor(StatusEffectInstance in) {
        return 0xFF000000 | in.getEffectType().value().getColor();
    }

    public static boolean effLow(StatusEffectInstance in) {
        return !in.isInfinite() && in.getDuration() < 200;
    }

    public static int accent2() {
        if (Config.isFlow()) return Config.flow(0.22f);
        int a = Config.accent();
        float r = ((a >> 16) & 255) / 255.0f, g = ((a >> 8) & 255) / 255.0f, b = (a & 255) / 255.0f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h;
        if (d == 0.0f) h = 0.0f;
        else if (max == r) h = ((g - b) / d) % 6.0f;
        else if (max == g) h = (b - r) / d + 2.0f;
        else h = (r - g) / d + 4.0f;
        h /= 6.0f;
        if (h < 0.0f) h += 1.0f;
        float s = max == 0.0f ? 0.0f : d / max;
        return 0xFF000000 | MathHelper.hsvToRgb((h + 0.14f) % 1.0f, s, max);
    }
}
