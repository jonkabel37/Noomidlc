package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Bunny Hop: автоматически прыгает при беге, по желанию слегка ускоряет в воздухе. */
public final class BunnyHop {
    private BunnyHop() {}

    private static boolean held = false;

    private static boolean moving(MinecraftClient mc) {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean usable = Config.bunnyHop && p != null && mc.world != null && mc.currentScreen == null
                && !p.isSneaking() && !p.isTouchingWater() && !p.isInLava() && !p.hasVehicle()
                && !p.getAbilities().flying && !p.isClimbing() && moving(mc);

        boolean jump = usable && p.isOnGround() && (!Config.bhSprintOnly || p.isSprinting());
        if (jump) {
            mc.options.jumpKey.setPressed(true);
            held = true;
        } else if (held) {
            mc.options.jumpKey.setPressed(false);
            held = false;
        }

        // небольшое ускорение в воздухе (по умолчанию выключено), с потолком скорости
        if (usable && !p.isOnGround() && Config.bhBoost > 0.0f) {
            Vec3d v = p.getVelocity();
            double k = 1.0 + Config.bhBoost * 0.01;
            double nx = v.x * k, nz = v.z * k;
            double sp = Math.hypot(nx, nz);
            double cap = 0.62;
            if (sp > cap) {
                nx *= cap / sp;
                nz *= cap / sp;
            }
            p.setVelocity(nx, v.y, nz);
        }
    }
}
