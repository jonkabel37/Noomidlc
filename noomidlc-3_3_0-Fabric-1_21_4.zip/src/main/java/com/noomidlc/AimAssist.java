package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.Random;

/**
 * Aim Assist: мягко доводит прицел до ближайшей цели в заданном конусе (FOV).
 * В отличие от Kill Aura ничего не бьёт сам и не крутит камеру рывком - только подтягивает прицел.
 */
public final class AimAssist {
    private AimAssist() {}

    public static final String[] AIMS = {"Head", "Chest", "Closest"};
    private static final Random R = new Random();
    private static LivingEntity target = null;

    public static LivingEntity target() {
        return target;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.aimAssist || p == null || mc.world == null || mc.currentScreen != null
                || p.isSpectator() || !p.isAlive()) {
            target = null;
            return;
        }
        if (Config.aaClickOnly && !mc.options.attackKey.isPressed()) {
            target = null;
            return;
        }
        if (Config.aaWeaponOnly && !isWeapon(p)) {
            target = null;
            return;
        }

        Vec3d eye = p.getEyePos();
        double range = Config.aaRange;
        target = mc.world.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range + 1.0), e -> valid(p, e))
                .stream()
                .filter(e -> p.distanceTo(e) <= range)
                .filter(e -> p.canSee(e))
                .filter(e -> angle(p, aimPoint(p, e)) <= Config.aaFov / 2.0f)
                .min(Comparator.comparingDouble(e -> angle(p, aimPoint(p, e))))
                .orElse(null);
        if (target == null) return;

        Vec3d to = aimPoint(p, target);
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 57.29577951308232);

        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();

        // чем ближе прицел к цели, тем слабее притяжение; небольшой шум, чтобы не было "роботного" движения
        float strength = MathHelper.clamp(Config.aaSpeed / 100.0f, 0.02f, 1.0f);
        float maxStep = Math.max(0.5f, Config.aaSpeed * 0.25f);
        float noise = Config.aaRandom ? (R.nextFloat() - 0.5f) * 0.4f : 0.0f;

        float sy = MathHelper.clamp(dyaw * strength + noise, -maxStep, maxStep);
        float sp = Config.aaVertical ? MathHelper.clamp(dpitch * strength + noise, -maxStep, maxStep) : 0.0f;
        p.setYaw(p.getYaw() + sy);
        p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90.0f, 90.0f));
    }

    private static boolean isWeapon(ClientPlayerEntity p) {
        String id = p.getMainHandStack().getItem().toString();
        return id.contains("sword") || id.contains("axe") || id.contains("mace") || id.contains("trident");
    }

    private static boolean valid(ClientPlayerEntity p, LivingEntity e) {
        if (e == p || !e.isAlive() || e.isSpectator() || e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return true;
        return Config.aaMobs;
    }

    private static Vec3d aimPoint(ClientPlayerEntity p, LivingEntity e) {
        double f = switch (Config.aaPart) {
            case 0 -> 0.92;
            case 1 -> 0.65;
            default -> 0.0;
        };
        if (Config.aaPart == 2) {
            // ближайшая к прицелу точка по высоте тела
            Vec3d eye = p.getEyePos();
            double y = MathHelper.clamp(eye.y, e.getY() + 0.1, e.getY() + e.getHeight() * 0.95);
            return new Vec3d(e.getX(), y, e.getZ());
        }
        return new Vec3d(e.getX(), e.getY() + e.getHeight() * f, e.getZ());
    }

    private static float angle(ClientPlayerEntity p, Vec3d to) {
        Vec3d eye = p.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 57.29577951308232);
        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();
        return (float) Math.sqrt(dyaw * dyaw + dpitch * dpitch);
    }

    /** Круг FOV вокруг прицела (чисто визуально). */
    public static void drawCircle(DrawContext c, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.aimAssist || !Config.aaCircle || mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        double fov = Math.toRadians(mc.options.getFov().getValue());
        double half = Math.toRadians(Config.aaFov / 2.0f);
        float sh = mc.getWindow().getScaledHeight();
        float r = (float) (Math.tan(Math.min(half, 1.4)) / Math.tan(fov / 2.0) * sh / 2.0);
        r = Math.min(r, sh / 2.0f - 2.0f);
        float cx = mc.getWindow().getScaledWidth() / 2.0f, cy = sh / 2.0f;
        int col = Ui.alpha(Config.accent() & 0xFFFFFF, target != null ? 0.9f : 0.4f);
        int n = Math.max(48, (int) (r * 1.5f));
        float px = 1.0f / Ui.scale();
        for (int i = 0; i < n; i++) {
            double a = i / (double) n * Math.PI * 2.0;
            float x = cx + (float) Math.cos(a) * r, y = cy + (float) Math.sin(a) * r;
            Ui.rect(c, x - px, y - px, x + px, y + px, col);
        }
    }
}
