package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;

import java.util.Map;
import java.util.WeakHashMap;

/** Гладкие кнопки с подсветкой, бликом и искрами для ванильных экранов (миры, серверы, настройки). */
public final class ButtonFx {
    private ButtonFx() {}

    private static final Map<ClickableWidget, float[]> STATE = new WeakHashMap<>();
    private static long lastNs = System.nanoTime();
    private static long frameNs = 0L;

    public static void draw(DrawContext c, ClickableWidget w, int mx, int my) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        if (now != frameNs) {   // dt считаем один раз на кадр, а не на каждую кнопку
            frameNs = now;
        }
        float dt = Math.min(0.05f, (now - lastNs) / 1.0e9f);
        lastNs = now;
        float[] st = STATE.computeIfAbsent(w, k -> new float[]{0.0f, (float) Math.random() * 6.28f});
        boolean hov = w.isHovered() && w.active;
        st[0] += ((hov ? 1.0f : 0.0f) - st[0]) * Math.min(1.0f, 14.0f * 0.016f);
        float h = st[0];

        int x = w.getX(), y = w.getY(), bw = w.getWidth(), bh = w.getHeight();
        int acc = Config.accent() | 0xFF000000;
        float t = (System.currentTimeMillis() % 100000L) / 1000.0f;
        float r = Math.min(8.0f, bh / 2.0f);

        if (w.active) {
            for (int k = 4; k >= 1; k--) {
                Ui.rrectF(c, x - k * 1.5f, y - k * 1.5f, bw + k * 3.0f, bh + k * 3.0f, r + k * 1.5f,
                        Ui.alpha(acc, (0.01f + 0.05f * h) * (5 - k) / 4.0f));
            }
        }
        Ui.rrectF(c, x - 1, y - 1, bw + 2, bh + 2, r + 1, w.active ? Ui.alpha(acc, 0.35f + 0.55f * h) : Ui.alpha(0xFF808090, 0.25f));
        Ui.rrectF(c, x, y, bw, bh, r, Ui.mix(w.active ? 0xFF14141F : 0xFF101018, 0xFF2A2A48, h));
        Ui.rrectF(c, x + 1, y + 1, bw - 2, bh / 2.0f, r, Ui.alpha(0xFFFFFFFF, 0.04f + 0.05f * h));

        // бегущий блик при наведении
        if (h > 0.02f) {
            float sx = x - 30 + ((t * 0.9f + st[1]) % 1.0f) * (bw + 60);
            c.enableScissor(x, y, x + bw, y + bh);
            Ui.rrectF(c, sx, y, 24, bh, 10, Ui.alpha(0xFFFFFFFF, 0.08f * h));
            c.disableScissor();
        }
        // искры над кнопкой (только на экранах вне мира, где рисуется фон меню)
        if (hov && mc.world == null && Math.random() < dt * 18.0f) {
            MenuFx.spark(x + (float) Math.random() * bw, y + (float) Math.random() * bh);
        }

        String label = w.getMessage().getString();
        int tw = Ui.width(mc.textRenderer, label);
        int col = w.active ? Ui.mix(0xFFD8D8E4, 0xFFFFFFFF, h) : 0xFF8A8A98;
        Ui.textMid(c, mc.textRenderer, label, x + (bw - tw) / 2, y, bh, col);
    }
}
