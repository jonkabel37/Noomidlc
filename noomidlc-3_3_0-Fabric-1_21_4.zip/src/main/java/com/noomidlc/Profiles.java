package com.noomidlc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Профили настроек: сохраняют и загружают копию конфига в пять слотов. */
public final class Profiles {
    private Profiles() {}

    private static Path slotFile(int slot) {
        return Config.file().resolveSibling("noomidlc-profile-" + (slot + 1) + ".properties");
    }

    public static void save(int slot) {
        Config.save();
        try {
            Files.copy(Config.file(), slotFile(slot), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            // профиль не записался - текущий конфиг остаётся как есть
        }
    }

    public static void load(int slot) {
        Path f = slotFile(slot);
        if (!Files.exists(f)) return;
        try {
            Files.copy(f, Config.file(), StandardCopyOption.REPLACE_EXISTING);
            Config.load();
        } catch (IOException ignored) {
            // профиль не прочитался - ничего не меняем
        }
    }
}
