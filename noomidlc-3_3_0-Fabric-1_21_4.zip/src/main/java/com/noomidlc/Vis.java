package com.noomidlc;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Optional;

/** Проверки прицела, которым не мешает паутина: у неё нет коллизии, но ванильный прицел её "видит" как блок. */
public final class Vis {
    private Vis() {}

    /** true, если прицел сейчас упёрся в паутину (значит, за ней может стоять цель). */
    public static boolean aimingAtWeb(MinecraftClient mc) {
        return mc.world != null && mc.crosshairTarget instanceof BlockHitResult b
                && b.getType() == HitResult.Type.BLOCK
                && mc.world.getBlockState(b.getBlockPos()).isOf(Blocks.COBWEB);
    }

    /** Ближайшая живая сущность на линии взгляда в радиусе удара, твёрдые блоки между ними не пропускаем, паутину - да. */
    public static Entity entityThroughWebs(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.world == null) return null;
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        double reach = p.getEntityInteractionRange();
        Vec3d end = eye.add(look.multiply(reach));
        Entity best = null;
        Vec3d bestHit = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().stretch(look.multiply(reach)).expand(1.0),
                x -> x instanceof LivingEntity && x.isAlive() && !x.isSpectator() && x.isAttackable())) {
            Box b = e.getBoundingBox().expand(e.getTargetingMargin());
            Optional<Vec3d> hit = b.raycast(eye, end);
            if (hit.isEmpty()) continue;
            double d = eye.squaredDistanceTo(hit.get());
            if (d < bestD) {
                bestD = d;
                best = e;
                bestHit = hit.get();
            }
        }
        if (best == null) return null;
        // между нами и целью не должно быть настоящих препятствий (у паутины коллизии нет, она пропускается)
        BlockHitResult wall = mc.world.raycast(new RaycastContext(eye, bestHit, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p));
        return wall.getType() == HitResult.Type.MISS ? best : null;
    }

    /** Цель под прицелом: обычный прицел, а если он упёрся в паутину - поиск сквозь неё. */
    public static Entity aimedEntity(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult ehr) return ehr.getEntity();
        if (Config.webHit && aimingAtWeb(mc)) return entityThroughWebs(mc, p);
        return null;
    }
}
