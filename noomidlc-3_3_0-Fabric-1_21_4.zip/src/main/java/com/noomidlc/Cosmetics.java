package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Cosmetics: нимб над головой, рожки и хвост. Всё объёмное, в мире, видно в третьем лице. */
public final class Cosmetics {
    private Cosmetics() {}

    public static void render(WorldRenderContext ctx) {
        if (!Config.cosmetics) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Matrix4f mat = WorldFx.fixMatrix(ctx, null);
        float td = ctx.tickCounter().getTickDelta(true);
        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        double time = (System.currentTimeMillis() % 1_000_000L) / 1000.0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) {
                if (firstPerson) continue;
            } else if (!Config.cosOthers) {
                continue;
            }
            if (p.isInvisible() || !p.isAlive() || p.isSpectator()) continue;
            Vec3d pos = p.getLerpedPos(td);
            if (Config.cosHalo) halo(mat, p, pos, time);
            if (Config.cosHorns) horns(mat, p, pos, td);
            if (Config.cosTail) tail(mat, p, pos, td, time);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------------------ нимб

    private static void halo(Matrix4f mat, PlayerEntity p, Vec3d pos, double time) {
        float cy = (float) pos.y + p.getHeight() + 0.24f + (float) Math.sin(time * 2.0) * 0.03f - (p.isSneaking() ? 0.2f : 0.0f);
        float r = 0.27f;
        ring(mat, (float) pos.x, cy, (float) pos.z, r, 0.055f, 0.10f, time);
        ring(mat, (float) pos.x, cy, (float) pos.z, r, 0.032f, 0.28f, time);
        ring(mat, (float) pos.x, cy, (float) pos.z, r, 0.016f, 0.95f, time);
    }

    private static void ring(Matrix4f mat, float cx, float cy, float cz, float r, float w, float alpha, double time) {
        int seg = 36;
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= seg; i++) {
            double a = i * (Math.PI * 2.0 / seg) + time * 0.6;
            float hue = (float) (((i / (double) seg) + time * 0.08) % 1.0);
            int rgb = WorldFx.rgbOf(Config.cosColor, hue);
            int col = Wings3D.argb(Wings3D.mix(rgb, 0xFFFFFF, 0.25f), 1.0f, alpha);
            float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
            b.vertex(mat, cx + cs * (r - w), cy, cz + sn * (r - w)).color(col);
            b.vertex(mat, cx + cs * (r + w), cy, cz + sn * (r + w)).color(col);
        }
        Ui.flush(b);
    }

    // ------------------------------------------------------------ рожки

    private static void horns(Matrix4f mat, PlayerEntity p, Vec3d pos, float td) {
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevHeadYaw, p.headYaw));
        Vector3f fwd = new Vector3f((float) -Math.sin(yaw), 0.0f, (float) Math.cos(yaw));
        Vector3f right = new Vector3f((float) -Math.cos(yaw), 0.0f, (float) -Math.sin(yaw));
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
        float topY = (float) pos.y + p.getHeight() - (p.isSneaking() ? 0.2f : 0.0f) - 0.02f;
        int rgb = WorldFx.rgbOf(Config.cosColor, 0.0f);

        for (int s = -1; s <= 1; s += 2) {
            Vector3f p0 = new Vector3f((float) pos.x, topY, (float) pos.z).add(new Vector3f(right).mul(s * 0.17f));
            Vector3f p1 = new Vector3f(p0).add(new Vector3f(up).mul(0.12f)).add(new Vector3f(right).mul(s * 0.02f));
            Vector3f p2 = new Vector3f(p1).add(new Vector3f(up).mul(0.09f)).add(new Vector3f(right).mul(s * 0.035f)).add(new Vector3f(fwd).mul(0.02f));
            Vector3f p3 = new Vector3f(p2).add(new Vector3f(up).mul(0.06f)).add(new Vector3f(right).mul(s * 0.03f)).add(new Vector3f(fwd).mul(0.06f));
            Vector3f[] pts = {p0, p1, p2, p3};
            float[] ws = {0.045f, 0.036f, 0.025f, 0.0f};
            ribbon(mat, pts, ws, fwd, rgb, 0.95f);
            ribbon(mat, pts, ws, right, rgb, 0.95f);
        }
    }

    // ------------------------------------------------------------ хвост

    private static void tail(Matrix4f mat, PlayerEntity p, Vec3d pos, float td, double time) {
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
        Vector3f back = new Vector3f((float) Math.sin(yaw), 0.0f, (float) -Math.cos(yaw));
        Vector3f right = new Vector3f((float) -Math.cos(yaw), 0.0f, (float) -Math.sin(yaw));
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f);
        float baseY = (float) pos.y + p.getHeight() * 0.42f - (p.isSneaking() ? 0.12f : 0.0f);
        Vector3f base = new Vector3f((float) pos.x, baseY, (float) pos.z).add(new Vector3f(back).mul(0.14f));
        float moving = (float) Math.min(1.0, p.getVelocity().horizontalLength() * 6.0);

        int n = 12;
        Vector3f[] pts = new Vector3f[n];
        float[] ws = new float[n];
        for (int i = 0; i < n; i++) {
            float t = i / (float) (n - 1);
            float sway = (float) Math.sin(time * 3.0 - i * 0.5) * (0.016f + 0.014f * moving) * i;
            pts[i] = new Vector3f(base)
                    .add(new Vector3f(back).mul(0.12f * i))
                    .add(new Vector3f(right).mul(sway))
                    .add(new Vector3f(up).mul(-0.022f * i + 0.0045f * i * i));
            ws[i] = 0.05f * (1.0f - t * 0.75f);
        }
        int rgb = WorldFx.rgbOf(Config.cosColor, 0.0f);
        ribbon(mat, pts, ws, up, rgb, 0.95f);
        ribbon(mat, pts, ws, right, rgb, 0.95f);

        // наконечник-"стрелка"
        Vector3f end = pts[n - 1];
        Vector3f dir = new Vector3f(end).sub(pts[n - 2]).normalize();
        Vector3f c = new Vector3f(end).add(new Vector3f(dir).mul(0.07f));
        int col = Wings3D.argb(Wings3D.mix(rgb, 0xFFFFFF, 0.2f), 0.9f, 0.95f);
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        b.vertex(mat, c.x, c.y, c.z).color(col);
        Vector3f a = new Vector3f(end);
        b.vertex(mat, a.x, a.y, a.z).color(col);
        Vector3f l = new Vector3f(c).add(new Vector3f(right).mul(0.06f));
        b.vertex(mat, l.x, l.y, l.z).color(col);
        Vector3f f2 = new Vector3f(end).add(new Vector3f(dir).mul(0.16f));
        b.vertex(mat, f2.x, f2.y, f2.z).color(col);
        Vector3f r2 = new Vector3f(c).sub(new Vector3f(right).mul(0.06f));
        b.vertex(mat, r2.x, r2.y, r2.z).color(col);
        b.vertex(mat, a.x, a.y, a.z).color(col);
        Ui.flush(b);
    }

    // ------------------------------------------------------------ лента вдоль точек

    private static void ribbon(Matrix4f mat, Vector3f[] pts, float[] ws, Vector3f wdir, int rgb, float alpha) {
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        Vector3f light = new Vector3f(0.35f, 0.85f, 0.4f).normalize();
        for (int i = 0; i < pts.length; i++) {
            float t = i / (float) (pts.length - 1);
            float shade = 0.65f + 0.35f * Math.abs(new Vector3f(wdir).dot(light));
            int col = Wings3D.argb(Wings3D.mix(rgb, 0xFFFFFF, 0.12f + 0.3f * t), shade, alpha);
            Vector3f s = new Vector3f(wdir).mul(ws[i]);
            Vector3f a = new Vector3f(pts[i]).sub(s);
            Vector3f c = new Vector3f(pts[i]).add(s);
            b.vertex(mat, a.x, a.y, a.z).color(col);
            b.vertex(mat, c.x, c.y, c.z).color(col);
        }
        Ui.flush(b);
    }
}
