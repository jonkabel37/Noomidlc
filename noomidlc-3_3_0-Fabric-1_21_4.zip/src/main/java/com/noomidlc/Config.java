package com.noomidlc;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Все настройки мода. Сохраняются в config/noomidlc.properties.
 * Любое новое public static поле (boolean / int / float) сохраняется и грузится автоматически.
 */
public final class Config {
    private Config() {}

    // ---------------------------------------------------------------- Visuals
    public static boolean esp = false;
    public static int espMode = 5;            // 0 = Corners, 1 = Glow (ванильная обводка), 2 = Fancy (градиент + анимация)
    public static boolean espName = true;
    public static boolean espDistance = true;
    public static boolean espGlowLayer = true;   // мягкое свечение вокруг рамки
    public static boolean espPulse = true;       // пульсация
    public static boolean espTracer = false;     // линия от центра экрана к цели
    public static float espOpacity = 0.9f;
    public static int espColor = 0;           // 0 Accent, 1 Rainbow, 2 White
    public static boolean espMobs = false;
    public static boolean espFill = true;
    public static boolean espHealth = true;

    public static boolean seeInvisibles = false;
    public static boolean siPlayersOnly = false;

    public static boolean fullbright = false;

    public static boolean nameTags = false;
    public static float ntScale = 1.0f;
    public static float ntBg = 0.69f;
    public static boolean ntDistance = true;
    public static boolean ntHealth = true;
    public static boolean ntPotions = true;   // эффекты зелий над ником

    public static boolean itemPhysics = false;
    public static float ipSpin = 1.0f;

    // ---------------------------------------------------------------- World
    public static boolean jumpCircle = false;
    public static int jcColor = 0;            // 0 Accent, 1 Rainbow, 2 White
    public static float jcRadius = 1.6f;
    public static float jcDuration = 1.0f;    // секунды
    public static boolean jcOthers = false;

    public static final String[] WING_STYLES = {"Feathers", "Angel", "Bat", "Dragon", "Butterfly", "Fairy"};
    public static int wgStyle = 0;
    public static boolean cosmetics = false;     // нимб, рожки, хвост
    public static boolean cosHalo = true;
    public static boolean cosHorns = false;
    public static boolean cosTail = false;
    public static int cosColor = 0;
    public static boolean cosOthers = false;
    public static boolean wings3d = false;       // 3D крылья за спиной
    public static int wgColor = 0;
    public static float wgSize = 1.0f;
    public static float wgSpeed = 1.0f;
    public static float wgAlpha = 0.85f;
    public static float wgFeathers = 7.0f;
    public static boolean wgOthers = false;
    public static boolean chinaHat = false;
    public static int chColor = 0;
    public static float chRadius = 0.55f;
    public static float chHeight = 0.42f;
    public static float chAlpha = 0.6f;
    public static boolean chOthers = false;

    public static boolean noParticles = false;
    public static boolean fpsBoost = false;      // FPS Boost: без частиц + лёгкие настройки графики
    public static boolean fbNoParticles = true;  // убрать все частицы
    public static boolean fbShadows = true;      // выключить тени сущностей
    public static boolean fbClouds = true;       // выключить облака
    public static boolean fbFastGfx = true;      // графика Fast
    public static boolean fbBlend = true;        // без сглаживания цвета биомов
    public static boolean fbEntDist = false;     // дальность прорисовки сущностей 50%
    public static boolean fbLiteMenu = true;     // лёгкое меню: без частиц и сияния
    public static boolean npKeepTotem = false;
    public static boolean npKeepHit = false;

    public static boolean noHurtCam = false;
    public static boolean noBob = false;

    public static boolean noFire = false;

    public static boolean zoom = false;
    public static int zoomBind = 67;          // C
    public static float zoomLevel = 4.0f;
    public static boolean zoomSmooth = true;

    public static final String[] COLOR_MODES = {"Accent", "Rainbow", "White"};

    // ---------------------------------------------------------------- Sky / Stretch / Ambient / Cinematic
    public static boolean sky = false;
    public static int skyMode = 0;            // 0 Flow, 1 Custom, 2 Aurora, 3 Sunset, 4 Vanilla (только время)
    public static final String[] SKY_MODES = {"Flow", "Custom", "Aurora", "Sunset", "Vanilla color"};
    public static float skyHue = 0.75f;
    public static float skySat = 0.55f;
    public static float skyBright = 1.0f;
    public static boolean skyFog = true;      // туман на горизонте в цвет неба
    public static boolean skyClouds = true;   // облака в тон неба
    public static int skyTime = 0;            // 0 = время сервера
    public static final String[] SKY_TIMES = {"Server", "Sunrise", "Day", "Noon", "Sunset", "Night", "Midnight", "Timelapse"};
    public static float skySpeed = 1.0f;      // скорость Timelapse

    public static boolean stretch = false;
    public static float stretchX = 1.3f;      // >1 = картинка шире, объекты толще (как растянутое разрешение)
    public static float stretchY = 1.0f;

    public static boolean ambient = false;
    public static int amMode = 0;
    public static final String[] AM_MODES = {"Fireflies", "Snow", "Embers", "Petals", "Dust"};
    public static float amCount = 220.0f;
    public static float amSize = 1.0f;
    public static int amColor = 0;            // 0 Auto, 1 Accent, 2 Rainbow
    public static final String[] AM_COLORS = {"Auto", "Accent", "Rainbow"};

    public static boolean cinematic = false;
    public static float cvVignette = 0.6f;
    public static float cvBars = 0.07f;       // доля высоты экрана
    public static int cvTint = 3;
    public static final String[] CV_TINTS = {"None", "Warm", "Cool", "Teal & Orange", "Flow"};
    public static float cvTintAmount = 0.5f;

    // ---------------------------------------------------------------- Hands
    public static boolean viewModel = false;
    public static float vmX = 0.0f;
    public static float vmY = 0.0f;
    public static float vmZ = 0.0f;
    public static float vmScale = 1.0f;
    public static float vmRotX = 0.0f;           // наклон предмета в руке (градусы)
    public static float vmRotY = 0.0f;
    public static float vmRotZ = 0.0f;
    public static boolean vmHideOffhand = false; // скрыть предмет в левой руке

    public static boolean swingAnim = false;
    public static boolean swingBounce = true;    // лёгкий "отскок" в конце взмаха
    public static float swingSpeed = 6.0f;
    public static float swingAngle = 0.0f;
    public static boolean swingMirror = false;   // зеркальный взмах (в другую сторону)
    public static float swingScale = 1.0f;       // предмет увеличивается/уменьшается на пике взмаха
    public static float swingShiftX = 0.0f;      // дополнительный сдвиг предмета на пике взмаха
    public static float swingShiftY = 0.0f;
    public static float swingShiftZ = 0.0f;
    public static boolean swingSway = false;     // лёгкое покачивание предмета в покое
    public static int swingStyle = 1;
    public static final String[] SWING_STYLES = {"Vanilla", "Sideways", "Push", "Slash", "Spin", "Stab", "Whip", "Smooth", "Chop", "Wave", "Side Slash", "Pop", "Flip", "Drop", "Orbit", "Pendulum", "Hammer"};

    // ---------------------------------------------------------------- Combat
    public static boolean hitInfo = false;
    public static float hiHold = 10.0f;       // сколько секунд держим цель после последнего удара
    public static boolean hiName = true;
    public static boolean hiBar = true;
    public static boolean hiHealed = true;
    public static boolean hiLast = true;

    // Kill Aura
    public static boolean killAura = false;
    public static float kaRange = 4.0f;          // шаг 1 м: 1, 2, 3 ...
    public static float kaCharge = 0.92f;
    public static float kaDelay = 0.0f;
    public static boolean kaMobs = false;
    public static boolean kaRotate = true;
    public static float kaRotSpeed = 14.0f;      // градусов/тик максимум -> плавный поворот
    public static float kaFov = 180.0f;
    public static boolean kaWalls = false;
    public static boolean kaSwing = true;
    public static int kaSort = 0;               // 0 Distance, 1 Health, 2 Angle
    public static final String[] KA_SORTS = {"Distance", "Health", "Angle"};
    public static boolean kaPlayers = true;      // цели: игроки
    public static boolean kaAnimals = false;     // цели: животные / жители
    public static boolean kaInvis = true;        // цели: невидимые
    public static boolean kaLockOnly = false;    // бить только выбранную цель
    public static int kaLockBind = 71;           // G: выбрать цель под прицелом / снять выбор
    public static int kaStepIdx = 2;             // шаг ползунка Range: 0 = 0.1м, 1 = 0.5м, 2 = 1м (по умолчанию 1м-2м-3м)
    public static final float[] KA_STEPS = {0.1f, 0.5f, 1.0f};
    public static final String[] KA_STEP_NAMES = {"0.1m", "0.5m", "1m"};
    public static boolean kaMark = true;         // кольцо под целью
    public static float kaSmooth = 0.3f;         // доля оставшегося угла за тик (меньше = плавнее, без тряски)

    public static boolean kaCritsOnly = true;    // бить только критами (падение после прыжка)
    public static boolean critJump = true;       // сам прыгать, чтобы поймать крит

    // Legit Aura: "человеческая" аура - реальный reach, плавный прицел, бьёт только когда прицел на цели
    public static boolean legitAura = false;
    public static float laRange = 3.0f;
    public static float laFov = 100.0f;
    public static float laSmooth = 0.22f;
    public static boolean laPlayers = true;
    public static boolean laMobs = false;
    public static boolean laCrits = true;
    public static boolean laWalls = false;

    // Extras (прикольные штуки для HUD)
    public static boolean exHitMarker = true;
    public static boolean exBorder = false;
    public static float exBorderSize = 1.0f;
    public static boolean exLowHp = true;
    public static boolean exCombo = true;
    public static boolean hudTime = true;

    // Particles (визуальные частицы)
    public static boolean fxParticles = false;
    public static int fxMode = 0;               // 0 Hit burst, 1 Orbit, 2 Trail, 3 All
    public static final String[] FX_MODES = {"Hit burst", "Orbit", "Trail", "All"};
    public static int fxColor = 1;
    public static float fxAmount = 1.0f;
    public static float fxSize = 1.0f;
    public static boolean fxOthers = false;

    // Aim Assist
    public static boolean aimAssist = false;
    public static float aaRange = 4.5f;
    public static float aaFov = 90.0f;
    public static float aaSpeed = 18.0f;        // 1..100: сила притяжения
    public static int aaPart = 0;               // 0 Head, 1 Chest, 2 Closest
    public static boolean aaClickOnly = true;   // работает только при зажатой ЛКМ
    public static boolean aaWeaponOnly = false;
    public static boolean aaVertical = true;
    public static boolean aaMobs = false;
    public static boolean aaRandom = true;
    public static boolean aaCircle = true;      // круг FOV на экране

    // Projectile Aim (лук / арбалет / трезубец / бросаемые)
    public static boolean projAim = false;
    public static float paRange = 50.0f;
    public static float paFov = 70.0f;
    public static float paSmooth = 0.35f;
    public static boolean paPredict = true;     // упреждение по скорости цели
    public static boolean paGravity = true;     // компенсация падения снаряда
    public static boolean paBow = true;
    public static boolean paCrossbow = true;
    public static boolean paTrident = true;
    public static boolean paThrown = true;      // снежок / яйцо / жемчуг
    public static boolean paOnlyUse = true;     // только пока натягиваешь / держишь ПКМ
    public static boolean paMobs = false;
    public static boolean paMark = true;        // метка точки попадания

    // Kill Effect
    public static boolean killFx = false;
    public static int kfMode = 0;
    public static int kfColor = 1;
    public static float kfAmount = 1.0f;
    public static float kfSize = 1.0f;
    public static boolean kfMine = true;        // только мои убийства
    public static boolean kfMobs = false;

    public static boolean triggerBot = false;
    public static float tbCharge = 0.9f;      // минимальная зарядка удара (1.0 = полная)
    public static float tbDelay = 0.0f;       // доп. задержка в тиках перед ударом
    public static boolean tbPlayersOnly = true;
    public static int tbCritMode = 0;         // 0 = любые удары, 1 = только криты, 2 = только без критов

    public static boolean autoTotem = false;
    public static float atDelay = 2.0f;       // тиков между попытками
    public static float atHealth = 0.0f;      // 0 = всегда держать тотем в левой руке
    public static boolean atEmptyOnly = false;

    public static boolean clickPearl = false;
    public static int cpBind = -102;          // -100 - кнопка мыши (СКМ), >= 0 клавиша GLFW, -1 = нет
    public static boolean cpSwing = true;

    public static boolean clickWind = false;
    public static int cwBind = -1;
    public static boolean cwAimDown = true;
    public static boolean cwSwing = true;

    // ---------------------------------------------------------------- Misc
    public static boolean customMenu = true;     // своё главное меню (кнопки, питомец, крылья)
    public static boolean menuPet = true;
    public static boolean menuWings = true;
    public static int petColor = 0;
    public static int petStyle = 0;              // аксессуар питомца
    public static int petXp = 0;                 // опыт питомца (уровень = 1 + xp / 25)
    public static int petType = 0;               // 0 кот, 1 пёс, 2 заяц, 3 лиса, 4 панда, 5 дракон
    public static float petMood = 70.0f;
    public static boolean customTitle = true;   // главный экран: noomidlc вместо Minecraft
    public static boolean fly = false;
    public static float flySpeed = 0.6f;      // горизонталь, блоков за тик
    public static float flyVert = 0.4f;       // вверх/вниз, блоков за тик

    public static boolean spider = false;
    public static float spiderSpeed = 0.35f;  // скорость подъёма по стене

    public static boolean noWeb = false;

    public static boolean airSwim = false;
    public static float asSpeed = 0.35f;      // скорость "плавания" по воздуху

    public static boolean airStuck = false;

    public static boolean invMove = false;
    public static boolean invArrows = true;      // стрелки поворачивают камеру при открытом инвентаре
    public static float invLook = 3.0f;

    // Reach: увеличенная дистанция удара (серверный античит может не принять)
    public static boolean reach = false;
    public static float reachRange = 4.5f;    // блоков (ваниль = 3.0)

    // No Fall: убирает урон от падения
    public static boolean noFall = false;
    public static float nfDistance = 2.5f;    // с какой высоты падения подстилать землю

    // Jesus: ходьба по воде
    public static boolean jesus = false;
    public static boolean jesusLava = false;  // и по лаве (в ней всё равно горишь, если провалишься)
    public static float jesusSpeed = 1.0f;    // множитель скорости на воде

    // Anti AFK: имитирует активность, чтобы не кикало за простой
    public static boolean antiAfk = false;
    public static float afkInterval = 20.0f;  // секунд между действиями
    public static boolean afkRotate = true;
    public static boolean afkJump = true;
    public static boolean afkSwing = false;

    // No Clip: пролёт сквозь блоки
    public static boolean noClip = false;
    public static float ncSpeed = 0.5f;
    public static float ncVert = 0.4f;

    public static boolean blockEsp = false;
    public static float beRange = 24.0f;
    public static float beMax = 150.0f;
    public static boolean beOres = true;
    public static boolean beRare = false;     // только редкие руды
    public static boolean beChests = true;
    public static boolean beSpawners = true;

    public static boolean blockFx = false;
    public static int bfMode = 0;             // 0 Pulse, 1 Scan, 2 Corners
    public static final String[] BF_MODES = {"Aura", "Pulse", "Scan", "Corners"};
    public static boolean bfGlow = true;
    public static boolean bfSparks = true;
    public static int bfColor = 0;
    public static float bfSpeed = 1.0f;
    public static boolean bfFill = true;
    public static boolean bfOutline = true;

    public static boolean autoSprint = false;
    public static boolean autoRespawn = false;
    public static float arDelay = 0.0f;       // тиков до респавна


    // ---------------------------------------------------------------- 3.2.0: новые модули
    public static boolean freecam = false;
    public static float fcSpeed = 1.0f;

    public static boolean fovChanger = false;
    public static float fovValue = 100.0f;

    public static boolean autoTool = false;
    public static boolean atRestore = true;       // вернуть прежний слот после копания

    public static boolean autoEat = false;
    public static float aeHunger = 14.0f;         // есть, когда голод <= этого значения (из 20)

    public static boolean autoWalk = false;

    public static boolean noWeather = false;      // убирает дождь и грозу (только у тебя на экране)

    public static boolean trails = false;
    public static int trMode = 0;
    public static float trAmount = 2.0f;

    public static boolean deathCoords = false;    // координаты смерти в чат

    public static boolean invSort = false;
    public static int sortBind = 82;              // R (в инвентаре)

    public static boolean autoReconnect = false;
    public static float reconSec = 5.0f;

    public static boolean chatTime = false;
    public static boolean chatTime24 = true;

    public static boolean notify = false;         // всплывашки при вкл/выкл модулей

    public static boolean infoPanel = false;      // панель справа внизу
    public static boolean ipSpeed = true;
    public static boolean ipBiome = true;
    public static boolean ipLight = false;
    public static boolean ipDay = false;
    public static boolean ipSession = true;
    public static boolean ipMemory = false;
    public static boolean ipServer = true;

    // ---------------------------------------------------------------- HUD
    public static boolean hud = true;
    public static float hudScale = 1.0f;     // размер всего HUD (0.6 .. 2.0)
    public static boolean hudWatermark = true;
    public static boolean hudFps = true;
    public static boolean hudPing = true;
    public static boolean hudModuleList = true;
    public static boolean mlDots = true;
    public static boolean hudInfo = true;
    public static boolean hudFacing = true;
    public static boolean hudKeys = true;
    public static boolean ksSpace = true;
    public static boolean hudArmor = false;
    public static boolean haVertical = false;
    public static boolean haDurability = true;
    public static boolean hudPotions = false;
    public static boolean hudTarget = true;   // Target HUD для выбранной цели KillAura
    public static boolean hudRadar = false;   // мини-радар ближайших игроков
    public static boolean hudCompass = false;
    public static boolean hudDimension = false;
    public static boolean lowHealthWarning = false;
    public static float lowHealthThreshold = 6.0f;

    public static boolean customCrosshair = false;
    public static int crosshairStyle = 0;      // 0 Classic, 1 Dot, 2 Cross, 3 T-shape
    public static final String[] CROSSHAIR_STYLES = {"Classic", "Dot", "Cross", "T-shape"};
    public static float crosshairSize = 5.0f;
    public static float crosshairGap = 3.0f;
    public static float crosshairThickness = 1.0f;
    public static boolean crosshairDynamic = true;
    public static boolean hpTimer = true;
    public static boolean hudCounts = false;
    public static boolean ctTotem = true;
    public static boolean ctPearl = true;
    public static boolean ctWind = true;
    public static int font = 3;   // 0 Vanilla, 1 JetBrains Mono, 2 Geist Mono, 3 Carlito (сглаженный TTF)
    public static final String[] FONT_NAMES = {"Vanilla", "JetBrains", "Geist", "Carlito"};
    public static boolean uiAnim = true;
    public static boolean guiParticles = true;   // фоновые частицы в меню

    /** Эффекты главного меню (сияние, шары, искры): выключаются настройкой или режимом FPS Boost. */
    public static boolean menuFx() {
        return guiParticles && !(fpsBoost && fbLiteMenu);
    }
    public static boolean guiBlur = true;        // затемнение/виньетка
    public static boolean guiRipple = true;      // волна при клике
    public static boolean guiGlow = true;        // свечение панелей

    public static final int HUD_ELEMS = 8;
    /** 0 watermark, 1 info, 2 module list (x = ПРАВЫЙ край, -1 = по умолчанию), 3 keystrokes, 4 hit info, 5 armor, 6 counters, 7 potions. */
    public static int[] hudX = {4, 4, -1, 4, 4, 4, 4, 4};
    public static int[] hudY = {4, 23, 4, 44, 104, 170, 146, 200};

    // ---------------------------------------------------------------- Тема
    public static int accent = 5;             // по умолчанию переливающийся Flow
    public static float flowSpeed = 1.0f;     // скорость переливания
    public static final String[] ACCENT_NAMES = {
            "Violet", "Cyan", "Red", "Green", "Amber", "Flow", "Neon Pink", "Lime", "Ice", "Gold",
            "Rainbow", "Ocean", "Sunset", "Aurora", "Toxic", "Candy", "Lava", "Galaxy", "Mint Ice", "Cherry",
            "Vaporwave", "Matrix", "Ember", "Sakura", "Electric Blue", "Blood Moon",
            "Deep Space", "Tropical", "Arctic", "Cyber Gold", "Purple Haze", "Forest",
            "Neon Mint", "Peach", "Midnight", "Rose Gold", "Fire & Ice", "Pastel", "Emerald", "Steel"};
    /** Темы: один цвет = статичная, несколько = плавно переливающаяся. */
    public static final int[][] THEMES = {
            {0xFF7C4DFF}, {0xFF00BCD4}, {0xFFFF5252}, {0xFF69F0AE}, {0xFFFFB300},
            {0xFFFF2D4D, 0xFFFFFFFF, 0xFFFF6EC7, 0xFF9B4DFF},                       // Flow
            {0xFFFF2BD6}, {0xFFB6FF00}, {0xFF7DF9FF}, {0xFFFFD700},
            {0xFFFF004D, 0xFFFF9500, 0xFFFFEE00, 0xFF00E676, 0xFF00B0FF, 0xFFB44CFF}, // Rainbow
            {0xFF00E5FF, 0xFF2979FF, 0xFF00BFA5},                                   // Ocean
            {0xFFFF8A3D, 0xFFFF3D7F, 0xFF9B4DFF},                                   // Sunset
            {0xFF00FFC6, 0xFF7C4DFF, 0xFFFF6EC7},                                   // Aurora
            {0xFFB6FF00, 0xFF00E676, 0xFF00FFC6},                                   // Toxic
            {0xFFFF8ACD, 0xFF8AD1FF, 0xFFFFF08A},                                   // Candy
            {0xFFFF1E1E, 0xFFFF7A00, 0xFFFFD000},                                   // Lava
            {0xFF3A1CFF, 0xFF9B4DFF, 0xFFFF2BD6},                                   // Galaxy
            {0xFF7DF9FF, 0xFFB6FFEA, 0xFFFFFFFF},                                   // Mint Ice
            {0xFFFF0040, 0xFF8A0030, 0xFFFF4D6D},                                   // Cherry
            {0xFFFF71CE, 0xFF01CDFE, 0xFFB967FF},                                   // Vaporwave
            {0xFF00FF41, 0xFF008F11, 0xFF9DFFB0},                                   // Matrix
            {0xFFFF5E00, 0xFFFFB300, 0xFFFF2D4D},                                   // Ember
            {0xFFFFB7D5, 0xFFFFFFFF, 0xFFFF6EAF},                                   // Sakura
            {0xFF2979FF, 0xFF00E5FF, 0xFF7C4DFF},                                   // Electric Blue
            {0xFF5C0011, 0xFFFF1744, 0xFFFF6D00},                                   // Blood Moon
            {0xFF09001F, 0xFF4527A0, 0xFF00B0FF},                                   // Deep Space
            {0xFF00C853, 0xFFFFEA00, 0xFF00B8D4},                                   // Tropical
            {0xFF80DEEA, 0xFFFFFFFF, 0xFFB3E5FC},                                   // Arctic
            {0xFFFFD740, 0xFFFF6D00, 0xFFFFAB00},                                   // Cyber Gold
            {0xFF7E57C2, 0xFFEA80FC, 0xFF536DFE},                                   // Purple Haze
            {0xFF1B5E20, 0xFF76FF03, 0xFFA5D6A7},                                  // Forest
            {0xFF00FF9C, 0xFF00B3FF, 0xFFB6FFEA},                                   // Neon Mint
            {0xFFFFB199, 0xFFFF0844, 0xFFFFD1A9},                                   // Peach
            {0xFF0F2027, 0xFF2C5364, 0xFF00C6FF},                                   // Midnight
            {0xFFE8B4A0, 0xFFFFD9C7, 0xFFC98B7A},                                   // Rose Gold
            {0xFFFF512F, 0xFFFFFFFF, 0xFF00C6FF},                                   // Fire & Ice
            {0xFFFFC8DD, 0xFFBDE0FE, 0xFFCDB4DB, 0xFFFFE5B4},                       // Pastel
            {0xFF00C97B, 0xFF009B72, 0xFF7CFFCB},                                   // Emerald
            {0xFF8FA3B8, 0xFFD6E0EA, 0xFF5B6B7C}};                                  // Steel
    public static final int FLOW = 5;         // индекс базовой переливающейся темы

    private static int[] stops() {
        return THEMES[Math.floorMod(accent, THEMES.length)];
    }

    /** true, если выбранная тема переливается (несколько цветов). */
    public static boolean isFlow() {
        return stops().length > 1;
    }

    /** Цвет переливания выбранной темы в момент времени с фазовым сдвигом (0..1). */
    public static int flow(float phase) {
        int[] st = stops();
        if (st.length < 2) st = THEMES[FLOW];
        double t = System.currentTimeMillis() / 1000.0 * 0.18 * flowSpeed + phase;
        t -= Math.floor(t);
        double pos = t * st.length;
        int i = (int) pos;
        float k = (float) (pos - i);
        k = k * k * (3.0f - 2.0f * k);   // мягкое сглаживание между цветами
        return Ui.mix(st[i % st.length], st[(i + 1) % st.length], k);
    }

    public static int accent() {
        int[] st = stops();
        if (st.length > 1) return flow(0.0f);
        return st[0];
    }

    public static String accentName() {
        return ACCENT_NAMES[Math.floorMod(accent, ACCENT_NAMES.length)];
    }

    public static void resetHud() {
        hudX = new int[]{4, 4, -1, 4, 4, 4, 4, 4};
        hudY = new int[]{4, 23, 4, 44, 104, 170, 146, 200};
    }

    public static void resetViewModel() {
        vmX = 0.0f;
        vmY = 0.0f;
        vmZ = 0.0f;
        vmScale = 1.0f;
        vmRotX = 0.0f;
        vmRotY = 0.0f;
        vmRotZ = 0.0f;
    }

    // ---------------------------------------------------------------- клавиши включения модулей

    /** id модуля -> клавиша/кнопка мыши (-1 = нет). Сохраняется как bind.<id>. */
    public static final Map<String, Integer> BINDS = new HashMap<>();

    public static int bind(String id) {
        return BINDS.getOrDefault(id, -1);
    }

    public static void setBind(String id, int code) {
        if (code == -1) BINDS.remove(id);
        else BINDS.put(id, code);
    }

    // ---------------------------------------------------------------- сохранение

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("noomidlc.properties");
    }

    private static boolean persisted(Field f) {
        int m = f.getModifiers();
        if (!Modifier.isStatic(m) || Modifier.isFinal(m)) return false;
        Class<?> t = f.getType();
        return t == boolean.class || t == int.class || t == float.class;
    }

    public static void save() {
        Properties p = new Properties();
        try {
            for (Field f : Config.class.getDeclaredFields()) {
                if (persisted(f)) p.setProperty(f.getName(), String.valueOf(f.get(null)));
            }
        } catch (IllegalAccessException ignored) {
        }
        for (int i = 0; i < HUD_ELEMS; i++) {
            p.setProperty("hudX" + i, String.valueOf(hudX[i]));
            p.setProperty("hudY" + i, String.valueOf(hudY[i]));
        }
        for (Map.Entry<String, Integer> e : BINDS.entrySet()) {
            p.setProperty("bind." + e.getKey(), String.valueOf(e.getValue()));
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "noomidlc");
        } catch (IOException ignored) {
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        // старые конфиги хранили шрифт под ключом fontId
        if (p.getProperty("font") == null && p.getProperty("fontId") != null) {
            p.setProperty("font", p.getProperty("fontId"));
        }
        for (Field fld : Config.class.getDeclaredFields()) {
            if (!persisted(fld)) continue;
            String v = p.getProperty(fld.getName());
            if (v == null) continue;
            try {
                Class<?> t = fld.getType();
                if (t == boolean.class) fld.setBoolean(null, Boolean.parseBoolean(v));
                else if (t == int.class) fld.setInt(null, (int) Float.parseFloat(v));
                else fld.setFloat(null, Float.parseFloat(v));
            } catch (Exception ignored) {
            }
        }
        for (int i = 0; i < HUD_ELEMS; i++) {
            hudX[i] = (int) num(p, "hudX" + i, hudX[i]);
            hudY[i] = (int) num(p, "hudY" + i, hudY[i]);
        }
        BINDS.clear();
        for (String key : p.stringPropertyNames()) {
            if (!key.startsWith("bind.")) continue;
            try {
                BINDS.put(key.substring(5), Integer.parseInt(p.getProperty(key).trim()));
            } catch (NumberFormatException ignored) {
            }
        }
        espMode = Math.floorMod(espMode, 6);
        invLook = Math.max(0.5f, Math.min(10.0f, invLook));
        petMood = Math.max(0.0f, Math.min(100.0f, petMood));
        fcSpeed = Math.max(0.1f, Math.min(4.0f, fcSpeed));
        fovValue = Math.max(30.0f, Math.min(160.0f, fovValue));
        trMode = Math.floorMod(trMode, NewMods.TRAIL_MODES.length);
        aeHunger = Math.max(4.0f, Math.min(19.0f, aeHunger));
        reconSec = Math.max(1.0f, Math.min(60.0f, reconSec));
        trAmount = Math.max(1.0f, Math.min(8.0f, trAmount));
        kfMode = Math.floorMod(kfMode, KillFx.MODES.length);
        kfColor = Math.floorMod(kfColor, COLOR_MODES.length);
        aaPart = Math.floorMod(aaPart, AimAssist.AIMS.length);
        fxMode = Math.floorMod(fxMode, FX_MODES.length);
        bfMode = Math.floorMod(bfMode, BF_MODES.length);
        bfColor = Math.floorMod(bfColor, COLOR_MODES.length);
        fxColor = Math.floorMod(fxColor, COLOR_MODES.length);
        kaStepIdx = Math.floorMod(kaStepIdx, KA_STEPS.length);
        kaSort = Math.floorMod(kaSort, KA_SORTS.length);
        kaRange = Math.max(1.0f, Math.min(6.0f, kaRange));
        // защита от кривых значений в конфиге (иначе hsvToRgb / матрица проекции могут уронить игру)
        skyHue = Math.max(0.0f, Math.min(1.0f, skyHue));
        skySat = Math.max(0.0f, Math.min(1.0f, skySat));
        skyBright = Math.max(0.3f, Math.min(1.2f, skyBright));
        stretchX = Math.max(0.5f, Math.min(2.5f, stretchX));
        stretchY = Math.max(0.5f, Math.min(2.5f, stretchY));
        amCount = Math.max(10.0f, Math.min(400.0f, amCount));
        amSize = Math.max(0.3f, Math.min(4.0f, amSize));
        cvBars = Math.max(0.0f, Math.min(0.3f, cvBars));
        cvVignette = Math.max(0.0f, Math.min(1.0f, cvVignette));
        laRange = Math.max(2.0f, Math.min(3.5f, laRange));
        accent = Math.floorMod(accent, THEMES.length);
        skyMode = Math.floorMod(skyMode, SKY_MODES.length);
        skyTime = Math.floorMod(skyTime, SKY_TIMES.length);
        amMode = Math.floorMod(amMode, AM_MODES.length);
        amColor = Math.floorMod(amColor, AM_COLORS.length);
        cvTint = Math.floorMod(cvTint, CV_TINTS.length);
        hudScale = Math.max(0.6f, Math.min(2.0f, hudScale));
        reachRange = Math.max(3.0f, Math.min(6.0f, reachRange));
        espColor = Math.floorMod(espColor, COLOR_MODES.length);
        swingStyle = Math.floorMod(swingStyle, SWING_STYLES.length);
        vmRotX = Math.max(-180.0f, Math.min(180.0f, vmRotX));
        vmRotY = Math.max(-180.0f, Math.min(180.0f, vmRotY));
        vmRotZ = Math.max(-180.0f, Math.min(180.0f, vmRotZ));
        swingScale = Math.max(0.5f, Math.min(1.6f, swingScale));
        swingShiftX = Math.max(-0.6f, Math.min(0.6f, swingShiftX));
        swingShiftY = Math.max(-0.6f, Math.min(0.6f, swingShiftY));
        swingShiftZ = Math.max(-0.6f, Math.min(0.6f, swingShiftZ));
        font = Math.floorMod(font, FONT_NAMES.length);
        jcColor = Math.floorMod(jcColor, COLOR_MODES.length);
        chColor = Math.floorMod(chColor, COLOR_MODES.length);
        wgColor = Math.floorMod(wgColor, COLOR_MODES.length);
        wgStyle = Math.floorMod(wgStyle, WING_STYLES.length);
        cosColor = Math.floorMod(cosColor, COLOR_MODES.length);
        wgSize = Math.max(0.5f, Math.min(2.0f, wgSize));
        wgSpeed = Math.max(0.3f, Math.min(3.0f, wgSpeed));
        wgAlpha = Math.max(0.2f, Math.min(1.0f, wgAlpha));
        wgFeathers = Math.max(3.0f, Math.min(10.0f, wgFeathers));
    }

    private static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
