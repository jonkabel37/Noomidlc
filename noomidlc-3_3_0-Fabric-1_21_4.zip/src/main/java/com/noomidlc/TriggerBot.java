package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Trigger Bot: бьёт цель под прицелом, когда удар заряжен. Режимы критов: Any / Only crits / No crits. */
public final class TriggerBot {
    private TriggerBot() {}

    public static final String[] CRIT_MODES = {"Any", "Only crits", "No crits"};

    private static int ready = 0;
    private static boolean critPrepared = false;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.triggerBot || p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || p.isUsingItem() || p.isSpectator()) {
            reset(mc);
            return;
        }
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof EntityHitResult ehr)) {
            reset(mc);
            return;
        }
        Entity e = ehr.getEntity();
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || !le.isAttackable()) {
            reset(mc);
            return;
        }
        if (Config.tbPlayersOnly && !(e instanceof PlayerEntity)) {
            reset(mc);
            return;
        }

        // Перезарядка удара
        if (p.getAttackCooldownProgress(0.5f) < Config.tbCharge) return;

        int mode = Config.tbCritMode;
        if (mode == 1) {
            // Только криты: гасим бег / прыгаем (если включено) и ждём момента падения
            Crit.prepare(mc, p);
            critPrepared = true;
            if (!Crit.ready(p)) return;
        } else if (mode == 2) {
            // Только без критов: если сейчас был бы крит - ждём, пока он пройдёт
            if (critPrepared) {
                Crit.release(mc);
                critPrepared = false;
            }
            if (Crit.ready(p)) return;
        } else if (critPrepared) {
            Crit.release(mc);
            critPrepared = false;
        }

        if (ready++ < Math.round(Config.tbDelay)) return;

        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
        ready = 0;
        if (critPrepared) {
            Crit.release(mc);
            critPrepared = false;
        }
    }

    private static void reset(MinecraftClient mc) {
        ready = 0;
        if (critPrepared) {
            Crit.release(mc);
            critPrepared = false;
        }
    }
}
