package com.noomidlc;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

public class Noomidlc implements ClientModInitializer {
    public static KeyBinding menuKey;
    private static boolean fullbrightApplied = false;
    private static boolean sprintApplied = false;

    private static final Set<String> LOGGED = new HashSet<>();

    /** Любая ошибка в модуле не роняет игру: пишем в лог один раз и идём дальше. */
    public static void safe(String name, Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            if (LOGGED.add(name)) {
                System.err.println("[noomidlc] ошибка в модуле " + name + ": " + t);
                t.printStackTrace();
            }
        }
    }

    @Override
    public void onInitializeClient() {
        safe("config", Config::load);
        safe("hitinfo.init", HitInfo::init);

        // Меню открывается на Right Shift
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.noomidlc.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.noomidlc"
        ));

        ClientTickEvents.START_CLIENT_TICK.register(client -> safe("invmove", () -> InvMove.tick(client)));
        ClientTickEvents.END_CLIENT_TICK.register(client -> safe("invmove.end", () -> InvMove.tick(client, false)));
        ClientTickEvents.START_CLIENT_TICK.register(client -> safe("freecam", () -> Freecam.tick(client)));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            safe("menu", () -> {
                while (menuKey.wasPressed()) {
                    if (client.currentScreen == null) {
                        client.setScreen(new ClickGuiScreen());
                    }
                }
            });
            safe("modules", () -> Modules.tick(client));
            safe("blockesp", () -> BlockEsp.tick(client));
            safe("zoom", () -> Zoom.tick(client));
            safe("fullbright", () -> tickFullbright(client));
            safe("sprint", () -> tickSprint(client));
            safe("hitinfo", () -> HitInfo.tick(client));
            safe("actions", () -> Actions.tick(client));
            Crit.suppress = false;
            safe("swaps", () -> Swaps.tick(client));
            safe("bunnyhop", () -> BunnyHop.tick(client));
            safe("fpsboost", () -> FpsBoost.tick(client));
            safe("triggerbot", () -> TriggerBot.tick(client));
            safe("movement", () -> Movement.tick(client));
            safe("misc", () -> Misc.tick(client));
            safe("newmods", () -> NewMods.tick(client));
            safe("menu", () -> NoomiMenuScreen.tick(client));
            safe("ambient", () -> Ambient.tick(client));
            safe("aimassist", () -> AimAssist.tick(client));
            safe("projaim", () -> ProjectileAim.tick(client));
            safe("killaura", () -> KillAura.tick(client));
            safe("legitaura", () -> LegitAura.tick(client));
            safe("killfx", () -> KillFx.tick(client));
            safe("fx", () -> Fx.tick(client));
            safe("worldfx", () -> WorldFx.tick(client));
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && entity instanceof LivingEntity) safe("hitmarker", Extras::hit);
            return ActionResult.PASS;
        });

        WorldRenderEvents.LAST.register(ctx -> safe("nametags.collect", () -> NameTags.collect(ctx)));
        WorldRenderEvents.LAST.register(ctx -> safe("esp.collect", () -> Esp.collect(ctx)));
        WorldRenderEvents.LAST.register(ctx -> safe("blockesp.collect", () -> BlockEsp.collect(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("blockfx", () -> BlockFx.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("wings3d", () -> Wings3D.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("cosmetics", () -> Cosmetics.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("worldfx", () -> WorldFx.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("fx", () -> Fx.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("ambient.render", () -> Ambient.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("killaura.mark", () -> KillAura.renderMark(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("killfx.render", () -> KillFx.render(ctx)));
        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> safe("projaim.render", () -> ProjectileAim.render(ctx)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("aimassist.circle", () -> AimAssist.drawCircle(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("esp.draw", () -> Esp.draw(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("blockesp.draw", () -> BlockEsp.draw(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("nametags.draw", () -> NameTags.draw(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("cinematic", () -> Cinematic.draw(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("extras", () -> Extras.draw(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("hud", () -> Hud.render(c, tc)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("hud.extras", () -> HudExtras.render(c)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("newmods.info", () -> NewMods.drawInfo(c)));
        HudRenderCallback.EVENT.register((c, tc) -> safe("newmods.notify", () -> NewMods.drawNotify(c)));
        ClientReceiveMessageEvents.MODIFY_GAME.register((msg, overlay) -> {
            try { return NewMods.stamp(msg, overlay); } catch (Throwable t) { return msg; }
        });
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof DisconnectedScreen) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) ->
                        safe("reconnect.draw", () -> NewMods.drawReconnect(client, ctx, s.width, s.height)));
            }
        });
        HudRenderCallback.EVENT.register((c, tc) -> safe("crosshair", () -> CrosshairOverlay.render(c)));
    }

    /** Auto Sprint: зажимает клавишу бега, пока идёшь вперёд (остальное решает ваниль: голод, шифт и т.д.). */
    private static void tickSprint(MinecraftClient client) {
        if (client.player == null) {
            sprintApplied = false;
            return;
        }
        if (Config.autoSprint && !Crit.suppress && client.options.forwardKey.isPressed()) {
            client.options.sprintKey.setPressed(true);
            sprintApplied = true;
        } else if (sprintApplied) {
            client.options.sprintKey.setPressed(false);
            sprintApplied = false;
        }
    }

    /** Fullbright через клиентский эффект ночного зрения (на сервер ничего не отправляется). */
    private static void tickFullbright(MinecraftClient client) {
        if (client.player == null) {
            fullbrightApplied = false;
            return;
        }
        if (Config.fullbright) {
            StatusEffectInstance cur = client.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                client.player.addStatusEffect(
                        new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
            }
            fullbrightApplied = true;
        } else if (fullbrightApplied) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightApplied = false;
        }
    }
}
