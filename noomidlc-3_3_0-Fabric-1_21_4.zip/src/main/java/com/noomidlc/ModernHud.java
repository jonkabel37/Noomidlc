package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import org.lwjgl.glfw.GLFW;

import java.lang.management.ManagementFactory;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * HUD в виде панелей. Панели можно перетаскивать мышью, когда открыт чат
 * (ПКМ по панели возвращает её на место). Смещения сохраняются в конфиге.
 */
public final class ModernHud {
    private ModernHud() {}

    // номера панелей (совпадают с Config.mhOff)
    private static final int TOP = 0, COORDS = 1, COOLDOWNS = 2, KEYBINDS = 3, ARMOR = 4, TARGET = 5, INVENTORY = 6, EFFECTS = 7, N = 8;
    private static final String[] NAMES = {"Top bar", "Coords", "Cooldowns", "Keybinds", "Armor", "Target", "Inventory", "Effects"};

    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.FIREWORK_ROCKET, Items.GOLDEN_APPLE,
            Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.WIND_CHARGE, Items.SHIELD};
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    // прямоугольники панелей без смещения (для перетаскивания) и признак, что панель нарисована
    private static final int[][] RECT = new int[N][4];
    private static final boolean[] SHOWN = new boolean[N];
    private static int dragId = -1;
    private static double grabX, grabY;
    private static boolean prevL = false, prevR = false;
    private static boolean preview = false;

    private static float bps = 0.0f;
    private static int cpu = 0;
    private static long cpuAt = 0L;
    private static float shownHp = 20.0f;
    private static LivingEntity lastTarget = null;
    private static long lastTargetAt = 0L;

    private static int acc;
    private static int hoverId = -1;

    public static void render(DrawContext c, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        TextRenderer tr = mc.textRenderer;
        float s = MathHelper.clamp(Config.mhScale, 0.5f, 2.0f);
        int sw = Math.round(mc.getWindow().getScaledWidth() / s);
        int sh = Math.round(mc.getWindow().getScaledHeight() / s);
        acc = 0xFF000000 | Config.accent();
        preview = mc.currentScreen instanceof ChatScreen;
        Arrays.fill(SHOWN, false);

        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        bps += (float) (Math.hypot(dx, dz) * 20.0 - bps) * 0.1f;

        MatrixStack ms = c.getMatrices();
        ms.push();
        ms.scale(s, s, 1.0f);
        int y = 4;
        if (Config.mhTop) y = topBar(c, mc, tr, p, sw) + 4;
        if (Config.mhCoords) y = coords(c, tr, p, y) + 4;
        if (Config.mhCooldowns) y = cooldowns(c, tr, p, y);
        if (Config.mhKeybinds) y = keybinds(c, tr, y);
        if (Config.mhArmor) armor(c, tr, p, y);
        if (Config.mhTarget) targetBox(c, mc, tr, p, sw, sh);
        if (Config.mhInventory) inventory(c, tr, p, sw, sh);
        if (Config.mhEffects) effects(c, tr, p, sw);

        if (preview) dragLogic(c, mc, tr, sw, sh);
        else {
            dragId = -1;
            hoverId = -1;
            prevL = false;
            prevR = false;
        }
        ms.pop();
    }

    /** Колесо мыши над панелью в чате меняет размер всего HUD. Возвращает true, если событие использовано. */
    public static boolean onScroll(double amount) {
        if (!preview || hoverId < 0 || amount == 0.0) return false;
        float v = Config.mhScale + (amount > 0.0 ? 0.05f : -0.05f);
        Config.mhScale = MathHelper.clamp(Math.round(v * 20.0f) / 20.0f, 0.5f, 2.0f);
        Config.save();
        return true;
    }

    public static void registerScroll() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof ChatScreen) {
                ScreenMouseEvents.allowMouseScroll(screen).register((s, mx, my, hx, vy) -> !onScroll(vy));
            }
        });
    }

    // ------------------------------------------------------------ перетаскивание в чате

    private static void dragLogic(DrawContext c, MinecraftClient mc, TextRenderer tr, int sw, int sh) {
        long handle = mc.getWindow().getHandle();
        double mx = mc.mouse.getX() * sw / (double) mc.getWindow().getWidth();
        double my = mc.mouse.getY() * sh / (double) mc.getWindow().getHeight();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        int hover = -1;
        for (int i = N - 1; i >= 0; i--) {
            if (!SHOWN[i]) continue;
            int rx = RECT[i][0] + Config.mhOff(i, true), ry = RECT[i][1] + Config.mhOff(i, false);
            if (mx >= rx && mx <= rx + RECT[i][2] && my >= ry && my <= ry + RECT[i][3]) {
                hover = i;
                break;
            }
        }

        if (l && !prevL && hover >= 0) {
            dragId = hover;
            grabX = mx - (RECT[hover][0] + Config.mhOff(hover, true));
            grabY = my - (RECT[hover][1] + Config.mhOff(hover, false));
        }
        if (r && !prevR && hover >= 0) {
            Config.mhSetOff(hover, true, 0);
            Config.mhSetOff(hover, false, 0);
            Config.save();
        }
        if (dragId >= 0 && l) {
            int w = RECT[dragId][2], h = RECT[dragId][3];
            double nx = MathHelper.clamp(mx - grabX, 0.0, Math.max(0, sw - w));
            double ny = MathHelper.clamp(my - grabY, 0.0, Math.max(0, sh - h));
            Config.mhSetOff(dragId, true, (int) Math.round(nx) - RECT[dragId][0]);
            Config.mhSetOff(dragId, false, (int) Math.round(ny) - RECT[dragId][1]);
        }
        if (dragId >= 0 && !l) {
            dragId = -1;
            Config.save();
        }
        hoverId = hover;
        prevL = l;
        prevR = r;

        // рамки вокруг панелей и подсказка
        for (int i = 0; i < N; i++) {
            if (!SHOWN[i]) continue;
            int rx = RECT[i][0] + Config.mhOff(i, true), ry = RECT[i][1] + Config.mhOff(i, false);
            boolean on = i == hover || i == dragId;
            float a = on ? 0.9f : 0.35f;
            int col = Ui.alpha(acc, a);
            Ui.rect(c, rx - 2, ry - 2, rx + RECT[i][2] + 2, ry - 1, col);
            Ui.rect(c, rx - 2, ry + RECT[i][3] + 1, rx + RECT[i][2] + 2, ry + RECT[i][3] + 2, col);
            Ui.rect(c, rx - 2, ry - 1, rx - 1, ry + RECT[i][3] + 1, col);
            Ui.rect(c, rx + RECT[i][2] + 1, ry - 1, rx + RECT[i][2] + 2, ry + RECT[i][3] + 1, col);
            if (on) Ui.text(c, tr, NAMES[i], rx, ry - 12, 0xFFFFFFFF);
        }
        String hint = String.format(Locale.ROOT, "HUD: тяни мышью, колесо - размер (x%.2f), ПКМ - сброс", Config.mhScale);
        Ui.text(c, tr, hint, (sw - Ui.width(tr, hint)) / 2, 28, Ui.alpha(0xFFFFFF, 0.65f));
    }

    // ------------------------------------------------------------ общие куски

    private static void begin(DrawContext c, int id) {
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(Config.mhOff(id, true), Config.mhOff(id, false), 0.0f);
    }

    private static void end(DrawContext c, int id, int x, int y, int w, int h) {
        c.getMatrices().pop();
        SHOWN[id] = true;
        RECT[id][0] = x;
        RECT[id][1] = y;
        RECT[id][2] = w;
        RECT[id][3] = h;
    }

    private static void panel(DrawContext c, float x, float y, float w, float h) {
        switch (Config.mhTheme) {
            case 1 -> {   // Solid
                Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.35f));
                Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(0xFF14141C, 0.97f));
            }
            case 2 -> {   // Accent
                Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.65f));
                Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(Ui.mix(0xFF0A0A12, acc, 0.22f), 0.88f));
            }
            case 3 -> Ui.rrectF(c, x, y, w, h, 4, Ui.alpha(0xFF0A0A12, 0.55f));   // Minimal
            default -> {   // Glass
                Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.20f));
                Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(0xFF0A0A12, 0.82f));
            }
        }
    }

    private static void dot(DrawContext c, float x, float y, int color) {
        Ui.rrectF(c, x, y, 5, 5, 2.5f, color);
    }

    private static int cpuLoad() {
        long now = System.currentTimeMillis();
        if (now - cpuAt > 700L) {
            cpuAt = now;
            try {
                java.lang.management.OperatingSystemMXBean b = ManagementFactory.getOperatingSystemMXBean();
                if (b instanceof com.sun.management.OperatingSystemMXBean os) {
                    double v = os.getCpuLoad();
                    if (v >= 0.0) cpu = (int) Math.round(v * 100.0);
                }
            } catch (Throwable ignored) {
                // метрика недоступна - оставляем прежнее значение
            }
        }
        return cpu;
    }

    private static int ping(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.getNetworkHandler() == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    // ------------------------------------------------------------ верхняя плашка

    private static int topBar(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw) {
        String server = (mc.isInSingleplayer() || mc.getCurrentServerEntry() == null) ? "Local" : mc.getCurrentServerEntry().address;
        Runtime rt = Runtime.getRuntime();
        int ram = (int) Math.round((rt.totalMemory() - rt.freeMemory()) * 100.0 / rt.maxMemory());
        String[] parts = {"noomidlc", server, LocalTime.now().format(TIME), ping(mc, p) + " MS",
                mc.getCurrentFps() + " FPS", cpuLoad() + "% CPU", ram + "% RAM", p.getName().getString()};
        int w = 8;
        for (String s : parts) w += 5 + 4 + Ui.width(tr, s) + 9;
        w += 16;
        int h = 18;
        int x = (sw - w) / 2;
        begin(c, TOP);
        panel(c, x, 4, w, h);
        int cx = x + 8;
        for (int i = 0; i < parts.length; i++) {
            dot(c, cx, 4 + 6.5f, i == 0 ? 0xFFFFFFFF : Ui.alpha(acc, 0.9f));
            cx += 9;
            Ui.textMid(c, tr, parts[i], cx, 4, h, i == 0 ? acc : 0xFFFFFFFF);
            cx += Ui.width(tr, parts[i]) + 9;
        }
        PlayerSkinDrawer.draw(c, p.getSkinTextures(), cx - 1, 4 + 3, 12);
        end(c, TOP, x, 4, w, h);
        return 4 + h;
    }

    // ------------------------------------------------------------ координаты и скорость

    private static int coords(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        String a = (int) Math.floor(p.getX()) + "X " + (int) Math.floor(p.getY()) + "Y " + (int) Math.floor(p.getZ()) + "Z";
        String b = String.format(Locale.ROOT, "%.2f BPS", bps);
        int w = 8 + 5 + 4 + Ui.width(tr, a) + 10 + 5 + 4 + Ui.width(tr, b) + 8;
        begin(c, COORDS);
        panel(c, 6, y, w, 16);
        int cx = 14;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, a, cx, y, 16, 0xFFFFFFFF);
        cx += Ui.width(tr, a) + 10;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, b, cx, y, 16, 0xFFFFFFFF);
        end(c, COORDS, 6, y, w, 16);
        return y + 16;
    }

    // ------------------------------------------------------------ кулдауны

    private static int cooldowns(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        List<Object[]> rows = new ArrayList<>();
        for (Item it : CD_ITEMS) {
            ItemStack st = new ItemStack(it);
            if (!p.getItemCooldownManager().isCoolingDown(st)) continue;
            float pr = MathHelper.clamp(p.getItemCooldownManager().getCooldownProgress(st, 0.0f), 0.0f, 1.0f);
            rows.add(new Object[]{st, pr});
        }
        if (rows.isEmpty() && preview) {   // образец, чтобы панель можно было двигать
            rows.add(new Object[]{new ItemStack(Items.ENDER_PEARL), 0.68f});
            rows.add(new Object[]{new ItemStack(Items.FIREWORK_ROCKET), 0.36f});
        }
        if (rows.isEmpty()) return y;
        int w = 124;
        int h = 18 + rows.size() * 17 + 2;
        begin(c, COOLDOWNS);
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Cooldowns", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (Object[] r : rows) {
            ItemStack st = (ItemStack) r[0];
            float pr = (Float) r[1];
            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(13.0f, ry - 1.0f, 0.0f);
            m.scale(0.75f, 0.75f, 1.0f);
            c.drawItem(st, 0, 0);
            m.pop();
            Ui.text(c, tr, st.getName().getString(), 28, ry, 0xFFFFFFFF);
            String pc = Math.round(pr * 100.0f) + "%";
            Ui.text(c, tr, pc, 6 + w - 8 - Ui.width(tr, pc), ry, Ui.alpha(0xFFFFFF, 0.8f));
            Ui.rrectF(c, 28, ry + 10, w - 30, 2, 1, Ui.alpha(0xFFFFFF, 0.12f));
            Ui.rrectF(c, 28, ry + 10, (w - 30) * pr, 2, 1, acc);
            ry += 17;
        }
        end(c, COOLDOWNS, 6, y, w, h);
        return y + h + 4;
    }

    // ------------------------------------------------------------ бинды модулей

    private static String keyName(int code) {
        if (code <= -100) {
            int b = -100 - code;
            return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "M" + (b + 1);
        }
        try {
            return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
        } catch (Throwable t) {
            return "K" + code;
        }
    }

    private static int keybinds(DrawContext c, TextRenderer tr, int y) {
        List<String[]> rows = new ArrayList<>();
        List<Boolean> on = new ArrayList<>();
        for (Map.Entry<String, Integer> e : Config.BINDS.entrySet()) {
            Modules.Mod m = Modules.get(e.getKey());
            if (m == null) continue;
            rows.add(new String[]{m.label(), keyName(e.getValue())});
            on.add(m.get().getAsBoolean());
        }
        if (rows.isEmpty() && preview) {
            rows.add(new String[]{"KillAura", "R"});
            on.add(true);
            rows.add(new String[]{"Bunny Hop", "H"});
            on.add(false);
        }
        if (rows.isEmpty()) return y;
        int w = 112;
        for (String[] r : rows) w = Math.max(w, 24 + Ui.width(tr, r[0]) + 14 + Ui.width(tr, r[1]));
        int h = 18 + rows.size() * 11 + 4;
        begin(c, KEYBINDS);
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Keybinds", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (int i = 0; i < rows.size(); i++) {
            int col = on.get(i) ? 0xFFFFFFFF : Ui.alpha(0xFFFFFF, 0.45f);
            Ui.text(c, tr, rows.get(i)[0], 14, ry, col);
            Ui.text(c, tr, rows.get(i)[1], 6 + w - 8 - Ui.width(tr, rows.get(i)[1]), ry, on.get(i) ? acc : col);
            ry += 11;
        }
        end(c, KEYBINDS, 6, y, w, h);
        return y + h + 4;
    }

    // ------------------------------------------------------------ броня (колонка)

    private static void armor(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        begin(c, ARMOR);
        panel(c, 6, y, 24, 4 * 18 + 6);
        for (int i = 0; i < 4; i++) {
            ItemStack st = p.getEquippedStack(slots[i]);
            if (st.isEmpty()) continue;
            c.drawItem(st, 10, y + 3 + i * 18);
            c.drawStackOverlay(tr, st, 10, y + 3 + i * 18);
        }
        end(c, ARMOR, 6, y, 24, 4 * 18 + 6);
    }

    // ------------------------------------------------------------ цель (игрок или животное)

    /** Цель KillAura / LegitAura, иначе сущность под прицелом; после потери цели держим её ещё ~2 секунды. */
    static LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity t = KillAura.target();
        if (t == null) t = LegitAura.target();
        if (t == null && mc.crosshairTarget instanceof EntityHitResult ehr
                && ehr.getEntity() instanceof LivingEntity le && le != p && le.isAlive() && !(le instanceof ArmorStandEntity)) {
            t = le;
        }
        long now = System.currentTimeMillis();
        if (t != null) {
            lastTarget = t;
            lastTargetAt = now;
            return t;
        }
        if (lastTarget != null && now - lastTargetAt < 2000L && lastTarget.isAlive() && !lastTarget.isRemoved()) {
            return lastTarget;
        }
        return null;
    }

    // ------------------------------------------------------------ таргет-худ: несколько стилей

    private static final class TInfo {
        LivingEntity t;
        String name, hpText, dist;
        float r, hp, max;
        int barCol;
        boolean sample;
    }

    private static final String[] HEART = {".XX.XX.", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."};

    private static void targetBox(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        LivingEntity t = findTarget(mc, p);
        boolean sample = false;
        if (t == null) {
            if (!preview) return;
            t = p;          // образец в чате, чтобы панель можно было двигать
            sample = true;
        }
        TInfo i = new TInfo();
        i.t = t;
        i.sample = sample;
        i.hp = t.getHealth();
        i.max = Math.max(1.0f, t.getMaxHealth());
        shownHp += (i.hp - shownHp) * 0.18f;
        i.r = MathHelper.clamp(shownHp / i.max, 0.0f, 1.0f);
        i.name = sample ? "Target" : t.getName().getString();
        i.hpText = String.format(Locale.ROOT, "%.1f HP", i.hp);
        i.dist = sample ? "" : String.format(Locale.ROOT, "%.1fm", p.distanceTo(t));
        i.barCol = Ui.mix(0xFFFF4D4D, 0xFF5CE08A, i.r);
        switch (Math.floorMod(Config.mhTargetStyle, Config.MH_TARGET_STYLES.length)) {
            case 1 -> styleCompact(c, tr, i, sw, sh);
            case 2 -> styleCard(c, tr, i, sw, sh);
            case 3 -> styleMinimal(c, tr, i, sw, sh);
            case 4 -> styleRing(c, tr, i, sw, sh);
            case 5 -> styleNeon(c, tr, i, sw, sh);
            case 6 -> styleHearts(c, tr, i, sw, sh);
            case 7 -> styleStrip(c, tr, i, sw, sh);
            default -> styleClassic(c, tr, i, sw, sh);
        }
    }

    // ---- общие детали стилей

    private static void head(DrawContext c, TextRenderer tr, TInfo i, int x, int y, int size) {
        if (i.t instanceof AbstractClientPlayerEntity ap) {
            PlayerSkinDrawer.draw(c, ap.getSkinTextures(), x, y, size);
        } else {
            // у животных и мобов нет скина: плашка с первой буквой названия
            Ui.rrectF(c, x, y, size, size, size / 4.0f, Ui.alpha(acc, 0.35f));
            String letter = i.name.isEmpty() ? "?" : i.name.substring(0, 1).toUpperCase(Locale.ROOT);
            Ui.textMid(c, tr, letter, x + (size - Ui.width(tr, letter)) / 2, y, size, 0xFFFFFFFF);
        }
    }

    private static void slot(DrawContext c, TextRenderer tr, ItemStack st, int x, int y, boolean overlay) {
        Ui.rrectF(c, x - 1, y - 1, 18, 18, 3, Ui.alpha(0xFFFFFF, 0.07f));
        if (st.isEmpty()) return;
        c.drawItem(st, x, y);
        if (overlay) c.drawStackOverlay(tr, st, x, y);
    }

    private static boolean hasHands(TInfo i) {
        return i.sample || i.t instanceof AbstractClientPlayerEntity
                || !i.t.getMainHandStack().isEmpty() || !i.t.getOffHandStack().isEmpty();
    }

    private static void hands(DrawContext c, TextRenderer tr, TInfo i, int x, int y) {
        slot(c, tr, i.t.getMainHandStack(), x, y, true);
        slot(c, tr, i.t.getOffHandStack(), x + 18, y, true);
    }

    private static void armorSlots(DrawContext c, TextRenderer tr, TInfo i, int x, int y) {
        EquipmentSlot[] es = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int k = 0; k < 4; k++) slot(c, tr, i.t.getEquippedStack(es[k]), x + k * 18, y, false);
    }

    private static void bar(DrawContext c, float x, float y, float w, float h, TInfo i) {
        Ui.rrectF(c, x, y, w, h, h / 2.0f, Ui.alpha(0xFFFFFF, 0.14f));
        if (i.r > 0.01f) Ui.rrectF(c, x, y, Math.max(h, w * i.r), h, h / 2.0f, i.barCol);
    }

    private static void ctext(DrawContext c, TextRenderer tr, String s, int cx, int y, int color) {
        Ui.text(c, tr, s, cx - Ui.width(tr, s) / 2, y, color);
    }

    private static void heart(DrawContext c, int x, int y, float fill) {
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < 7; col++) {
                if (HEART[row].charAt(col) != 'X') continue;
                int color = col < fill * 7.0f ? 0xFFFF4D5E : 0xFF3A3A48;
                Ui.rect(c, x + col, y + row, x + col + 1, y + row + 1, color);
            }
        }
    }

    // ---- 1. Classic: голова, имя, HP, расстояние, полоска и предметы в руках

    private static void styleClassic(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int w = Math.max(128, 36 + Math.max(Ui.width(tr, i.name), Ui.width(tr, i.hpText) + 10 + Ui.width(tr, i.dist)) + 8);
        boolean items = hasHands(i);
        int iw = items ? 40 : 0;
        w += iw;
        int h = 32;
        int x = sw / 2 - w / 2, y = sh / 2 + 66;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        head(c, tr, i, x + 5, y + 6, 20);
        Ui.text(c, tr, i.name, x + 31, y + 5, 0xFFFFFFFF);
        Ui.text(c, tr, i.hpText, x + 31, y + 15, Ui.alpha(0xFFFFFF, 0.8f));
        if (!i.dist.isEmpty()) Ui.text(c, tr, i.dist, x + w - 8 - iw - Ui.width(tr, i.dist), y + 15, Ui.alpha(0xFFFFFF, 0.55f));
        bar(c, x + 31, y + 25, w - 39 - iw, 3, i);
        if (items) hands(c, tr, i, x + w - 38, y + 7);
        end(c, TARGET, x, y, w, h);
    }

    // ---- 2. Compact: маленькая плашка

    private static void styleCompact(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        String hp = String.format(Locale.ROOT, "%.0f", i.hp);
        int w = Math.max(96, 22 + Ui.width(tr, i.name) + 10 + Ui.width(tr, hp) + 8);
        int h = 20;
        int x = sw / 2 - w / 2, y = sh / 2 + 70;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        head(c, tr, i, x + 4, y + 3, 12);
        Ui.text(c, tr, i.name, x + 20, y + 3, 0xFFFFFFFF);
        Ui.text(c, tr, hp, x + w - 8 - Ui.width(tr, hp), y + 3, i.barCol);
        bar(c, x + 20, y + 14, w - 28, 2, i);
        end(c, TARGET, x, y, w, h);
    }

    // ---- 3. Card: большая карточка с бронёй и руками

    private static void styleCard(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int w = 158, h = 66;
        int x = sw / 2 - w / 2, y = sh / 2 + 50;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        head(c, tr, i, x + 6, y + 6, 36);
        Ui.text(c, tr, i.name, x + 48, y + 6, 0xFFFFFFFF);
        Ui.text(c, tr, i.hpText, x + 48, y + 17, Ui.alpha(0xFFFFFF, 0.8f));
        if (!i.dist.isEmpty()) Ui.text(c, tr, i.dist, x + w - 8 - Ui.width(tr, i.dist), y + 17, Ui.alpha(0xFFFFFF, 0.55f));
        bar(c, x + 48, y + 30, w - 56, 6, i);
        armorSlots(c, tr, i, x + 6, y + 44);
        if (hasHands(i)) hands(c, tr, i, x + w - 42, y + 44);
        end(c, TARGET, x, y, w, h);
    }

    // ---- 4. Minimal: только текст и тонкая полоска, без плашки

    private static void styleMinimal(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int w = Math.max(100, Ui.width(tr, i.name) + 20);
        int h = 26;
        int x = sw / 2 - w / 2, y = sh / 2 + 70;
        begin(c, TARGET);
        ctext(c, tr, i.name, sw / 2, y, 0xFFFFFFFF);
        bar(c, x, y + 12, w, 2, i);
        ctext(c, tr, i.hpText, sw / 2, y + 17, Ui.alpha(0xFFFFFF, 0.75f));
        end(c, TARGET, x, y, w, h);
    }

    // ---- 5. Ring: кольцо здоровья вокруг головы

    private static void styleRing(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int cx = sw / 2, cy = sh / 2 + 96;
        int segs = 48;
        int filled = Math.round(i.r * segs);
        begin(c, TARGET);
        Ui.rrectF(c, cx - 33, cy - 33, 66, 66, 33, Ui.alpha(0xFF0A0A12, 0.75f));
        for (int k = 0; k < segs; k++) {
            double ang = -Math.PI / 2.0 + k * (Math.PI * 2.0 / segs);
            float px = cx + (float) Math.cos(ang) * 29.0f;
            float py = cy + (float) Math.sin(ang) * 29.0f;
            int col = k < filled ? i.barCol : Ui.alpha(0xFFFFFF, 0.14f);
            Ui.rrectF(c, px - 1.6f, py - 1.6f, 3.2f, 3.2f, 1.6f, col);
        }
        head(c, tr, i, cx - 14, cy - 14, 28);
        ctext(c, tr, i.name, cx, cy + 38, 0xFFFFFFFF);
        ctext(c, tr, i.hpText, cx, cy + 49, Ui.alpha(0xFFFFFF, 0.75f));
        end(c, TARGET, cx - 34, cy - 34, 68, 100);
    }

    // ---- 6. Neon: светящаяся рамка цвета темы и подсвеченная полоска

    private static void styleNeon(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 400.0);
        int w = Math.max(136, 34 + Ui.width(tr, i.name) + 14);
        int h = 36;
        int x = sw / 2 - w / 2, y = sh / 2 + 64;
        begin(c, TARGET);
        for (int k = 4; k >= 1; k--) {
            Ui.rrectF(c, x - k * 1.6f, y - k * 1.6f, w + k * 3.2f, h + k * 3.2f, 8 + k * 1.6f, Ui.alpha(acc, (0.04f + 0.04f * pulse) * (5 - k) / 4.0f));
        }
        Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.65f + 0.3f * pulse));
        Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(0xFF07070C, 0.95f));
        head(c, tr, i, x + 6, y + 7, 22);
        Ui.text(c, tr, i.name, x + 34, y + 6, acc);
        Ui.text(c, tr, i.hpText, x + w - 8 - Ui.width(tr, i.hpText), y + 6, Ui.alpha(0xFFFFFF, 0.85f));
        Ui.rrectF(c, x + 34, y + 21, w - 42, 6, 3, Ui.alpha(0xFFFFFF, 0.10f));
        if (i.r > 0.01f) {
            float bw = Math.max(6.0f, (w - 42) * i.r);
            Ui.rrectF(c, x + 34, y + 21, bw, 6, 3, Ui.mix(acc, 0xFFFFFFFF, 0.25f));
            Ui.rrectF(c, x + 34, y + 21, bw, 2, 1, Ui.alpha(0xFFFFFFFF, 0.35f));
        }
        end(c, TARGET, x, y, w, h);
    }

    // ---- 7. Hearts: сердечки вместо полоски

    private static void styleHearts(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int count = Math.min(10, (int) Math.ceil(i.max / 2.0f));
        int w = Math.max(count * 9 + 16, 22 + Ui.width(tr, i.name) + 10);
        int h = 36;
        int x = sw / 2 - w / 2, y = sh / 2 + 66;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        head(c, tr, i, x + 5, y + 4, 14);
        Ui.text(c, tr, i.name, x + 24, y + 4, 0xFFFFFFFF);
        if (!i.dist.isEmpty()) Ui.text(c, tr, i.dist, x + w - 8 - Ui.width(tr, i.dist), y + 4, Ui.alpha(0xFFFFFF, 0.55f));
        float perHeart = i.max / count;
        for (int k = 0; k < count; k++) {
            float fill = MathHelper.clamp((shownHp - k * perHeart) / perHeart, 0.0f, 1.0f);
            heart(c, x + 8 + k * 9, y + 22, fill);
        }
        end(c, TARGET, x, y, w, h);
    }

    // ---- 8. Strip: широкая горизонтальная полоса с бронёй и руками

    private static void styleStrip(DrawContext c, TextRenderer tr, TInfo i, int sw, int sh) {
        int w = 262, h = 26;
        int x = sw / 2 - w / 2, y = sh / 2 + 74;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        head(c, tr, i, x + 4, y + 4, 18);
        Ui.text(c, tr, i.name, x + 27, y + 3, 0xFFFFFFFF);
        Ui.text(c, tr, i.hpText, x + 27, y + 14, Ui.alpha(0xFFFFFF, 0.75f));
        bar(c, x + 84, y + 11, 54, 4, i);
        armorSlots(c, tr, i, x + 146, y + 5);
        if (hasHands(i)) hands(c, tr, i, x + w - 40, y + 5);
        end(c, TARGET, x, y, w, h);
    }

    // ------------------------------------------------------------ эффекты зелий

    private static void effects(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int sw) {
        List<Object[]> rows = new ArrayList<>();
        for (StatusEffectInstance in : p.getStatusEffects()) {
            rows.add(new Object[]{Hud.effName(in), Hud.effTime(in), Hud.effColor(in), Hud.effLow(in)});
        }
        if (rows.isEmpty() && preview) {   // образец, чтобы панель можно было двигать
            rows.add(new Object[]{"Speed II", "1:23", 0xFF7CAFC6, false});
            rows.add(new Object[]{"Strength", "0:05", 0xFF932423, true});
        }
        if (rows.isEmpty()) return;
        int w = 112;
        for (Object[] r : rows) w = Math.max(w, 30 + Ui.width(tr, (String) r[0]) + 14 + Ui.width(tr, (String) r[1]));
        int h = 18 + rows.size() * 12 + 2;
        int x = sw - w - 8, y = 30;
        begin(c, EFFECTS);
        panel(c, x, y, w, h);
        Ui.textMid(c, tr, "Effects", x + 8, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (Object[] r : rows) {
            dot(c, x + 8, ry + 2, (Integer) r[2]);
            Ui.text(c, tr, (String) r[0], x + 18, ry, 0xFFFFFFFF);
            String tm = (String) r[1];
            Ui.text(c, tr, tm, x + w - 8 - Ui.width(tr, tm), ry, (Boolean) r[3] ? 0xFFFF6B6B : Ui.alpha(0xFFFFFF, 0.8f));
            ry += 12;
        }
        end(c, EFFECTS, x, y, w, h);
    }

    // ------------------------------------------------------------ инвентарь (3 ряда)

    private static void inventory(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        int w = 9 * 18 + 8, h = 3 * 18 + 8;
        int x = sw - w - 8;
        int y = sh - h - 46;
        begin(c, INVENTORY);
        panel(c, x, y, w, h);
        for (int i = 0; i < 27; i++) {
            ItemStack st = p.getInventory().getStack(9 + i);
            int sx = x + 4 + (i % 9) * 18 + 1;
            int sy = y + 4 + (i / 9) * 18 + 1;
            Ui.rrectF(c, sx - 1, sy - 1, 18, 18, 3, Ui.alpha(0xFFFFFF, 0.05f));
            if (st.isEmpty()) continue;
            c.drawItem(st, sx, sy);
            c.drawStackOverlay(tr, st, sx, sy);
        }
        end(c, INVENTORY, x, y, w, h);
    }
}
