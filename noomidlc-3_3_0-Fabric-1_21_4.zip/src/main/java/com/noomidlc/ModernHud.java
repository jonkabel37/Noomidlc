package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

import java.lang.management.ManagementFactory;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Новый стиль HUD: верхняя плашка, координаты, кулдауны, бинды, броня, бокс игрока/цели, инвентарь. */
public final class ModernHud {
    private ModernHud() {}

    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.FIREWORK_ROCKET, Items.GOLDEN_APPLE,
            Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.WIND_CHARGE, Items.SHIELD};
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private static float bps = 0.0f;
    private static int cpu = 0;
    private static long cpuAt = 0L;
    private static float shownHp = 20.0f;

    private static int acc;

    public static void render(DrawContext c, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        acc = 0xFF000000 | Config.accent();

        // скорость в блоках в секунду (сглаженная)
        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        float cur = (float) (Math.hypot(dx, dz) * 20.0);
        bps += (cur - bps) * 0.1f;

        int y = 4;
        if (Config.mhTop) y = topBar(c, mc, tr, p, sw) + 4;
        if (Config.mhCoords) y = coords(c, tr, p, y) + 4;
        if (Config.mhCooldowns) y = cooldowns(c, mc, tr, p, y);
        if (Config.mhKeybinds) y = keybinds(c, mc, tr, y);
        if (Config.mhArmor) armor(c, tr, p, y);
        if (Config.mhTarget) targetBox(c, mc, tr, p, sw, sh);
        if (Config.mhInventory) inventory(c, tr, p, sw, sh);
    }

    // ------------------------------------------------------------ общие куски

    private static void panel(DrawContext c, float x, float y, float w, float h) {
        Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.20f));
        Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(0xFF0A0A12, 0.82f));
    }

    private static void dot(DrawContext c, float x, float y, int color) {
        Ui.rrectF(c, x, y, 5, 5, 2.5f, color);
    }

    private static int cpuLoad() {
        long now = System.currentTimeMillis();
        if (now - cpuAt > 700L) {
            cpuAt = now;
            try {
                java.lang.management.OperatingSystemMXBean b = ManagementFactory.getOperatingSystemMXBean();
                if (b instanceof com.sun.management.OperatingSystemMXBean os) {
                    double v = os.getCpuLoad();
                    if (v >= 0.0) cpu = (int) Math.round(v * 100.0);
                }
            } catch (Throwable ignored) {
                // метрика недоступна - оставляем прежнее значение
            }
        }
        return cpu;
    }

    private static int ping(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.getNetworkHandler() == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    // ------------------------------------------------------------ верхняя плашка

    private static int topBar(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw) {
        String server = (mc.isInSingleplayer() || mc.getCurrentServerEntry() == null) ? "Local" : mc.getCurrentServerEntry().address;
        Runtime rt = Runtime.getRuntime();
        int ram = (int) Math.round((rt.totalMemory() - rt.freeMemory()) * 100.0 / rt.maxMemory());
        String[] parts = {
                "noomidlc",
                server,
                LocalTime.now().format(TIME),
                ping(mc, p) + " MS",
                mc.getCurrentFps() + " FPS",
                cpuLoad() + "% CPU",
                ram + "% RAM",
                p.getName().getString()};
        int w = 8;
        for (String s : parts) w += 5 + 4 + Ui.width(tr, s) + 9;
        w += 16;
        int h = 18;
        int x = (sw - w) / 2;
        panel(c, x, 4, w, h);
        int cx = x + 8;
        for (int i = 0; i < parts.length; i++) {
            dot(c, cx, 4 + 6.5f, i == 0 ? 0xFFFFFFFF : Ui.alpha(acc, 0.9f));
            cx += 9;
            int col = i == 0 ? acc : 0xFFFFFFFF;
            Ui.textMid(c, tr, parts[i], cx, 4, h, col);
            cx += Ui.width(tr, parts[i]) + 9;
        }
        PlayerSkinDrawer.draw(c, p.getSkinTextures(), cx - 1, 4 + 3, 12);
        return 4 + h;
    }

    // ------------------------------------------------------------ координаты и скорость

    private static int coords(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        String a = (int) Math.floor(p.getX()) + "X " + (int) Math.floor(p.getY()) + "Y " + (int) Math.floor(p.getZ()) + "Z";
        String b = String.format(Locale.ROOT, "%.2f BPS", bps);
        int w = 8 + 5 + 4 + Ui.width(tr, a) + 10 + 5 + 4 + Ui.width(tr, b) + 8;
        panel(c, 6, y, w, 16);
        int cx = 14;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, a, cx, y, 16, 0xFFFFFFFF);
        cx += Ui.width(tr, a) + 10;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, b, cx, y, 16, 0xFFFFFFFF);
        return y + 16;
    }

    // ------------------------------------------------------------ кулдауны

    private static int cooldowns(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int y) {
        List<Object[]> rows = new ArrayList<>();
        for (Item it : CD_ITEMS) {
            ItemStack st = new ItemStack(it);
            if (!p.getItemCooldownManager().isCoolingDown(st)) continue;
            float pr = MathHelper.clamp(p.getItemCooldownManager().getCooldownProgress(st, 0.0f), 0.0f, 1.0f);
            rows.add(new Object[]{st, pr});
        }
        if (rows.isEmpty()) return y;
        int w = 124;
        int h = 18 + rows.size() * 17 + 2;
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Cooldowns", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (Object[] r : rows) {
            ItemStack st = (ItemStack) r[0];
            float pr = (Float) r[1];
            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(13.0f, ry - 1.0f, 0.0f);
            m.scale(0.75f, 0.75f, 1.0f);
            c.drawItem(st, 0, 0);
            m.pop();
            Ui.text(c, tr, st.getName().getString(), 28, ry, 0xFFFFFFFF);
            String pc = Math.round(pr * 100.0f) + "%";
            Ui.text(c, tr, pc, 6 + w - 8 - Ui.width(tr, pc), ry, Ui.alpha(0xFFFFFF, 0.8f));
            Ui.rrectF(c, 28, ry + 10, w - 30, 2, 1, Ui.alpha(0xFFFFFF, 0.12f));
            Ui.rrectF(c, 28, ry + 10, (w - 30) * pr, 2, 1, acc);
            ry += 17;
        }
        return y + h + 4;
    }

    // ------------------------------------------------------------ бинды модулей

    private static String keyName(int code) {
        if (code <= -100) {
            int b = -100 - code;
            return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "M" + (b + 1);
        }
        try {
            return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
        } catch (Throwable t) {
            return "K" + code;
        }
    }

    private static int keybinds(DrawContext c, MinecraftClient mc, TextRenderer tr, int y) {
        List<String[]> rows = new ArrayList<>();
        List<Boolean> on = new ArrayList<>();
        for (Map.Entry<String, Integer> e : Config.BINDS.entrySet()) {
            Modules.Mod m = Modules.get(e.getKey());
            if (m == null) continue;
            rows.add(new String[]{m.label(), keyName(e.getValue())});
            on.add(m.get().getAsBoolean());
        }
        if (rows.isEmpty()) return y;
        int w = 112;
        for (String[] r : rows) w = Math.max(w, 24 + Ui.width(tr, r[0]) + 14 + Ui.width(tr, r[1]));
        int h = 18 + rows.size() * 11 + 4;
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Keybinds", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (int i = 0; i < rows.size(); i++) {
            int col = on.get(i) ? 0xFFFFFFFF : Ui.alpha(0xFFFFFF, 0.45f);
            Ui.text(c, tr, rows.get(i)[0], 14, ry, col);
            Ui.text(c, tr, rows.get(i)[1], 6 + w - 8 - Ui.width(tr, rows.get(i)[1]), ry, on.get(i) ? acc : col);
            ry += 11;
        }
        return y + h + 4;
    }

    // ------------------------------------------------------------ броня (колонка)

    private static void armor(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        panel(c, 6, y, 24, 4 * 18 + 6);
        for (int i = 0; i < 4; i++) {
            ItemStack st = p.getEquippedStack(slots[i]);
            if (st.isEmpty()) continue;
            c.drawItem(st, 10, y + 3 + i * 18);
            c.drawStackOverlay(tr, st, 10, y + 3 + i * 18);
        }
    }

    // ------------------------------------------------------------ бокс игрока / цели

    private static void targetBox(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        PlayerEntity who = p;
        if (mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity e = ehr.getEntity();
            if (e instanceof PlayerEntity pe && e != p) who = pe;
        }
        float hp = who.getHealth();
        float max = Math.max(1.0f, who.getMaxHealth());
        shownHp += (hp - shownHp) * 0.15f;
        int w = 124, h = 30;
        int x = sw / 2 - w / 2;
        int y = sh / 2 + 66;
        panel(c, x, y, w, h);
        if (who instanceof AbstractClientPlayerEntity ap) {
            PlayerSkinDrawer.draw(c, ap.getSkinTextures(), x + 5, y + 5, 20);
        }
        Ui.text(c, tr, who.getName().getString(), x + 30, y + 5, 0xFFFFFFFF);
        Ui.text(c, tr, String.format(Locale.ROOT, "%.1f HP", hp), x + 30, y + 15, Ui.alpha(0xFFFFFF, 0.75f));
        float r = MathHelper.clamp(shownHp / max, 0.0f, 1.0f);
        Ui.rrectF(c, x + 30, y + 24, w - 38, 3, 1.5f, Ui.alpha(0xFFFFFF, 0.14f));
        Ui.rrectF(c, x + 30, y + 24, (w - 38) * r, 3, 1.5f, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------ инвентарь (3 ряда)

    private static void inventory(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        int w = 9 * 18 + 8, h = 3 * 18 + 8;
        int x = sw - w - 8;
        int y = sh - h - 46;
        panel(c, x, y, w, h);
        for (int i = 0; i < 27; i++) {
            ItemStack st = p.getInventory().getStack(9 + i);
            int sx = x + 4 + (i % 9) * 18 + 1;
            int sy = y + 4 + (i / 9) * 18 + 1;
            Ui.rrectF(c, sx - 1, sy - 1, 18, 18, 3, Ui.alpha(0xFFFFFF, 0.05f));
            if (st.isEmpty()) continue;
            c.drawItem(st, sx, sy);
            c.drawStackOverlay(tr, st, sx, sy);
        }
    }
}
