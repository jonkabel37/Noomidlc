package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.lang.management.ManagementFactory;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * HUD в виде панелей. Панели можно перетаскивать мышью, когда открыт чат
 * (ПКМ по панели возвращает её на место). Смещения сохраняются в конфиге.
 */
public final class ModernHud {
    private ModernHud() {}

    // номера панелей (совпадают с Config.mhOff)
    private static final int TOP = 0, COORDS = 1, COOLDOWNS = 2, KEYBINDS = 3, ARMOR = 4, TARGET = 5, INVENTORY = 6, N = 7;
    private static final String[] NAMES = {"Top bar", "Coords", "Cooldowns", "Keybinds", "Armor", "Target", "Inventory"};

    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.FIREWORK_ROCKET, Items.GOLDEN_APPLE,
            Items.ENCHANTED_GOLDEN_APPLE, Items.CHORUS_FRUIT, Items.WIND_CHARGE, Items.SHIELD};
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    // прямоугольники панелей без смещения (для перетаскивания) и признак, что панель нарисована
    private static final int[][] RECT = new int[N][4];
    private static final boolean[] SHOWN = new boolean[N];
    private static int dragId = -1;
    private static double grabX, grabY;
    private static boolean prevL = false, prevR = false;
    private static boolean preview = false;

    private static float bps = 0.0f;
    private static int cpu = 0;
    private static long cpuAt = 0L;
    private static float shownHp = 20.0f;
    private static LivingEntity lastTarget = null;
    private static long lastTargetAt = 0L;

    private static int acc;

    public static void render(DrawContext c, MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        acc = 0xFF000000 | Config.accent();
        preview = mc.currentScreen instanceof ChatScreen;
        Arrays.fill(SHOWN, false);

        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        bps += (float) (Math.hypot(dx, dz) * 20.0 - bps) * 0.1f;

        int y = 4;
        if (Config.mhTop) y = topBar(c, mc, tr, p, sw) + 4;
        if (Config.mhCoords) y = coords(c, tr, p, y) + 4;
        if (Config.mhCooldowns) y = cooldowns(c, tr, p, y);
        if (Config.mhKeybinds) y = keybinds(c, tr, y);
        if (Config.mhArmor) armor(c, tr, p, y);
        if (Config.mhTarget) targetBox(c, mc, tr, p, sw, sh);
        if (Config.mhInventory) inventory(c, tr, p, sw, sh);

        if (preview) dragLogic(c, mc, tr, sw, sh);
        else {
            dragId = -1;
            prevL = false;
            prevR = false;
        }
    }

    // ------------------------------------------------------------ перетаскивание в чате

    private static void dragLogic(DrawContext c, MinecraftClient mc, TextRenderer tr, int sw, int sh) {
        long handle = mc.getWindow().getHandle();
        double mx = mc.mouse.getX() * sw / (double) mc.getWindow().getWidth();
        double my = mc.mouse.getY() * sh / (double) mc.getWindow().getHeight();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        int hover = -1;
        for (int i = N - 1; i >= 0; i--) {
            if (!SHOWN[i]) continue;
            int rx = RECT[i][0] + Config.mhOff(i, true), ry = RECT[i][1] + Config.mhOff(i, false);
            if (mx >= rx && mx <= rx + RECT[i][2] && my >= ry && my <= ry + RECT[i][3]) {
                hover = i;
                break;
            }
        }

        if (l && !prevL && hover >= 0) {
            dragId = hover;
            grabX = mx - (RECT[hover][0] + Config.mhOff(hover, true));
            grabY = my - (RECT[hover][1] + Config.mhOff(hover, false));
        }
        if (r && !prevR && hover >= 0) {
            Config.mhSetOff(hover, true, 0);
            Config.mhSetOff(hover, false, 0);
            Config.save();
        }
        if (dragId >= 0 && l) {
            int w = RECT[dragId][2], h = RECT[dragId][3];
            double nx = MathHelper.clamp(mx - grabX, 0.0, Math.max(0, sw - w));
            double ny = MathHelper.clamp(my - grabY, 0.0, Math.max(0, sh - h));
            Config.mhSetOff(dragId, true, (int) Math.round(nx) - RECT[dragId][0]);
            Config.mhSetOff(dragId, false, (int) Math.round(ny) - RECT[dragId][1]);
        }
        if (dragId >= 0 && !l) {
            dragId = -1;
            Config.save();
        }
        prevL = l;
        prevR = r;

        // рамки вокруг панелей и подсказка
        for (int i = 0; i < N; i++) {
            if (!SHOWN[i]) continue;
            int rx = RECT[i][0] + Config.mhOff(i, true), ry = RECT[i][1] + Config.mhOff(i, false);
            boolean on = i == hover || i == dragId;
            float a = on ? 0.9f : 0.35f;
            int col = Ui.alpha(acc, a);
            Ui.rect(c, rx - 2, ry - 2, rx + RECT[i][2] + 2, ry - 1, col);
            Ui.rect(c, rx - 2, ry + RECT[i][3] + 1, rx + RECT[i][2] + 2, ry + RECT[i][3] + 2, col);
            Ui.rect(c, rx - 2, ry - 1, rx - 1, ry + RECT[i][3] + 1, col);
            Ui.rect(c, rx + RECT[i][2] + 1, ry - 1, rx + RECT[i][2] + 2, ry + RECT[i][3] + 1, col);
            if (on) Ui.text(c, tr, NAMES[i], rx, ry - 12, 0xFFFFFFFF);
        }
        String hint = "HUD: тяни панели мышью, ПКМ - сбросить";
        Ui.text(c, tr, hint, (sw - Ui.width(tr, hint)) / 2, 28, Ui.alpha(0xFFFFFF, 0.65f));
    }

    // ------------------------------------------------------------ общие куски

    private static void begin(DrawContext c, int id) {
        MatrixStack m = c.getMatrices();
        m.push();
        m.translate(Config.mhOff(id, true), Config.mhOff(id, false), 0.0f);
    }

    private static void end(DrawContext c, int id, int x, int y, int w, int h) {
        c.getMatrices().pop();
        SHOWN[id] = true;
        RECT[id][0] = x;
        RECT[id][1] = y;
        RECT[id][2] = w;
        RECT[id][3] = h;
    }

    private static void panel(DrawContext c, float x, float y, float w, float h) {
        Ui.rrectF(c, x - 1, y - 1, w + 2, h + 2, 8, Ui.alpha(acc, 0.20f));
        Ui.rrectF(c, x, y, w, h, 7, Ui.alpha(0xFF0A0A12, 0.82f));
    }

    private static void dot(DrawContext c, float x, float y, int color) {
        Ui.rrectF(c, x, y, 5, 5, 2.5f, color);
    }

    private static int cpuLoad() {
        long now = System.currentTimeMillis();
        if (now - cpuAt > 700L) {
            cpuAt = now;
            try {
                java.lang.management.OperatingSystemMXBean b = ManagementFactory.getOperatingSystemMXBean();
                if (b instanceof com.sun.management.OperatingSystemMXBean os) {
                    double v = os.getCpuLoad();
                    if (v >= 0.0) cpu = (int) Math.round(v * 100.0);
                }
            } catch (Throwable ignored) {
                // метрика недоступна - оставляем прежнее значение
            }
        }
        return cpu;
    }

    private static int ping(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.getNetworkHandler() == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    // ------------------------------------------------------------ верхняя плашка

    private static int topBar(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw) {
        String server = (mc.isInSingleplayer() || mc.getCurrentServerEntry() == null) ? "Local" : mc.getCurrentServerEntry().address;
        Runtime rt = Runtime.getRuntime();
        int ram = (int) Math.round((rt.totalMemory() - rt.freeMemory()) * 100.0 / rt.maxMemory());
        String[] parts = {"noomidlc", server, LocalTime.now().format(TIME), ping(mc, p) + " MS",
                mc.getCurrentFps() + " FPS", cpuLoad() + "% CPU", ram + "% RAM", p.getName().getString()};
        int w = 8;
        for (String s : parts) w += 5 + 4 + Ui.width(tr, s) + 9;
        w += 16;
        int h = 18;
        int x = (sw - w) / 2;
        begin(c, TOP);
        panel(c, x, 4, w, h);
        int cx = x + 8;
        for (int i = 0; i < parts.length; i++) {
            dot(c, cx, 4 + 6.5f, i == 0 ? 0xFFFFFFFF : Ui.alpha(acc, 0.9f));
            cx += 9;
            Ui.textMid(c, tr, parts[i], cx, 4, h, i == 0 ? acc : 0xFFFFFFFF);
            cx += Ui.width(tr, parts[i]) + 9;
        }
        PlayerSkinDrawer.draw(c, p.getSkinTextures(), cx - 1, 4 + 3, 12);
        end(c, TOP, x, 4, w, h);
        return 4 + h;
    }

    // ------------------------------------------------------------ координаты и скорость

    private static int coords(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        String a = (int) Math.floor(p.getX()) + "X " + (int) Math.floor(p.getY()) + "Y " + (int) Math.floor(p.getZ()) + "Z";
        String b = String.format(Locale.ROOT, "%.2f BPS", bps);
        int w = 8 + 5 + 4 + Ui.width(tr, a) + 10 + 5 + 4 + Ui.width(tr, b) + 8;
        begin(c, COORDS);
        panel(c, 6, y, w, 16);
        int cx = 14;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, a, cx, y, 16, 0xFFFFFFFF);
        cx += Ui.width(tr, a) + 10;
        dot(c, cx, y + 5.5f, Ui.alpha(acc, 0.9f));
        cx += 9;
        Ui.textMid(c, tr, b, cx, y, 16, 0xFFFFFFFF);
        end(c, COORDS, 6, y, w, 16);
        return y + 16;
    }

    // ------------------------------------------------------------ кулдауны

    private static int cooldowns(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        List<Object[]> rows = new ArrayList<>();
        for (Item it : CD_ITEMS) {
            ItemStack st = new ItemStack(it);
            if (!p.getItemCooldownManager().isCoolingDown(st)) continue;
            float pr = MathHelper.clamp(p.getItemCooldownManager().getCooldownProgress(st, 0.0f), 0.0f, 1.0f);
            rows.add(new Object[]{st, pr});
        }
        if (rows.isEmpty() && preview) {   // образец, чтобы панель можно было двигать
            rows.add(new Object[]{new ItemStack(Items.ENDER_PEARL), 0.68f});
            rows.add(new Object[]{new ItemStack(Items.FIREWORK_ROCKET), 0.36f});
        }
        if (rows.isEmpty()) return y;
        int w = 124;
        int h = 18 + rows.size() * 17 + 2;
        begin(c, COOLDOWNS);
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Cooldowns", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (Object[] r : rows) {
            ItemStack st = (ItemStack) r[0];
            float pr = (Float) r[1];
            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(13.0f, ry - 1.0f, 0.0f);
            m.scale(0.75f, 0.75f, 1.0f);
            c.drawItem(st, 0, 0);
            m.pop();
            Ui.text(c, tr, st.getName().getString(), 28, ry, 0xFFFFFFFF);
            String pc = Math.round(pr * 100.0f) + "%";
            Ui.text(c, tr, pc, 6 + w - 8 - Ui.width(tr, pc), ry, Ui.alpha(0xFFFFFF, 0.8f));
            Ui.rrectF(c, 28, ry + 10, w - 30, 2, 1, Ui.alpha(0xFFFFFF, 0.12f));
            Ui.rrectF(c, 28, ry + 10, (w - 30) * pr, 2, 1, acc);
            ry += 17;
        }
        end(c, COOLDOWNS, 6, y, w, h);
        return y + h + 4;
    }

    // ------------------------------------------------------------ бинды модулей

    private static String keyName(int code) {
        if (code <= -100) {
            int b = -100 - code;
            return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "M" + (b + 1);
        }
        try {
            return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString().toUpperCase(Locale.ROOT);
        } catch (Throwable t) {
            return "K" + code;
        }
    }

    private static int keybinds(DrawContext c, TextRenderer tr, int y) {
        List<String[]> rows = new ArrayList<>();
        List<Boolean> on = new ArrayList<>();
        for (Map.Entry<String, Integer> e : Config.BINDS.entrySet()) {
            Modules.Mod m = Modules.get(e.getKey());
            if (m == null) continue;
            rows.add(new String[]{m.label(), keyName(e.getValue())});
            on.add(m.get().getAsBoolean());
        }
        if (rows.isEmpty() && preview) {
            rows.add(new String[]{"KillAura", "R"});
            on.add(true);
            rows.add(new String[]{"Bunny Hop", "H"});
            on.add(false);
        }
        if (rows.isEmpty()) return y;
        int w = 112;
        for (String[] r : rows) w = Math.max(w, 24 + Ui.width(tr, r[0]) + 14 + Ui.width(tr, r[1]));
        int h = 18 + rows.size() * 11 + 4;
        begin(c, KEYBINDS);
        panel(c, 6, y, w, h);
        Ui.textMid(c, tr, "Keybinds", 14, y + 2, 14, 0xFFFFFFFF);
        int ry = y + 18;
        for (int i = 0; i < rows.size(); i++) {
            int col = on.get(i) ? 0xFFFFFFFF : Ui.alpha(0xFFFFFF, 0.45f);
            Ui.text(c, tr, rows.get(i)[0], 14, ry, col);
            Ui.text(c, tr, rows.get(i)[1], 6 + w - 8 - Ui.width(tr, rows.get(i)[1]), ry, on.get(i) ? acc : col);
            ry += 11;
        }
        end(c, KEYBINDS, 6, y, w, h);
        return y + h + 4;
    }

    // ------------------------------------------------------------ броня (колонка)

    private static void armor(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int y) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        begin(c, ARMOR);
        panel(c, 6, y, 24, 4 * 18 + 6);
        for (int i = 0; i < 4; i++) {
            ItemStack st = p.getEquippedStack(slots[i]);
            if (st.isEmpty()) continue;
            c.drawItem(st, 10, y + 3 + i * 18);
            c.drawStackOverlay(tr, st, 10, y + 3 + i * 18);
        }
        end(c, ARMOR, 6, y, 24, 4 * 18 + 6);
    }

    // ------------------------------------------------------------ цель (игрок или животное)

    /** Цель KillAura / LegitAura, иначе сущность под прицелом; после потери цели держим её ещё ~2 секунды. */
    private static LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity t = KillAura.target();
        if (t == null) t = LegitAura.target();
        if (t == null && mc.crosshairTarget instanceof EntityHitResult ehr
                && ehr.getEntity() instanceof LivingEntity le && le != p && le.isAlive() && !(le instanceof ArmorStandEntity)) {
            t = le;
        }
        long now = System.currentTimeMillis();
        if (t != null) {
            lastTarget = t;
            lastTargetAt = now;
            return t;
        }
        if (lastTarget != null && now - lastTargetAt < 2000L && lastTarget.isAlive() && !lastTarget.isRemoved()) {
            return lastTarget;
        }
        return null;
    }

    private static void targetBox(DrawContext c, MinecraftClient mc, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        LivingEntity t = findTarget(mc, p);
        boolean sample = false;
        if (t == null) {
            if (!preview) return;
            t = p;          // образец в чате, чтобы панель можно было двигать
            sample = true;
        }
        float hp = t.getHealth();
        float max = Math.max(1.0f, t.getMaxHealth());
        shownHp += (hp - shownHp) * 0.18f;
        String name = sample ? "Target" : t.getName().getString();
        String hpText = String.format(Locale.ROOT, "%.1f HP", hp);
        String dist = sample ? "" : String.format(Locale.ROOT, "%.1fm", p.distanceTo(t));
        int w = Math.max(128, 36 + Math.max(Ui.width(tr, name), Ui.width(tr, hpText) + 10 + Ui.width(tr, dist)) + 8);
        int h = 32;
        int x = sw / 2 - w / 2;
        int y = sh / 2 + 66;
        begin(c, TARGET);
        panel(c, x, y, w, h);
        if (t instanceof AbstractClientPlayerEntity ap) {
            PlayerSkinDrawer.draw(c, ap.getSkinTextures(), x + 5, y + 6, 20);
        } else {
            // у животных и мобов нет скина: рисуем плашку с первой буквой названия
            Ui.rrectF(c, x + 5, y + 6, 20, 20, 5, Ui.alpha(acc, 0.35f));
            String letter = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
            Ui.textMid(c, tr, letter, x + 5 + (20 - Ui.width(tr, letter)) / 2, y + 6, 20, 0xFFFFFFFF);
        }
        Ui.text(c, tr, name, x + 31, y + 5, 0xFFFFFFFF);
        Ui.text(c, tr, hpText, x + 31, y + 15, Ui.alpha(0xFFFFFF, 0.8f));
        if (!dist.isEmpty()) Ui.text(c, tr, dist, x + w - 8 - Ui.width(tr, dist), y + 15, Ui.alpha(0xFFFFFF, 0.55f));
        float r = MathHelper.clamp(shownHp / max, 0.0f, 1.0f);
        int barCol = Ui.mix(0xFFFF4D4D, 0xFF5CE08A, r);
        Ui.rrectF(c, x + 31, y + 25, w - 39, 3, 1.5f, Ui.alpha(0xFFFFFF, 0.14f));
        Ui.rrectF(c, x + 31, y + 25, (w - 39) * r, 3, 1.5f, barCol);
        end(c, TARGET, x, y, w, h);
    }

    // ------------------------------------------------------------ инвентарь (3 ряда)

    private static void inventory(DrawContext c, TextRenderer tr, ClientPlayerEntity p, int sw, int sh) {
        int w = 9 * 18 + 8, h = 3 * 18 + 8;
        int x = sw - w - 8;
        int y = sh - h - 46;
        begin(c, INVENTORY);
        panel(c, x, y, w, h);
        for (int i = 0; i < 27; i++) {
            ItemStack st = p.getInventory().getStack(9 + i);
            int sx = x + 4 + (i % 9) * 18 + 1;
            int sy = y + 4 + (i / 9) * 18 + 1;
            Ui.rrectF(c, sx - 1, sy - 1, 18, 18, 3, Ui.alpha(0xFFFFFF, 0.05f));
            if (st.isEmpty()) continue;
            c.drawItem(st, sx, sy);
            c.drawStackOverlay(tr, st, sx, sy);
        }
        end(c, INVENTORY, x, y, w, h);
    }
}
