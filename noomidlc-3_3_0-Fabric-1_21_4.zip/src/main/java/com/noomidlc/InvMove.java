package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Inventory Move: клавиши движения работают, пока открыт инвентарь/сундук/верстак и т.п. */
public final class InvMove {
    private InvMove() {}

    public static void tick(MinecraftClient mc) {
        tick(mc, true);
    }

    /** look = false: только клавиши (второй вызов за тик, стрелки не крутим дважды). */
    public static void tick(MinecraftClient mc, boolean look) {
        if (!Config.invMove || mc.player == null) return;
        Screen s = mc.currentScreen;
        if (s == null) return;
        // экраны с полем ввода текста не трогаем (наковальня, креатив-поиск, чат и т.п.)
        boolean ok = (s instanceof HandledScreen<?> || s instanceof ClickGuiScreen)
                && !(s instanceof AnvilScreen) && !(s instanceof CreativeInventoryScreen);
        if (!ok) return;

        KeyBinding[] keys = {
                mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey,
                mc.options.jumpKey, mc.options.sprintKey, mc.options.sneakKey};
        for (KeyBinding k : keys) k.setPressed(down(mc, k));

        // стрелки поворачивают камеру (мышь в инвентаре занята курсором)
        if (look && Config.invArrows) {
            long h = mc.getWindow().getHandle();
            float sp = Config.invLook;
            float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
            if (InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_LEFT)) yaw -= sp;
            if (InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_RIGHT)) yaw += sp;
            if (InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_UP)) pitch -= sp;
            if (InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_DOWN)) pitch += sp;
            mc.player.setYaw(yaw);
            mc.player.setPitch(Math.max(-90.0f, Math.min(90.0f, pitch)));
        }
    }

    private static boolean down(MinecraftClient mc, KeyBinding k) {
        InputUtil.Key key = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey());
        long h = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.KEYSYM) return InputUtil.isKeyPressed(h, key.getCode());
        if (key.getCategory() == InputUtil.Type.MOUSE) return GLFW.glfwGetMouseButton(h, key.getCode()) == GLFW.GLFW_PRESS;
        return false;
    }
}
