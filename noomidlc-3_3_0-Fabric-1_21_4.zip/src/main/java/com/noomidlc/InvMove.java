package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Inventory Move: клавиши движения работают, пока открыт инвентарь/сундук/верстак и т.п. */
public final class InvMove {
    private InvMove() {}

    public static void tick(MinecraftClient mc) {
        if (!Config.invMove || mc.player == null) return;
        Screen s = mc.currentScreen;
        // экраны с полем ввода текста не трогаем
        if (!(s instanceof HandledScreen<?>) || s instanceof AnvilScreen || s instanceof CreativeInventoryScreen) return;

        KeyBinding[] keys = {
                mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey,
                mc.options.jumpKey, mc.options.sprintKey, mc.options.sneakKey};
        for (KeyBinding k : keys) k.setPressed(down(mc, k));
    }

    private static boolean down(MinecraftClient mc, KeyBinding k) {
        InputUtil.Key key = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey());
        long h = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.KEYSYM) return InputUtil.isKeyPressed(h, key.getCode());
        if (key.getCategory() == InputUtil.Type.MOUSE) return GLFW.glfwGetMouseButton(h, key.getCode()) == GLFW.GLFW_PRESS;
        return false;
    }
}
