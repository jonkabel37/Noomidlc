package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.Comparator;

/**
 * Kill Aura: выбирает ближайшую цель в радиусе, плавно поворачивает камеру и бьёт, когда удар заряжен.
 * Сверху - анимированное кольцо-метка на цели.
 */
public final class KillAura {
    private KillAura() {}

    private static LivingEntity target = null;
    private static LivingEntity shown = null;   // цель, которая рисуется (держим во время затухания)
    private static float markAlpha = 0.0f;
    private static int wait = 0;
    private static int lockedId = -1;
    private static boolean lockDown = false;

    public static LivingEntity locked() {
        return lockedId == -1 || MinecraftClient.getInstance().world == null ? null
                : (MinecraftClient.getInstance().world.getEntityById(lockedId) instanceof LivingEntity le ? le : null);
    }

    public static LivingEntity target() {
        return target;
    }

    // ------------------------------------------------------------ логика

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.killAura || p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || p.isSpectator() || !p.isAlive()) {
            target = null;
            wait = 0;
            Crit.release(mc);
            return;
        }

        handleLock(mc);
        target = pick(mc, p);
        if (target == null) {
            wait = 0;
            Crit.release(mc);
            return;
        }
        shown = target;

        if (Config.kaRotate && Config.kaMode == 1) aim(p, target);   // Free: камеру не трогаем

        if (p.isUsingItem()) return;
        if (Config.kaCritsOnly) {
            // бьём только критами: ждём падения после прыжка (бег гасим, прыжок по желанию делаем сами)
            Crit.prepare(mc, p);
            if (p.getAttackCooldownProgress(0.5f) < Config.kaCharge) return;
            if (!Crit.ready(p)) return;
        } else {
            Crit.release(mc);
            if (p.getAttackCooldownProgress(0.5f) < Config.kaCharge) return;
        }
        if (wait++ < Math.round(Config.kaDelay)) return;

        mc.interactionManager.attackEntity(p, target);
        if (Config.kaSwing) p.swingHand(Hand.MAIN_HAND);
        wait = 0;
    }

    /** Клавиша выбора: цель под прицелом становится приоритетной; повторное нажатие (или нажатие в пустоту) снимает выбор. */
    private static void handleLock(MinecraftClient mc) {
        boolean d = Config.kaLockBind != -1 && Actions.isDown(mc, Config.kaLockBind);
        if (d && !lockDown) {
            HitResult hr = mc.crosshairTarget;
            if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le && le.getId() != lockedId) {
                lockedId = le.getId();
            } else {
                lockedId = -1;
            }
        }
        lockDown = d;
        LivingEntity l = locked();
        if (lockedId != -1 && (l == null || !l.isAlive())) lockedId = -1;
    }

    private static LivingEntity pick(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        double range = Config.kaRange;
        LivingEntity lock = locked();
        if (lock != null) {
            if (distance(eye, lock) <= range && (Config.kaWalls || p.canSee(lock))) return lock;
            if (Config.kaLockOnly) return null;
        } else if (Config.kaLockOnly) {
            return null;
        }
        LivingEntity candidate = mc.world.getEntitiesByClass(LivingEntity.class,
                        p.getBoundingBox().expand(range + 1.0), e -> valid(p, e))
                .stream()
                .filter(e -> distance(eye, e) <= range)
                .filter(e -> Config.kaWalls || p.canSee(e))
                .filter(e -> Config.kaMode == 0 || Math.abs(yawDiff(p, e)) <= Config.kaFov / 2.0f)
                .min(comparator(p, eye))
                .orElse(null);

        // Удерживаем текущую цель, пока новая не станет заметно лучше:
        // это убирает переключение между двумя близкими сущностями и рывки камеры.
        if (target != null && target.isAlive() && valid(p, target)
                && distance(eye, target) <= range
                && (Config.kaWalls || p.canSee(target))
                && (Config.kaMode == 0 || Math.abs(yawDiff(p, target)) <= Config.kaFov / 2.0f)) {
            if (Config.kaMode == 1) return target;   // Focused: держим одну цель до конца
            if (candidate == null || candidate == target
                    || distance(eye, target) <= distance(eye, candidate) * 1.18) {
                return target;
            }
        }
        return candidate;
    }

    private static Comparator<LivingEntity> comparator(ClientPlayerEntity p, Vec3d eye) {
        return switch (Config.kaSort) {
            case 1 -> Comparator.comparingDouble(LivingEntity::getHealth);
            case 2 -> Comparator.comparingDouble(e -> Math.abs(yawDiff(p, e)));
            default -> Comparator.comparingDouble(e -> distance(eye, e));
        };
    }

    private static boolean valid(ClientPlayerEntity p, LivingEntity e) {
        if (e == p || !e.isAlive() || !e.isAttackable() || e instanceof ArmorStandEntity) return false;
        if (e.isSpectator()) return false;
        if (e.isInvisible() && !Config.kaInvis) return false;
        if (e instanceof PlayerEntity) return Config.kaPlayers;
        if (e instanceof HostileEntity || e instanceof Monster) return Config.kaMobs;
        if (e instanceof VillagerEntity || e instanceof PassiveEntity) return Config.kaAnimals;
        return Config.kaMobs;
    }

    private static double distance(Vec3d eye, Entity e) {
        Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    private static float yawDiff(ClientPlayerEntity p, Entity e) {
        double dx = e.getX() - p.getX();
        double dz = e.getZ() - p.getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        return MathHelper.wrapDegrees(yaw - p.getYaw());
    }

    /**
     * Плавный поворот без тряски: берём долю оставшегося угла (затухание вместо фиксированного шага),
     * внутри мёртвой зоны не вращаем вообще, чтобы камера не дрожала около цели.
     */
    private static void aim(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Vec3d to = new Vec3d(t.getX(), t.getY() + t.getHeight() * 0.62, t.getZ());
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 57.29577951308232);

        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();

        Anim.frame();
        float dt = MathHelper.clamp(Anim.dt(), 0.001f, 0.05f);
        // kaSmooth задаёт интенсивность сглаживания; экспонента не зависит от FPS.
        // Более резкий отклик: меньше ощущения «вязкой» камеры.
        // Сглаживание остаётся независимым от FPS, но быстрее догоняет цель.
        float response = 14.0f + MathHelper.clamp(Config.kaSmooth, 0.05f, 1.0f) * 32.0f;
        float k = 1.0f - (float) Math.exp(-response * dt);
        float dead = 0.08f;
        // Увеличен предел углового шага: поворот не отстаёт от быстро движущейся цели.
        float maxStep = Math.max(1.0f, Config.kaRotSpeed) * 60.0f * dt;
        float sy = Math.abs(dyaw) < dead ? 0.0f : MathHelper.clamp(dyaw * k, -maxStep, maxStep);
        float sp = Math.abs(dpitch) < dead ? 0.0f : MathHelper.clamp(dpitch * k, -maxStep, maxStep);
        if (sy == 0.0f && sp == 0.0f) return;
        p.setYaw(p.getYaw() + sy);
        p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90.0f, 90.0f));
    }

    // ------------------------------------------------------------ метка на цели

    public static void renderMark(WorldRenderContext ctx) {
        Anim.frame();
        markAlpha = Anim.smooth(markAlpha, (Config.killAura && Config.kaMark && target != null) ? 1.0f : 0.0f, 12.0f);
        if (markAlpha <= 0.01f || shown == null || !shown.isAlive()) return;

        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d pos = shown.getLerpedPos(td);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = WorldFx.fixMatrix(ctx, ms.peek().getPositionMatrix());

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        long ms0 = System.currentTimeMillis();
        float h = shown.getHeight();
        float r = shown.getWidth() * 0.8f + 0.25f;
        // кольцо ходит вверх-вниз по телу, за ним тянется затухающий шлейф
        float phase = (float) ((Math.sin(ms0 / 520.0) + 1.0) * 0.5);
        float dir = (float) Math.cos(ms0 / 520.0);
        int segs = 40;
        int trail = 8;
        for (int k = 0; k < trail; k++) {
            float back = k * 0.045f * (dir >= 0 ? -1.0f : 1.0f);
            float y = (float) pos.y + MathHelper.clamp(phase + back, 0.0f, 1.0f) * h;
            float a = markAlpha * (1.0f - k / (float) trail) * 0.55f;
            ring(mat, (float) pos.x, y, (float) pos.z, r, 0.07f, segs, a, ms0);
        }
        // ровное кольцо у ног
        ring(mat, (float) pos.x, (float) pos.y + 0.03f, (float) pos.z, r + 0.05f, 0.1f, segs, markAlpha * 0.75f, ms0);

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static void ring(Matrix4f mat, float cx, float y, float cz, float r, float w, int segs, float alpha, long t) {
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float f = (float) i / segs;
            double a = f * Math.PI * 2.0;
            float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
            int col = argb(WorldFx.rgbOf(Config.espColor, f), alpha * (0.55f + 0.45f * (float) Math.sin(a * 2.0 + t / 300.0)));
            b.vertex(mat, cx + cs * (r - w), y, cz + sn * (r - w)).color(col);
            b.vertex(mat, cx + cs * (r + w), y, cz + sn * (r + w)).color(col);
        }
        Ui.flush(b);
    }

    private static int argb(int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }
}
