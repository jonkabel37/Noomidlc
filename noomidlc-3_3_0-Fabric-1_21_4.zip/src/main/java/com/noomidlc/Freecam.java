package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/** Freecam: камера летает отдельно, персонаж стоит на месте. Камеру двигает CameraMixin. */
public final class Freecam {
    private Freecam() {}

    private static boolean active = false;
    private static double x, y, z, px, py, pz;

    public static boolean active() {
        return active;
    }

    /** Позиция камеры с интерполяцией между тиками. */
    public static double[] pos(float td) {
        return new double[]{px + (x - px) * td, py + (y - py) * td, pz + (z - pz) * td};
    }

    private static boolean down(MinecraftClient mc, KeyBinding k) {
        InputUtil.Key key = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey());
        long h = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.KEYSYM) return InputUtil.isKeyPressed(h, key.getCode());
        if (key.getCategory() == InputUtil.Type.MOUSE) return GLFW.glfwGetMouseButton(h, key.getCode()) == GLFW.GLFW_PRESS;
        return false;
    }

    /** Вызывается в начале тика, до того как игра прочитает клавиши. */
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            active = false;
            return;
        }
        if (Config.freecam && !active) {
            active = true;
            Vec3d e = mc.player.getEyePos();
            x = px = e.x;
            y = py = e.y;
            z = pz = e.z;
        } else if (!Config.freecam && active) {
            active = false;
            return;
        }
        if (!active) return;

        px = x;
        py = y;
        pz = z;
        if (mc.currentScreen != null) return;

        boolean f = down(mc, mc.options.forwardKey), b = down(mc, mc.options.backKey);
        boolean l = down(mc, mc.options.leftKey), r = down(mc, mc.options.rightKey);
        boolean up = down(mc, mc.options.jumpKey), dn = down(mc, mc.options.sneakKey);
        boolean fast = down(mc, mc.options.sprintKey);

        double yaw = Math.toRadians(mc.player.getYaw());
        double pitch = Math.toRadians(mc.player.getPitch());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);

        double fw = (f ? 1 : 0) - (b ? 1 : 0);
        double sd = (r ? 1 : 0) - (l ? 1 : 0);
        double vt = (up ? 1 : 0) - (dn ? 1 : 0);
        double dx = fx * fw + rx * sd;
        double dy = fy * fw + vt;
        double dz = fz * fw + rz * sd;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len > 1.0e-4) {
            double sp = Config.fcSpeed * (fast ? 2.0 : 1.0) * 0.5;
            x += dx / len * sp;
            y += dy / len * sp;
            z += dz / len * sp;
        }

        // персонаж не должен двигаться
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
    }
}
