package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Box;

/** Time Changer (своё время суток только у вас на экране) и Safe Walk (не даёт упасть с края). */
public final class WorldMods {
    private WorldMods() {}

    private static boolean sneakHeld = false;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            sneakHeld = false;
            return;
        }
        if (Config.timeChanger) {
            mc.world.setTimeOfDay(Config.TC_VALUES[Math.floorMod(Config.tcTime, Config.TC_VALUES.length)]);
        }

        boolean edge = false;
        if (Config.safeWalk && mc.currentScreen == null && p.isOnGround() && !p.getAbilities().flying
                && !p.isClimbing() && !p.hasVehicle()) {
            float f = (mc.options.forwardKey.isPressed() ? 1.0f : 0.0f) - (mc.options.backKey.isPressed() ? 1.0f : 0.0f);
            float l = (mc.options.leftKey.isPressed() ? 1.0f : 0.0f) - (mc.options.rightKey.isPressed() ? 1.0f : 0.0f);
            if (f != 0.0f || l != 0.0f) {
                double yaw = Math.toRadians(p.getYaw());
                double dx = -Math.sin(yaw) * f + Math.cos(yaw) * l;
                double dz = Math.cos(yaw) * f + Math.sin(yaw) * l;
                double len = Math.max(0.001, Math.hypot(dx, dz));
                dx = dx / len * 0.35;
                dz = dz / len * 0.35;
                Box next = p.getBoundingBox().offset(dx, -0.65, dz);
                edge = mc.world.isSpaceEmpty(p, next);
            }
        }
        if (edge) {
            mc.options.sneakKey.setPressed(true);
            sneakHeld = true;
        } else if (sneakHeld) {
            mc.options.sneakKey.setPressed(false);
            sneakHeld = false;
        }
    }
}
