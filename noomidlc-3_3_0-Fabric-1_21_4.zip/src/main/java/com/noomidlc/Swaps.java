package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** Auto Swap (тотем <-> предмет в левой руке) и Elytra Swap (нагрудник <-> элитры) по клавише. */
public final class Swaps {
    private Swaps() {}

    public static final String[] SWAP_ITEMS = {"Golden Apple", "Shield", "Firework", "Ender Pearl"};
    private static final String[] CHEST_ORDER = {"netherite", "diamond", "iron", "chainmail", "golden", "leather"};

    private static boolean asDown = false, esDown = false;
    private static long last = 0L;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            asDown = false;
            esDown = false;
            return;
        }
        boolean free = mc.currentScreen == null;

        boolean a = free && Config.autoSwap && Actions.isDown(mc, Config.asBind);
        if (a && !asDown) autoSwap(mc, p);
        asDown = a;

        boolean e = free && Config.elytraSwap && Actions.isDown(mc, Config.esBind);
        if (e && !esDown) elytraSwap(mc, p);
        esDown = e;
    }

    private static boolean ready() {
        long now = System.currentTimeMillis();
        if (now - last < 200L) return false;
        last = now;
        return true;
    }

    private static boolean isItem(ItemStack s, int mode) {
        return switch (mode) {
            case 1 -> s.isOf(Items.SHIELD);
            case 2 -> s.isOf(Items.FIREWORK_ROCKET);
            case 3 -> s.isOf(Items.ENDER_PEARL);
            default -> s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
        };
    }

    private static int slotId(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;   // номер слота в PlayerScreenHandler
    }

    /** Левая рука: если там тотем - берём выбранный предмет, иначе возвращаем тотем. */
    private static void autoSwap(MinecraftClient mc, ClientPlayerEntity p) {
        if (!ready()) return;
        boolean wantTotem = !p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        PlayerInventory inv = p.getInventory();
        int found = -1;
        for (int i = 9; i < 36 && found < 0; i++) {
            ItemStack s = inv.getStack(i);
            if (wantTotem ? s.isOf(Items.TOTEM_OF_UNDYING) : isItem(s, Config.asItem)) found = i;
        }
        for (int i = 0; i < 9 && found < 0; i++) {
            ItemStack s = inv.getStack(i);
            if (wantTotem ? s.isOf(Items.TOTEM_OF_UNDYING) : isItem(s, Config.asItem)) found = i;
        }
        if (found < 0) return;
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slotId(found), 40, SlotActionType.SWAP, p);
    }

    private static int chestScore(ItemStack s) {
        if (s.isEmpty()) return -1;
        String path = Registries.ITEM.getId(s.getItem()).getPath();
        if (!path.endsWith("_chestplate")) return -1;
        for (int i = 0; i < CHEST_ORDER.length; i++) {
            if (path.startsWith(CHEST_ORDER[i])) return CHEST_ORDER.length - i;
        }
        return 0;
    }

    /** Если надеты элитры - надеваем лучший нагрудник из инвентаря, иначе надеваем элитры. */
    private static void elytraSwap(MinecraftClient mc, ClientPlayerEntity p) {
        if (!ready()) return;
        boolean wearingElytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        PlayerInventory inv = p.getInventory();
        int found = -1;
        int best = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (wearingElytra) {
                int sc = chestScore(s);
                if (sc > best) {
                    best = sc;
                    found = i;
                }
            } else if (s.isOf(Items.ELYTRA)) {
                found = i;
                break;
            }
        }
        if (found < 0) return;
        int sync = p.playerScreenHandler.syncId;
        int src = slotId(found);
        // три клика: взять предмет, положить в слот нагрудника (6), вернуть снятую вещь на место
        mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(sync, 6, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p);
    }
}
