package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Дополнительные HUD-панели: цель и локальный радар игроков. */
public final class HudExtras {
    private HudExtras() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = Config.accent();

        // Компактный компас с направлением взгляда.
        if (Config.hudCompass) {
            String facing = mc.player.getHorizontalFacing().asString().toUpperCase(java.util.Locale.ROOT);
            float yaw = mc.player.getYaw();
            String heading = String.format(java.util.Locale.ROOT, "%.0f°", (yaw % 360.0f + 360.0f) % 360.0f);
            String compass = "✦  " + facing + "  " + heading;
            int w = mc.textRenderer.getWidth(compass) + 18;
            int x = (sw - w) / 2, y = 8;
            ctx.fill(x, y, x + w, y + 19, 0xB9101018);
            ctx.fill(x, y, x + w, y + 1, accent);
            ctx.drawText(mc.textRenderer, compass, x + 9, y + 6, 0xFFFFFFFF, true);
        }

        // Название измерения (Overworld / Nether / End).
        if (Config.hudDimension) {
            String dimension = mc.world.getRegistryKey().getValue().getPath();
            String label = dimension.replace('_', ' ').toUpperCase(java.util.Locale.ROOT);
            int w = mc.textRenderer.getWidth(label) + 14;
            int x = 8, y = sh - 25;
            ctx.fill(x, y, x + w, y + 16, 0xB9101018);
            ctx.fill(x, y, x + 2, y + 16, accent);
            ctx.drawText(mc.textRenderer, label, x + 7, y + 4, 0xFFE8E8F0, true);
        }

        // Мягкое предупреждение о низком здоровье по краям экрана.
        if (Config.lowHealthWarning && mc.player.getHealth() <= Config.lowHealthThreshold) {
            float pulse = 0.55f + 0.25f * (float)Math.sin(System.currentTimeMillis() / 260.0);
            int alpha = Math.max(35, Math.min(110, (int)(pulse * 110.0f)));
            int red = (alpha << 24) | 0x00FF2020;
            int band = Math.max(8, Math.min(22, sw / 35));
            ctx.fill(0, 0, sw, band, red);
            ctx.fill(0, sh - band, sw, sh, red);
            ctx.fill(0, band, band, sh - band, red);
            ctx.fill(sw - band, band, sw, sh - band, red);
            String warning = "LOW HEALTH";
            int tx = (sw - mc.textRenderer.getWidth(warning)) / 2;
            ctx.drawText(mc.textRenderer, warning, tx, sh / 2 + 28, 0xFFFF7777, true);
        }

        if (Config.hudTarget) TargetHud.render(ctx, mc, sw, sh, accent);

        if (Config.hudRadar) {
            int size = 94, x = sw - size - 12, y = 12, cx = x + size / 2, cy = y + size / 2;
            ctx.fill(x, y, x + size, y + size, 0xB9101018);
            ctx.fill(x, y, x + size, y + 1, accent);
            ctx.fill(cx - 1, y + 8, cx + 1, y + size - 8, 0x665E6475);
            ctx.fill(x + 8, cy - 1, x + size - 8, cy + 1, 0x665E6475);
            ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFFFFFFFF);

            Vec3d origin = mc.player.getPos();
            double yaw = Math.toRadians(mc.player.getYaw());
            double sin = Math.sin(yaw), cos = Math.cos(yaw);
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || !p.isAlive()) continue;
                double dx = p.getX() - origin.x, dz = p.getZ() - origin.z;
                double rx = (dx * cos - dz * sin) / 32.0;
                double rz = (dx * sin + dz * cos) / 32.0;
                if (Math.abs(rx) > 1.0 || Math.abs(rz) > 1.0) continue;
                int px = cx + (int)Math.round(rx * 37.0);
                int py = cy + (int)Math.round(rz * 37.0);
                ctx.fill(px - 2, py - 2, px + 3, py + 3, 0xFFFF6666);
            }
            ctx.drawText(mc.textRenderer, "RADAR", x + 5, y + size + 3, 0xFFD8D8E8, true);
        }
    }
}
