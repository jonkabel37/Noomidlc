package com.noomidlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Мягкое предупреждение о низком здоровье по краям экрана. */
public final class HudExtras {
    private HudExtras() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!Config.lowHealthWarning || mc.player.getHealth() > Config.lowHealthThreshold) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float pulse = 0.55f + 0.25f * (float) Math.sin(System.currentTimeMillis() / 260.0);
        int alpha = Math.max(35, Math.min(110, (int) (pulse * 110.0f)));
        int red = (alpha << 24) | 0x00FF2020;
        int band = Math.max(8, Math.min(22, sw / 35));
        ctx.fill(0, 0, sw, band, red);
        ctx.fill(0, sh - band, sw, sh, red);
        ctx.fill(0, band, band, sh - band, red);
        ctx.fill(sw - band, band, sw, sh - band, red);
        String warning = "LOW HEALTH";
        int tx = (sw - mc.textRenderer.getWidth(warning)) / 2;
        ctx.drawText(mc.textRenderer, warning, tx, sh / 2 + 28, 0xFFFF7777, true);
    }
}
